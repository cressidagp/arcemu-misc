﻿/* ArcEmu Manager
 * 
 * Copyright (C) 2010 Mitchell Kutchuk (Mitch528)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *  
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *  
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *  
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ArcEmu_Manager.Properties;
using MySql.Data.MySqlClient;
using System.Threading;
using System.IO;
using System.Diagnostics;
using System.Collections;

namespace ArcEmu_Manager
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        public delegate void UpdateText(string message);

        private Dictionary<string, List<string>> acctdict = new Dictionary<string, List<string>>();
        private Dictionary<string, List<string>> chardict = new Dictionary<string, List<string>>();

        private Dictionary<string, string> ipbandict = new Dictionary<string, string>();

        private List<string> bnamelist = new List<string>();

        private List<Dictionary<string, string>> itemlist = new List<Dictionary<string, string>>();

        private int lastindex = 0;

        public delegate void UpdateTextCallback(string message);

        private int loginprocid = 0;
        private int worldprocid = 0;

        private FileSystemWatcher _watchFolder;
        private FileSystemWatcher _watchFile;

        private string logfile = String.Empty;
        private string logdirname = String.Empty;

        private Process loginproc = new Process();
        private Process worldproc = new Process();

        private void Form1_Load(object sender, EventArgs e)
        {

            if (Settings.Default.sql == false)
            {
                Form2 firstSQL = new Form2();

                firstSQL.Show();

                firstSQL.Activate();

                firstSQL.TopMost = true;

                this.Enabled = false;

                firstSQL.FormClosing += new FormClosingEventHandler(firstSQL_FormClosing);
            }

            tabControl1.SelectedIndexChanged += new EventHandler(tabControl1_SelectedIndexChanged);
            tabControl2.SelectedIndexChanged += new EventHandler(tabControl2_SelectedIndexChanged);
            tabControl3.SelectedIndexChanged += new EventHandler(tabControl3_SelectedIndexChanged);
            creatorTabControl.SelectedIndexChanged += new EventHandler(creatorTabControl_SelectedIndexChanged);

            textBox12.KeyPress += new KeyPressEventHandler(textBox12_KeyPress);
            textBox13.KeyPress += new KeyPressEventHandler(textBox13_KeyPress);
            textBox14.KeyPress += new KeyPressEventHandler(textBox14_KeyPress);
            textBox15.KeyPress += new KeyPressEventHandler(textBox15_KeyPress);

            //Mail

            mailGoldTextBox.KeyPress += new KeyPressEventHandler(mailGoldTextBox_KeyPress);

            //Item Details
            itemDisplayidTextBox.KeyPress += new KeyPressEventHandler(itemDisplayidTextBox_KeyPress);
            itemEntryTextBox.KeyPress += new KeyPressEventHandler(itemEntryTextBox_KeyPress);
            itemLevelTextBox.KeyPress += new KeyPressEventHandler(itemLevelTextBox_KeyPress);

            //Item Requirements
            itemRequiredLevelTextBox.KeyPress += new KeyPressEventHandler(itemRequiredLevelTextBox_KeyPress);
            itemSkillLevelTextBox.KeyPress += new KeyPressEventHandler(itemSkillLevelTextBox_KeyPress);
            itemsMaxTextBox.KeyPress += new KeyPressEventHandler(itemsMaxTextBox_KeyPress);

            //Item Price
            itemsBuyGoldTextBox.KeyPress += new KeyPressEventHandler(itemsBuyGoldTextBox_KeyPress);

            itemsSellGoldTextBox.KeyPress += new KeyPressEventHandler(itemsSellGoldTextBox_KeyPress);

            //Vendors

            vendorEntryIDTextBox.KeyPress += new KeyPressEventHandler(vendorEntryIDTextBox_KeyPress);
            vendorItemEntryIDTextBox.KeyPress += new KeyPressEventHandler(vendorItemEntryIDTextBox_KeyPress);

            textBox19.KeyPress += new KeyPressEventHandler(textBox19_KeyPress);

            comboBox1.SelectedIndexChanged += new EventHandler(loginChanged);

            listBox1.SelectedIndexChanged += new EventHandler(listBox1_SelectedIndexChanged);
            listBox2.SelectedIndexChanged += new EventHandler(listBox2_SelectedIndexChanged);

            //On Application Exit
            Application.ApplicationExit += new EventHandler(Application_ApplicationExit);
            //End On Application Exit

            button27.Visible = false;
            button28.Visible = false;

            //Item Creator
            itemQualityComboBox.SelectedIndex = 0;
            itemTypeComboBox.SelectedIndex = 0;
            itemBindsComboBox.SelectedIndex = 0;
            itemSkillProfessionComboBox.SelectedIndex = 0;

            itemsTabControl.TabPages.Remove(itemRequirementsTabPage);
            itemsTabControl.TabPages.Remove(itemPriceTabPage);
            itemsTabControl.TabPages.Remove(itemFinishTabPage);

            itemsAllClasses.CheckedChanged += new EventHandler(itemsAllClasses_CheckedChanged);
            itemsAllRaces.CheckedChanged += new EventHandler(itemsAllRaces_CheckedChanged);

            //End Item Creator//

            //NPC Creator//

            npcTabControl.TabPages.Remove(npcBehaviorTabPage);
            npcTabControl.TabPages.Remove(npcStatsTabPage);
            npcTabControl.TabPages.Remove(npcResistsTabPage);
            npcTabControl.TabPages.Remove(npcOptionsTabPage);
            npcTabControl.TabPages.Remove(npcLootTabPage);
            npcTabControl.TabPages.Remove(npcFinishTabPage);

            //Details
            npcRankComboBox.SelectedIndex = 0;
            npcFactionComboBox.SelectedIndex = 0;
            npcTypeComboBox.SelectedIndex = 0;

            npcDisplayidTextBox.KeyPress += new KeyPressEventHandler(npcDisplayidTextBox_KeyPress);
            npcEntryIDTextBox.KeyPress += new KeyPressEventHandler(npcEntryIDTextBox_KeyPress);
            npcHoursTextBox.KeyPress += new KeyPressEventHandler(npcHoursTextBox_KeyPress);

            //Stats
            npcArmorTextBox.KeyPress += new KeyPressEventHandler(npcArmorTextBox_KeyPress);
            npcManaTextBox.KeyPress += new KeyPressEventHandler(npcManaTextBox_KeyPress);
            npcMinHealthTextBox.KeyPress += new KeyPressEventHandler(npcMinHealthTextBox_KeyPress);
            npcMaxHealthTextBox.KeyPress += new KeyPressEventHandler(npcMaxHealthTextBox_KeyPress);
            npcMinLevelTextBox.KeyPress += new KeyPressEventHandler(npcMinLevelTextBox_KeyPress);
            npcMaxLevelTextBox.KeyPress += new KeyPressEventHandler(npcMaxLevelTextBox_KeyPress);
            npcMinDamageTextBox.KeyPress += new KeyPressEventHandler(npcMinDamageTextBox_KeyPress);
            npcMaxDamageTextBox.KeyPress += new KeyPressEventHandler(npcMaxDamageTextBox_KeyPress);
            npcSpeedTextBox.KeyPress += new KeyPressEventHandler(npcSpeedTextBox_KeyPress);

            //Resists
            npcResistHolyTextBox.KeyPress += new KeyPressEventHandler(npcResistHolyTextBox_KeyPress);
            npcResistNatureTextBox.KeyPress += new KeyPressEventHandler(npcResistNatureTextBox_KeyPress);
            npcResistShadowTextBox.KeyPress += new KeyPressEventHandler(npcResistShadowTextBox_KeyPress);
            npcResistFireTextBox.KeyPress += new KeyPressEventHandler(npcResistFireTextBox_KeyPress);
            npcResistFrostTextBox.KeyPress += new KeyPressEventHandler(npcResistFrostTextBox_KeyPress);
            npcResistArcaneTextBox.KeyPress += new KeyPressEventHandler(npcResistArcaneTextBox_KeyPress);

            //Loot

            //End NPC Creator//

            npcLootGoldTextBox.KeyPress += new KeyPressEventHandler(npcLootGoldTextBox_KeyPress);

            //Weapon Creator//

            weaponsTabControl.TabPages.Remove(weaponStatsTabPage);
            weaponsTabControl.TabPages.Remove(weaponRequirementsTabPage);
            weaponsTabControl.TabPages.Remove(weaponDamageTabPage);
            weaponsTabControl.TabPages.Remove(weaponResistsTabPage);
            weaponsTabControl.TabPages.Remove(weaponSocketsTabPage);
            weaponsTabControl.TabPages.Remove(weaponPriceTabPage);
            weaponsTabControl.TabPages.Remove(weaponFinishTabPage);

            weaponClassAllCheckBox.CheckedChanged += new EventHandler(weaponClassAllCheckBox_CheckedChanged);
            weaponRaceAllCheckBox.CheckedChanged += new EventHandler(weaponRaceAllCheckBox_CheckedChanged);

            //Details

            weaponDisplayIDTextBox.KeyPress += new KeyPressEventHandler(weaponDisplayIDTextBox_KeyPress);
            weaponEntryIDTextBox.KeyPress += new KeyPressEventHandler(weaponEntryIDTextBox_KeyPress);
            weaponDurabilityTextBox.KeyPress += new KeyPressEventHandler(weaponDurabilityTextBox_KeyPress);

            weaponQualityComboBox.SelectedIndex = 0;
            weaponEquipComboBox.SelectedIndex = 0;
            weaponTypeComboBox.SelectedIndex = 0;
            weaponBindComboBox.SelectedIndex = 0;

            //Stats

            weaponBlockTextBox.KeyPress += new KeyPressEventHandler(weaponBlockTextBox_KeyPress);
            weaponBlockArmorTextBox.KeyPress += new KeyPressEventHandler(weaponBlockArmorTextBox_KeyPress);

            weaponSheathComboBox.SelectedIndex = 0;
            weaponAmmoTypeComboBox.SelectedIndex = 0;

            //Requirements

            weaponRequiredLevelTextBox.KeyPress += new KeyPressEventHandler(weaponRequiredLevelTextBox_KeyPress);
            weaponItemLevelTextBox.KeyPress += new KeyPressEventHandler(weaponItemLevelTextBox_KeyPress);
            weaponMaxTextBox.KeyPress += new KeyPressEventHandler(weaponMaxTextBox_KeyPress);
            weaponStackableTextBox.KeyPress += new KeyPressEventHandler(weaponStackableTextBox_KeyPress);

            //Damage

            weaponDamageMin1TextBox.KeyPress += new KeyPressEventHandler(weaponDamageMin1TextBox_KeyPress);
            weaponDamageMax1TextBox.KeyPress += new KeyPressEventHandler(weaponDamageMax1TextBox_KeyPress);
            weaponDamageMin2TextBox.KeyPress += new KeyPressEventHandler(weaponDamageMin2TextBox_KeyPress);
            weaponDamageMax2TextBox.KeyPress += new KeyPressEventHandler(weaponDamageMax2TextBox_KeyPress);

            weaponDamageType1ComboBox.SelectedIndex = 0;
            weaponDamageType2ComboBox.SelectedIndex = 0;

            //Resists

            weaponHolyTextBox.KeyPress += new KeyPressEventHandler(weaponHolyTextBox_KeyPress);
            weaponNatureTextBox.KeyPress += new KeyPressEventHandler(weaponNatureTextBox_KeyPress);
            weaponShadowTextBox.KeyPress += new KeyPressEventHandler(weaponShadowTextBox_KeyPress);
            weaponFireTextBox.KeyPress += new KeyPressEventHandler(weaponFireTextBox_KeyPress);
            weaponFrostTextBox.KeyPress += new KeyPressEventHandler(weaponFrostTextBox_KeyPress);
            weaponArcaneTextBox.KeyPress += new KeyPressEventHandler(weaponArcaneTextBox_KeyPress);

            //Sockets

            weaponSocketBonusComboBox.SelectedIndex = 0;

            //Price

            weaponBuyGoldTextBox.KeyPress += new KeyPressEventHandler(weaponBuyGoldTextBox_KeyPress);
            weaponSellGoldTextBox.KeyPress += new KeyPressEventHandler(weaponSellGoldTextBox_KeyPress);

            //End Weapon Creator//

            //Armor Creator//

            armorTabControl.TabPages.Remove(armorStatsTabPage);
            armorTabControl.TabPages.Remove(armorRequirementsTabPage);
            armorTabControl.TabPages.Remove(armorSocketsTabPage);
            armorTabControl.TabPages.Remove(armorPriceTabPage);
            armorTabControl.TabPages.Remove(armorFinishTabPage);

            //Details

            armorDisplayIDTextBox.KeyPress += new KeyPressEventHandler(armorDisplayIDTextBox_KeyPress);
            armorEntryIDTextBox.KeyPress += new KeyPressEventHandler(armorEntryIDTextBox_KeyPress);
            armorDurabilityTextBox.KeyPress += new KeyPressEventHandler(armorDurabilityTextBox_KeyPress);

            armorQualityComboBox.SelectedIndex = 0;
            armorEquipComboBox.SelectedIndex = 0;
            armorMaterialComboBox.SelectedIndex = 0;
            armorBindsComboBox.SelectedIndex = 0;

            //Stats

            armorStatsBlockTextBox.KeyPress += new KeyPressEventHandler(armorStatsBlockTextBox_KeyPress);
            armorStatsArmorTextBox.KeyPress += new KeyPressEventHandler(armorStatsArmorTextBox_KeyPress);

            //Requirements

            armorClassAllCheckBox.CheckedChanged += new EventHandler(armorClassAllCheckBox_CheckedChanged);
            armorRaceAllCheckBox.CheckedChanged += new EventHandler(armorRaceAllCheckBox_CheckedChanged);

            armorRequiredLevelTextBox.KeyPress += new KeyPressEventHandler(armorRequiredLevelTextBox_KeyPress);
            armorItemLevelTextBox.KeyPress += new KeyPressEventHandler(armorItemLevelTextBox_KeyPress);
            armorMaxTextBox.KeyPress += new KeyPressEventHandler(armorMaxTextBox_KeyPress);
            armorStackableTextBox.KeyPress += new KeyPressEventHandler(armorStackableTextBox_KeyPress);

            //Sockets

            armorBonusComboBox.SelectedIndex = 0;

            //Price

            armorBuyGoldTextBox.KeyPress += new KeyPressEventHandler(armorBuyGoldTextBox_KeyPress);
            armorSellGoldTextBox.KeyPress += new KeyPressEventHandler(armorSellGoldTextBox_KeyPress);

            //End Armor Creator//

            //Loot Creator//

            lootNPCEntryIDTextBox.KeyPress += new KeyPressEventHandler(lootNPCEntryIDTextBox_KeyPress);
            lootItemEntryIDTextBox.KeyPress += new KeyPressEventHandler(lootItemEntryIDTextBox_KeyPress);
            lootChanceTextBox.KeyPress += new KeyPressEventHandler(lootChanceTextBox_KeyPress);

            //End Loot Creator//
        }

        private void firstSQL_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form2 sql = (Form2)sender;

            if (sql.buttonPressed)
            {
                this.Enabled = true;
            }
            else
            {
                Application.Exit();
            }
        }

        private void Application_ApplicationExit(object sender, EventArgs e)
        {
            try
            {
                bool exists = false;

                foreach (Process p in Process.GetProcesses())
                {
                    if (p.Id == loginprocid && loginprocid != 0)
                    {
                        exists = true;
                    }
                }

                if (exists == true)
                {
                    if (!loginproc.HasExited)
                    {
                        loginproc.Kill();

                        loginproc.Close();
                        loginproc.Dispose();
                    }
                }

                exists = false;

                foreach (Process p in Process.GetProcesses())
                {
                    if (p.Id == worldprocid && worldprocid != 0)
                    {
                        exists = true;
                    }
                }

                if (exists == true)
                {
                    if (!worldproc.HasExited)
                    {
                        worldproc.Kill();

                        worldproc.Close();
                        worldproc.Dispose();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void setAccounts()
        {
            try
            {
                if (acctdict != null)
                {

                    int index = comboBox1.SelectedIndex;

                    label2.Text = String.Format("Account ID: {0}", acctdict["acct"][index]);
                    textBox2.Text = acctdict["pword"][index];
                    textBox3.Text = acctdict["email"][index];
                    textBox4.Text = acctdict["gm"][index];
                    textBox5.Text = acctdict["flags"][index];

                    if (acctdict["banned"][index] == "0")
                    {
                        comboBox2.SelectedIndex = 0;
                    }
                    else if (acctdict["banned"][index] == "1")
                    {
                        comboBox2.SelectedIndex = 1;
                    }
                    else
                    {
                        comboBox2.Items.Clear();
                        comboBox2.Enabled = false;
                        comboBox2.Items.Add("Error");
                    }

                    if (acctdict["muted"][index] == "0")
                    {
                        comboBox3.SelectedIndex = 0;
                    }
                    else if (acctdict["muted"][index] == "1")
                    {
                        comboBox3.SelectedIndex = 1;
                    }
                    else
                    {
                        comboBox3.Items.Clear();
                        comboBox3.Enabled = false;
                        comboBox3.Items.Add("Error");
                    }

                    textBox6.Text = acctdict["banreason"][index];
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void loginChanged(object sender, EventArgs e)
        {
            try
            {
                setAccounts();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private Dictionary<string, List<string>> GetAccounts()
        {
            try
            {

                string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.logondb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                MySqlConnection mConnection = new MySqlConnection(connection);

                mConnection.Open();

                string qry = "SELECT * FROM accounts LIMIT 1000";

                MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                MySqlDataReader Reader = cmd.ExecuteReader();

                List<string> acct = new List<string>();
                List<string> login = new List<string>();
                List<string> pword = new List<string>();
                List<string> gm = new List<string>();
                List<string> banned = new List<string>();
                List<string> email = new List<string>();
                List<string> flags = new List<string>();
                List<string> muted = new List<string>();
                List<string> banreason = new List<string>();

                Dictionary<string, List<string>> dictionary = new Dictionary<string, List<string>>();

                while (Reader.Read())
                {
                    acct.Add(Reader.GetString("acct"));
                    login.Add(Reader.GetString("login"));
                    pword.Add(Reader.GetString("password"));
                    gm.Add(Reader.GetString("gm"));
                    banned.Add(Reader.GetString("banned"));
                    email.Add(Reader.GetString("email"));
                    flags.Add(Reader.GetString("flags"));
                    muted.Add(Reader.GetString("muted"));
                    if (!Reader.IsDBNull(Reader.GetOrdinal("banreason")))
                    {
                        banreason.Add(Reader.GetString("banreason"));
                    }
                    else
                    {
                        banreason.Add(String.Empty);
                    }
                }

                mConnection.Close();

                dictionary.Add("acct", acct);
                dictionary.Add("login", login);
                dictionary.Add("pword", pword);
                dictionary.Add("gm", gm);
                dictionary.Add("banned", banned);
                dictionary.Add("email", email);
                dictionary.Add("flags", flags);
                dictionary.Add("muted", muted);
                dictionary.Add("banreason", banreason);

                return dictionary;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return null;
            }

        }

        private void mySQLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.FormClosing += new FormClosingEventHandler(form2Closing);

            form2.Show();
        }

        private void form2Closing(object sender, EventArgs args)
        {
            try
            {
                if (Settings.Default.host != String.Empty && Settings.Default.port != String.Empty && Settings.Default.username != String.Empty && Settings.Default.password != String.Empty && Settings.Default.logondb != String.Empty && Settings.Default.chardb != String.Empty && Settings.Default.worlddb != String.Empty)
                {
                    if (tabControl1.SelectedTab == tabPage1)
                    {
                        acctdict = GetAccounts();

                        if (comboBox1.Items.Count == 0)
                        {
                            if (acctdict != null)
                            {

                                for (int i = 0; i < acctdict["login"].Count; i++)
                                {
                                    comboBox1.Items.Add(acctdict["login"][i]);
                                }

                                comboBox1.SelectedIndex = 0;
                            }
                        }
                        setAccounts();
                    }
                    else if (tabControl1.SelectedTab == tabPage2)
                    {
                        listBox1.Items.Clear();

                        chardict = GetCharacters();

                        if (chardict != null)
                        {
                            for (int i = 0; i < chardict["name"].Count; i++)
                            {
                                listBox1.Items.Add(chardict["name"][i]);
                            }

                            listBox1.SelectedIndex = 0;

                            SetCharacters();
                        }
                    }
                    else if (tabControl1.SelectedTab == tabPage3)
                    {
                    }
                    else if (tabControl1.SelectedTab == tabPage4)
                    {
                    }
                    else if (tabControl1.SelectedTab == tabPage5)
                    {
                    }
                    else if (tabControl1.SelectedTab == tabPage13)
                    {
                        listBox2.Items.Clear();
                        listBox3.Items.Clear();

                        chardict = GetCharacters();

                        if (chardict != null)
                        {
                            for (int i = 0; i < chardict["name"].Count; i++)
                            {
                                listBox2.Items.Add(chardict["name"][i]);
                            }

                            listBox2.SelectedIndex = 0;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {

                string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.logondb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                MySqlConnection mConnection = new MySqlConnection(connection);

                mConnection.Open();

                string qry = String.Empty;

                if (textBox1.Text != String.Empty)
                {
                    qry = String.Format("UPDATE accounts SET login='{0}', password='{1}', gm='{2}', banned='{3}', email='{4}', flags='{5}', muted='{6}', banreason='{7}' WHERE acct='{8}'",
                        textBox1.Text, textBox2.Text, textBox4.Text, comboBox2.SelectedIndex, textBox3.Text, textBox5.Text, comboBox3.SelectedIndex, textBox6.Text, acctdict["acct"][comboBox1.SelectedIndex]);
                }
                else
                {
                    qry = String.Format("UPDATE accounts SET password='{0}', gm='{1}', banned='{2}', email='{3}', flags='{4}', muted='{5}', banreason='{6}' WHERE acct='{7}'",
                        textBox2.Text, textBox4.Text, comboBox2.SelectedIndex, textBox3.Text, textBox5.Text, comboBox3.SelectedIndex, textBox6.Text, acctdict["acct"][comboBox1.SelectedIndex]);
                }

                MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                cmd.ExecuteReader();

                mConnection.Close();

                MessageBox.Show("Account Saved", "Success");
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (acctdict != null)
                {
                    acctdict = GetAccounts();

                    setAccounts();

                }
                else
                {
                    MessageBox.Show("Could not revert changes!", "Error");
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void creditsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();

            form3.Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }



        private Dictionary<string, List<string>> GetCharacters()
        {

            try
            {

                string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.logondb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                MySqlConnection mConnection = new MySqlConnection(connection);

                mConnection.Open();

                string qry = "SELECT * FROM accounts LIMIT 1000";

                MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                MySqlDataReader Reader = cmd.ExecuteReader();

                List<string> acctid = new List<string>();
                List<string> acctname = new List<string>();

                while (Reader.Read())
                {
                    acctid.Add(Reader.GetString("acct"));
                    acctname.Add(Reader.GetString("login"));
                }

                mConnection.Close();

                connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.chardb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                mConnection = new MySqlConnection(connection);

                mConnection.Open();

                qry = "SELECT * FROM characters LIMIT 1000";

                cmd = new MySqlCommand(qry, mConnection);

                Reader = cmd.ExecuteReader();

                Dictionary<string, List<string>> dictionary = new Dictionary<string, List<string>>();

                List<string> guid = new List<string>();
                List<string> acct = new List<string>();
                List<string> name = new List<string>();
                List<string> gender = new List<string>();
                List<string> level = new List<string>();
                List<string> gold = new List<string>();
                List<string> banned = new List<string>();

                while (Reader.Read())
                {
                    guid.Add(Reader.GetString("guid"));
                    acct.Add(Reader.GetString("acct"));
                    name.Add(Reader.GetString("name"));
                    gender.Add(Reader.GetString("gender"));
                    level.Add(Reader.GetString("level"));
                    gold.Add(Reader.GetString("gold"));
                    banned.Add(Reader.GetString("banned"));
                }

                List<string> accountname = new List<string>();

                for (int i = 0; i < acct.Count; i++)
                {

                    bool found = false;

                    for (int x = 0; x < acctname.Count; x++)
                    {
                        if (acct.ElementAt(i) == acctid.ElementAt(x))
                        {
                            accountname.Add(acctname.ElementAt(x));

                            found = true;
                        }
                    }

                    if (found == false)
                    {
                        accountname.Add("Account Name Not Found!");
                    }

                }
                if (guid.Count != 0)
                {
                    dictionary.Add("guid", guid);
                    dictionary.Add("acctname", accountname);
                    dictionary.Add("banned", banned);
                    dictionary.Add("acct", acct);
                    dictionary.Add("name", name);
                    dictionary.Add("gender", gender);
                    dictionary.Add("level", level);
                    dictionary.Add("gold", gold);
                }
                else
                {
                    return null;
                }
                mConnection.Close();

                return dictionary;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return null;
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (tabControl1.SelectedTab == tabPage1) //Accounts
            {
                if (Settings.Default.host != String.Empty && Settings.Default.port != String.Empty && Settings.Default.username != String.Empty && Settings.Default.password != String.Empty && Settings.Default.logondb != String.Empty && Settings.Default.chardb != String.Empty && Settings.Default.worlddb != String.Empty)
                {
                    if (comboBox1.Items.Count != 0)
                        comboBox1.Items.Clear();

                    acctdict = GetAccounts();

                    if (acctdict != null)
                    {

                        for (int i = 0; i < acctdict["login"].Count; i++)
                        {
                            comboBox1.Items.Add(acctdict["login"][i]);
                        }

                        comboBox1.SelectedIndex = 0;
                    }
                }
                else
                {
                    MessageBox.Show("You must configure MySQL to use this feature!");
                }
            }
            else if (tabControl1.SelectedTab == tabPage2) //Characters
            {

                if (Settings.Default.host != String.Empty && Settings.Default.port != String.Empty && Settings.Default.username != String.Empty && Settings.Default.password != String.Empty && Settings.Default.logondb != String.Empty && Settings.Default.chardb != String.Empty && Settings.Default.worlddb != String.Empty)
                {

                    listBox1.Items.Clear();

                    chardict = GetCharacters();

                    if (chardict != null)
                    {
                        for (int i = 0; i < chardict["name"].Count; i++)
                        {
                            listBox1.Items.Add(chardict["name"][i]);
                        }

                        listBox1.SelectedIndex = 0;

                        SetCharacters();
                    }
                }
                else
                {
                    MessageBox.Show("You must configure MySQL to use this feature!");
                }
            }
            else if (tabControl1.SelectedTab == tabPage3)
            {

            }
            else if (tabControl1.SelectedTab == tabPage4)
            {

                if (Settings.Default.host != String.Empty && Settings.Default.port != String.Empty && Settings.Default.username != String.Empty && Settings.Default.password != String.Empty && Settings.Default.logondb != String.Empty && Settings.Default.chardb != String.Empty && Settings.Default.worlddb != String.Empty)
                {
                    listBox4.Items.Clear();

                    ipbandict = GetIPBans();

                    if (ipbandict != null)
                    {
                        for (int i = 0; i < ipbandict.Count; i++)
                        {
                            listBox4.Items.Add(String.Format("{0} ({1})", ipbandict.ElementAt(i).Key, ipbandict.ElementAt(i).Value));
                        }

                        listBox4.SelectedIndex = 0;
                    }
                    else
                    {
                        button21.Enabled = false;
                        button22.Enabled = false;
                    }
                }
                else
                {
                    MessageBox.Show("You must configure MySQL to use this feature!");
                }
            }
            else if (tabControl1.SelectedTab == tabPage5)
            {
                if (Settings.Default.host != String.Empty && Settings.Default.port != String.Empty && Settings.Default.username != String.Empty && Settings.Default.password != String.Empty && Settings.Default.logondb != String.Empty && Settings.Default.chardb != String.Empty && Settings.Default.worlddb != String.Empty)
                {
                    listBox5.Items.Clear();

                    bnamelist = GetBannedNames();

                    if (bnamelist != null)
                    {
                        for (int i = 0; i < bnamelist.Count; i++)
                        {
                            listBox5.Items.Add(bnamelist[i]);
                        }

                        listBox5.SelectedIndex = 0;
                    }
                    else
                    {
                        button23.Visible = false;
                        button24.Enabled = false;
                    }
                }
                else
                {
                    MessageBox.Show("You must configure MySQL to use this feature!");
                }
            }
            else if (tabControl1.SelectedTab == tabPage13)
            {
                if (Settings.Default.host != String.Empty && Settings.Default.port != String.Empty && Settings.Default.username != String.Empty && Settings.Default.password != String.Empty && Settings.Default.logondb != String.Empty && Settings.Default.chardb != String.Empty && Settings.Default.worlddb != String.Empty)
                {

                    listBox2.Focus();

                    listBox2.KeyDown += new KeyEventHandler(listBox2_KeyDown);

                    listBox2.Items.Clear();

                    chardict = GetCharacters();

                    if (chardict != null)
                    {
                        for (int i = 0; i < chardict["name"].Count; i++)
                        {
                            listBox2.Items.Add(chardict["name"][i]);
                        }

                        listBox2.SelectedIndex = 0;
                    }
                }
                else
                {
                    MessageBox.Show("You must configure MySQL to use this feature!");
                }
            }
            else if (tabControl1.SelectedTab == tabPage17)
            {

                if (comboBox13.Items.Count != 0)
                    comboBox13.Items.Clear();

                chardict = GetCharacters();

                textBox26.KeyPress += new KeyPressEventHandler(textBox26_KeyPress);

                if (chardict != null)
                {
                    for (int i = 0; i < chardict["name"].Count; i++)
                    {
                        comboBox13.Items.Add(chardict["name"][i]);
                    }

                    comboBox13.SelectedIndex = 0;
                }
            }
            else if (tabControl1.SelectedTab == creatorTabPage)
            {
                if (creatorTabControl.SelectedTab == itemsTabPage)
                {
                    if (itemsTabControl.SelectedTab == itemDetailsTabPage)
                    {

                    }
                }
            }
        }

        private void textBox26_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void listBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Right)
            {
                if (listBox3.Items.Count != 0)
                {
                    listBox3.Focus();
                    listBox3.SelectedIndex = 0;
                    e.Handled = true;
                }
            }
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

            //listBox3.Focus();

            try
            {
                if (chardict != null)
                {
                    listBox3.Items.Clear();

                    label51.Text = String.Format("Account: {0}", chardict["acctname"][listBox2.SelectedIndex]);

                    itemlist = GetPlayerItems(listBox2.SelectedIndex);

                    listBox3.SelectedIndexChanged += new EventHandler(listBox3_SelectedIndexChanged);

                    for (int i = 0; i < itemlist.Count; i++)
                    {
                        for (int x = 0; x < itemlist[i].Count; x++)
                        {
                            listBox3.Items.Add(itemlist[i].ElementAt(x).Value);
                        }
                    }

                    button18.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

            button18.Enabled = true;

            listBox3.KeyDown += new KeyEventHandler(listBox3_KeyDown);

            //label52.Text = String.Format("Item Entry ID: {0}", itemlist[listBox3.SelectedIndex].ElementAt(0).Value);
        }

        private void listBox3_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                e.Handled = true;
                listBox2.Focus();
                listBox3.SelectedIndex = -1;
            }
        }

        private List<Dictionary<string, string>> GetPlayerItems(int index)
        {
            try
            {

                string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.chardb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                MySqlConnection mConnection = new MySqlConnection(connection);

                mConnection.Open();

                string qry = String.Format("SELECT * FROM playeritems WHERE ownerguid='{0}' LIMIT 1000", chardict["guid"][listBox2.SelectedIndex]);

                MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                MySqlDataReader Reader = cmd.ExecuteReader();

                List<string> entry = new List<string>();
                List<string> guid = new List<string>();

                while (Reader.Read())
                {
                    entry.Add(Reader.GetString("entry"));
                    guid.Add(Reader.GetString("guid"));
                }

                Reader.Close();

                mConnection.Close();
                mConnection.Dispose();

                connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.worlddb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                if (guid.Count != entry.Count)
                {
                    return null;
                }

                List<Dictionary<string, string>> templist = new List<Dictionary<string, string>>();

                for (int i = 0; i < guid.Count; i++)
                {

                    Dictionary<string, string> tempdict = new Dictionary<string, string>();

                    mConnection = new MySqlConnection(connection);

                    mConnection.Open();

                    qry = String.Format("SELECT * FROM items WHERE entry='{0}' LIMIT 1000", entry.ElementAt(i));

                    cmd = new MySqlCommand(qry, mConnection);

                    Reader = cmd.ExecuteReader();

                    string name = String.Empty;

                    while (Reader.Read())
                    {
                        name = Reader.GetString("name1");
                    }


                    if (name == String.Empty)
                    {
                        tempdict.Add(guid.ElementAt(i), "Item Not Found");
                    }
                    else
                    {
                        tempdict.Add(guid.ElementAt(i), name);
                    }

                    templist.Add(tempdict);

                    Reader.Close();

                    mConnection.Close();
                    mConnection.Dispose();
                }

                return templist;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return null;
        }

        private void SetCharacters()
        {
            try
            {
                int index = listBox1.SelectedIndex;

                label14.Text = String.Format("Account ID: {0} ({1})", chardict["acct"][index], chardict["acctname"][index]);

                comboBox4.SelectedIndex = int.Parse(chardict["banned"][index]);

                if (chardict["gender"][index] == "False")
                {
                    comboBox5.SelectedIndex = 0;
                }
                else
                {
                    comboBox5.SelectedIndex = 1;
                }

                textBox7.Text = chardict["name"][index];

                int total = int.Parse(chardict["gold"][index]);

                int gold = total / 10000;

                total = total % 10000;

                int silver = total / 100;

                int copper = total % 100;

                charactersGoldTextBox.Text = Convert.ToString(gold);
                charactersSilverNumericUpDown.Value = silver;
                charactersCopperNumericUpDown.Value = copper;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {
                if (chardict != null)
                {
                    SetCharacters();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {

                int totalmoney = (Convert.ToInt32(charactersCopperNumericUpDown.Value) % 100) + (Convert.ToInt32(charactersSilverNumericUpDown.Value) * 100) + (int.Parse(charactersGoldTextBox.Text) * 10000);

                string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.chardb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                MySqlConnection mConnection = new MySqlConnection(connection);

                mConnection.Open();

                string qry = String.Format("UPDATE characters SET name='{0}', banned='{1}', gender='{2}', gold='{3}' WHERE name='{4}' AND acct='{5}'", textBox7.Text, comboBox4.SelectedIndex, comboBox5.SelectedIndex, totalmoney, chardict["name"][listBox1.SelectedIndex], chardict["acct"][listBox1.SelectedIndex]);

                MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                cmd.ExecuteReader();

                MessageBox.Show(String.Format("Character {0} Saved!", textBox7.Text));

                int currentIndex = listBox1.SelectedIndex;

                listBox1.Items.Clear();

                chardict = GetCharacters();

                for (int i = 0; i < chardict["name"].Count; i++)
                {
                    listBox1.Items.Add(chardict["name"][i]);
                }

                if (listBox1.Items.Count != 0)
                {
                    listBox1.SelectedIndex = currentIndex;
                }

                mConnection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            acctdict = GetCharacters();
            SetCharacters();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void arcEmuLocationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (Settings.Default.arcemulogon != String.Empty)
            {

                bool exists = false;
                int pid = 0;

                foreach (Process p in Process.GetProcesses())
                {
                    if (p.ProcessName.Contains("arcemu-logonserver"))
                    {
                        exists = true;
                        pid = p.Id;
                    }
                }

                if (exists == false)
                {
                    Thread thread = new Thread(new ParameterizedThreadStart(ExecuteLogonServer));
                    thread.IsBackground = true;
                    thread.Priority = ThreadPriority.Normal;

                    thread.Start();

                    button27.Visible = true;
                    button5.Visible = false;
                }
                else
                {
                    DialogResult result = MessageBox.Show("Logon-Server is already running! Kill it?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        Process p = Process.GetProcessById(pid);

                        p.Kill();
                    }
                }
            }
            else
            {
                MessageBox.Show("You must set the location to arcemu-logonserver.exe first!", "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExecuteLogonServer(object obj)
        {

            try
            {

                System.Diagnostics.ProcessStartInfo procStartInfo = new ProcessStartInfo();

                procStartInfo.RedirectStandardOutput = true;
                procStartInfo.RedirectStandardInput = true;

                string dirname = Path.GetDirectoryName(Settings.Default.arcemulogon);

                procStartInfo.WorkingDirectory = dirname;

                procStartInfo.FileName = Settings.Default.arcemulogon;

                procStartInfo.UseShellExecute = false;

                procStartInfo.CreateNoWindow = true;

                loginproc = new Process();

                loginproc.StartInfo = procStartInfo;
                loginproc.Start();

                loginproc.EnableRaisingEvents = true;

                loginprocid = loginproc.Id;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (Settings.Default.arcemuworld != String.Empty)
            {

                if (loginprocid != 0)
                {

                    //Check if authserver is running before starting the world server

                    bool exists = false;

                    foreach (Process p in Process.GetProcesses())
                    {
                        if (p.Id == loginprocid && loginprocid != 0)
                        {
                            exists = true;
                        }
                    }

                    if (exists == true)
                    {

                        if (!loginproc.HasExited)
                        {

                            bool serverExists = false;
                            int pid = 0;

                            foreach (Process p in Process.GetProcesses())
                            {
                                if (p.ProcessName.Contains("arcemu-world"))
                                {
                                    serverExists = true;
                                    pid = p.Id;
                                }
                            }

                            if (serverExists == false)
                            {

                                Thread thread = new Thread(new ParameterizedThreadStart(ExecuteWorldServer));
                                thread.IsBackground = true;
                                thread.Priority = ThreadPriority.AboveNormal;

                                thread.Start();

                                button7.Visible = false;
                                button28.Visible = true;
                            }
                            else
                            {
                                DialogResult result = MessageBox.Show("World Server is already running! Kill it?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                                if (result == DialogResult.Yes)
                                {
                                    Process p = Process.GetProcessById(pid);

                                    p.Kill();
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Logon Server must be opened first!", "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Logon Server must be opened first!", "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("You must set where arcemu-world.exe is located.", "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExecuteWorldServer(object obj)
        {
            try
            {
                System.Diagnostics.ProcessStartInfo procStartInfo = new ProcessStartInfo();

                string dirname = Path.GetDirectoryName(Settings.Default.arcemuworld);

                procStartInfo.WorkingDirectory = dirname;

                procStartInfo.FileName = Settings.Default.arcemuworld;

                procStartInfo.UseShellExecute = true;

                if (Settings.Default.showworld == true)
                {
                    procStartInfo.WindowStyle = ProcessWindowStyle.Normal;
                }
                else
                {
                    procStartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                }

                worldproc = new Process();

                worldproc.StartInfo = procStartInfo;
                worldproc.Start();

                worldproc.EnableRaisingEvents = true;

                worldprocid = worldproc.Id;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tabControl3_SelectedIndexChanged(object sender, EventArgs args)
        {
            if (tabControl3.SelectedTab == tabPage11)
            {

            }
            else if (tabControl3.SelectedTab == tabPage14)
            {
                comboBox6.SelectedIndex = 1; //Limits Enabled Combo Box
            }
            else if (tabControl3.SelectedTab == tabPage16)
            {
                comboBox7.SelectedIndex = 1; //Start on GM Island Combo Box
                comboBox12.SelectedIndex = 1; //Collision Combo Box
            }
        }

        private void tabControl2_SelectedIndexChanged(object sender, EventArgs args)
        {
            if (tabControl2.SelectedTab == tabPage8)
            {
                if (tabControl3.SelectedTab == tabPage11)
                {
                    tabControl3.TabPages.Remove(tabPage12); //Rates
                    tabControl3.TabPages.Remove(tabPage14); //Limits
                    tabControl3.TabPages.Remove(tabPage16); //Other
                    tabControl3.TabPages.Remove(tabPage15); //Finish
                }
            }
            else if (tabControl2.SelectedTab == tabPage10)
            {
                comboBox8.SelectedIndex = 0;
                comboBox9.SelectedIndex = 1;
                comboBox10.SelectedIndex = 1;
                comboBox11.SelectedIndex = 1;
            }
        }

        private void tabPage14_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e) //Save Logon Config
        {

            if (textBox9.Text != String.Empty && textBox10.Text != String.Empty)
            {

                StreamReader textReader;

                try
                {
                    Stream theResource = this.GetType().Assembly.GetManifestResourceStream("ArcEmu_Manager.Logon_New.txt");
                    textReader = new StreamReader(theResource);

                    string configFile = String.Format(textReader.ReadToEnd(), Settings.Default.host, Settings.Default.username, Settings.Default.password, Settings.Default.logondb, Settings.Default.port,
                        textBox9.Text, textBox10.Text);

                    textReader.Close();

                    string dirname = Path.GetDirectoryName(Settings.Default.arcemulogon);

                    StreamWriter writer = new StreamWriter(String.Format("{0}\\configs\\logontest.conf", dirname));

                    writer.WriteLine(configFile);

                    writer.Close();

                    MessageBox.Show("Saved Config File!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("You must fill out all fields!", "Error");
            }
        }

        private void button8_Click(object sender, EventArgs e) //Save Logon Default Config
        {
            StreamReader textReader;

            try
            {
                Stream theResource = this.GetType().Assembly.GetManifestResourceStream("ArcEmu_Manager.Logon_Old.txt");
                textReader = new StreamReader(theResource);

                string configFile = textReader.ReadToEnd();

                textReader.Close();

                string dirname = Path.GetDirectoryName(Settings.Default.arcemulogon);

                StreamWriter writer = new StreamWriter(String.Format("{0}\\configs\\logontest.conf", dirname));

                writer.WriteLine(configFile);

                writer.Close();

                MessageBox.Show("Reverted To Default Configuration!");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {

            if (textBox11.Text != String.Empty)
            {
                if (!tabControl3.Contains(tabPage12))
                {
                    tabControl3.TabPages.Add(tabPage12);
                    tabControl3.SelectedIndex = tabControl3.TabPages.IndexOf(tabPage12);
                }
                else
                {
                    tabControl3.SelectedTab = tabPage12;
                }
            }
            else
            {
                MessageBox.Show("You must fill out all fields!", "Error");
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (((Control)numericUpDown1).Text == String.Empty || ((Control)numericUpDown2).Text == String.Empty || ((Control)numericUpDown3).Text == String.Empty || ((Control)numericUpDown4).Text == String.Empty
                || ((Control)numericUpDown5).Text == String.Empty || ((Control)numericUpDown6).Text == String.Empty || ((Control)numericUpDown7).Text == String.Empty ||
                ((Control)numericUpDown8).Text == String.Empty || ((Control)numericUpDown9).Text == String.Empty)
            {
                MessageBox.Show("All fields must be filled out!", "Error");
            }
            else if (textBox12.Text == String.Empty)
            {
                MessageBox.Show("All fields must be filled out!", "Error");
            }
            else
            {
                if (!tabControl3.Contains(tabPage14))
                {
                    tabControl3.TabPages.Add(tabPage14);
                    tabControl3.SelectedIndex = tabControl3.TabPages.IndexOf(tabPage14);
                }
                else
                {
                    tabControl3.SelectedTab = tabPage14;
                }
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {

            if (textBox13.Text != String.Empty && textBox14.Text != String.Empty && textBox15.Text != String.Empty)
            {
                if (!tabControl3.Contains(tabPage16))
                {
                    tabControl3.TabPages.Add(tabPage16);
                    tabControl3.SelectedIndex = tabControl3.TabPages.IndexOf(tabPage16);
                }
                else
                {
                    tabControl3.SelectedTab = tabPage16;
                }
            }
            else
            {
                MessageBox.Show("All fields must be filled out!", "Error");
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {

            if (textBox16.Text != String.Empty)
            {
                tabControl3.TabPages.Add(tabPage15);
                tabControl3.SelectedIndex = tabControl3.TabPages.IndexOf(tabPage15);

                tabControl3.TabPages.Remove(tabPage11);
                tabControl3.TabPages.Remove(tabPage12);
                tabControl3.TabPages.Remove(tabPage14);
                tabControl3.TabPages.Remove(tabPage16);
            }
            else
            {
                MessageBox.Show("All fields must be filled out!", "Error");
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            tabControl3.TabPages.Remove(tabPage15);

            tabControl3.TabPages.Add(tabPage11);

            tabControl3.SelectedIndex = tabControl3.TabPages.IndexOf(tabPage11);

            //Remote Password
            textBox11.Text = String.Empty;

            //Rates
            textBox12.Text = Convert.ToString(300000);
            numericUpDown1.Value = 1;
            numericUpDown2.Value = 1;
            numericUpDown3.Value = 1;
            numericUpDown4.Value = 1;
            numericUpDown5.Value = 1;
            numericUpDown6.Value = 1;
            numericUpDown7.Value = 1;
            numericUpDown8.Value = 1;
            numericUpDown9.Value = 1;

            //Limits
            textBox13.Text = Convert.ToString(30000); //Max Spell Damage
            textBox14.Text = Convert.ToString(100000); //Max Health
            textBox15.Text = Convert.ToString(80000); //Max Mana
            comboBox6.SelectedIndex = 1; //Limits Enabled

            //Other
            comboBox7.SelectedIndex = 1; //GM Island Start Enabled
            comboBox12.SelectedIndex = 1; //Collision Enabled
            textBox16.Text = "gm_sync_channel"; //GM Channel

        }

        private void button13_Click(object sender, EventArgs e)
        {
            StreamReader textReader;

            try
            {
                Stream theResource = this.GetType().Assembly.GetManifestResourceStream("ArcEmu_Manager.World_New.txt");
                textReader = new StreamReader(theResource);

                string configFile = String.Format(textReader.ReadToEnd(), Settings.Default.host, Settings.Default.username, Settings.Default.password, Settings.Default.worlddb, Settings.Default.port,
                    Settings.Default.host, Settings.Default.username, Settings.Default.password, Settings.Default.chardb, Settings.Default.port, comboBox12.SelectedIndex, numericUpDown1.Value,
                    numericUpDown3.Value, numericUpDown4.Value, numericUpDown5.Value, numericUpDown6.Value, numericUpDown7.Value, numericUpDown8.Value, numericUpDown9.Value, numericUpDown2.Value,
                    textBox12.Text, textBox13.Text, textBox14.Text, textBox15.Text, comboBox7.SelectedIndex, textBox16.Text);

                textReader.Close();

                string dirname = Path.GetDirectoryName(Settings.Default.arcemulogon);

                StreamWriter writer = new StreamWriter(String.Format("{0}\\configs\\worldtest.conf", dirname));

                writer.WriteLine(configFile);

                writer.Close();

                MessageBox.Show("Saved Config!");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void textBox12_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void textBox13_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void textBox14_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void textBox15_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void textBox19_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (textBox17.Text != String.Empty && textBox18.Text != String.Empty && textBox19.Text != String.Empty)
            {
                StreamReader textReader;

                try
                {
                    Stream theResource = this.GetType().Assembly.GetManifestResourceStream("ArcEmu_Manager.Realm_New.txt");
                    textReader = new StreamReader(theResource);

                    string configFile = String.Format(textReader.ReadToEnd(), textBox17.Text, textBox18.Text, textBox19.Text);

                    textReader.Close();

                    string dirname = Path.GetDirectoryName(Settings.Default.arcemulogon);

                    StreamWriter writer = new StreamWriter(String.Format("{0}\\configs\\realmtest.conf", dirname));

                    writer.WriteLine(configFile);

                    writer.Close();

                    MessageBox.Show("Saved Config!");

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("All fields must be filled out!", "Error");
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (((Control)numericUpDown10).Text != String.Empty && textBox20.Text != String.Empty && textBox21.Text != String.Empty)
            {
                StreamReader textReader;

                try
                {
                    Stream theResource = this.GetType().Assembly.GetManifestResourceStream("ArcEmu_Manager.Optional_New.txt");
                    textReader = new StreamReader(theResource);

                    string configFile = String.Format(textReader.ReadToEnd(), numericUpDown10.Value, comboBox8.SelectedIndex, comboBox9.SelectedIndex, textBox20.Text, textBox21.Text, comboBox10.SelectedIndex,
                        comboBox11.SelectedIndex);

                    textReader.Close();

                    string dirname = Path.GetDirectoryName(Settings.Default.arcemulogon);

                    StreamWriter writer = new StreamWriter(String.Format("{0}\\configs\\optionaltest.conf", dirname));

                    writer.WriteLine(configFile);

                    writer.Close();

                    MessageBox.Show("Saved Config!");

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("All fields must be filled out!", "Error");
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (listBox3.SelectedIndex != -1)
            {
                try
                {

                    string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.chardb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                    MySqlConnection mConnection = new MySqlConnection(connection);

                    mConnection.Open();

                    string qry = String.Format("DELETE FROM playeritems WHERE guid='{0}' AND ownerguid='{1}'", itemlist[listBox3.SelectedIndex].ElementAt(0).Key, chardict["guid"][listBox2.SelectedIndex]);

                    MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                    cmd.ExecuteReader();

                    mConnection.Close();
                    mConnection.Dispose();

                    int lastindex = listBox3.SelectedIndex;

                    listBox3.Items.RemoveAt(listBox3.SelectedIndex);

                    listBox3.SelectedIndex = lastindex - 1;

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {

            lastindex = listBox3.SelectedIndex;

            Form5 form5 = new Form5();

            form5.Show();

            form5.FormClosing += new FormClosingEventHandler(form5_FormClosing);
        }

        private void form5_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {

                Form5 form5 = (Form5)sender;

                if (form5.getTextBoxValue() != String.Empty && form5.getTextBoxValue() != null)
                {

                    string entryid = form5.getTextBoxValue();

                    string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.chardb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                    MySqlConnection mConnection = new MySqlConnection(connection);

                    mConnection.Open();

                    string qry = String.Format("INSERT INTO playeritems (ownerguid, entry, count, randomsuffix, enchantments) VALUES ('{0}', '{1}', '1', '0', '')",
                        chardict["guid"][listBox2.SelectedIndex], entryid);

                    MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                    cmd.ExecuteReader();

                    mConnection.Close();
                    mConnection.Dispose();

                    string itemname = String.Empty;

                    connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.worlddb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                    mConnection = new MySqlConnection(connection);

                    mConnection.Open();

                    qry = String.Format("SELECT * FROM items WHERE entry='{0}'", entryid);

                    cmd = new MySqlCommand(qry, mConnection);

                    MySqlDataReader Reader = cmd.ExecuteReader();

                    while (Reader.Read())
                    {
                        itemname = Reader.GetString("name1");
                    }

                    Reader.Close();

                    mConnection.Close();
                    mConnection.Dispose();

                    listBox3.Items.Add(itemname);

                    listBox3.SelectedIndex = listBox3.Items.IndexOf(itemname);

                    itemlist = GetPlayerItems(listBox3.Items.IndexOf(itemname));
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();

            form6.Show();

            form6.FormClosing += new FormClosingEventHandler(form6_FormClosing);
        }

        private void form6_FormClosing(object sender, FormClosingEventArgs e)
        {

            Form6 form6 = (Form6)sender;

            try
            {
                if (form6.GetItem() != null && form6.buttonPressed == true)
                {

                    string itemname = form6.GetItem().ElementAt(0).Key;
                    string itementry = form6.GetItem().ElementAt(0).Value;

                    string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.chardb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                    MySqlConnection mConnection = new MySqlConnection(connection);

                    mConnection.Open();

                    string qry = String.Format("INSERT INTO playeritems (ownerguid, entry, count, randomsuffix, enchantments) VALUES ('{0}', '{1}', '1', '0', '')",
                        chardict["guid"][listBox2.SelectedIndex], itementry);

                    MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                    cmd.ExecuteReader();

                    mConnection.Close();
                    mConnection.Dispose();

                    listBox3.Items.Add(itemname);

                    listBox3.SelectedIndex = listBox3.Items.Count - 1;

                    itemlist = GetPlayerItems(listBox3.Items.IndexOf(itemname));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private Dictionary<string, string> GetIPBans()
        {
            try
            {
                string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.logondb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                MySqlConnection mConnection = new MySqlConnection(connection);

                mConnection.Open();

                string qry = "SELECT * FROM ipbans";

                MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                MySqlDataReader Reader = cmd.ExecuteReader();

                Dictionary<string, string> tempdict = new Dictionary<string, string>();

                while (Reader.Read())
                {
                    tempdict.Add(Reader.GetString("ip"), Reader.GetString("banreason"));
                }

                if (tempdict.Count == 0)
                    return null;

                button21.Enabled = true;
                button22.Enabled = true;

                mConnection.Close();
                mConnection.Dispose();

                return tempdict;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return null;
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
            if (textBox22.Text != String.Empty && textBox23.Text != String.Empty)
            {
                try
                {
                    string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.logondb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                    MySqlConnection mConnection = new MySqlConnection(connection);

                    mConnection.Open();

                    string qry = String.Format("INSERT INTO ipbans (ip, expire, banreason) VALUES ('{0}', '0', '{1}')", textBox22.Text, textBox23.Text);

                    MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                    cmd.ExecuteReader();

                    mConnection.Close();
                    mConnection.Dispose();

                    listBox4.Items.Add(String.Format("{0} ({1})", textBox22.Text, textBox23.Text));

                    ipbandict = GetIPBans();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("You must fill out all fields!", "Error");
            }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            if (listBox4.SelectedIndex != -1)
            {
                try
                {
                    string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.logondb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                    MySqlConnection mConnection = new MySqlConnection(connection);

                    mConnection.Open();

                    string qry = String.Format("DELETE FROM ipbans WHERE ip='{0}'", ipbandict.ElementAt(listBox4.SelectedIndex).Key);

                    MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                    cmd.ExecuteReader();

                    mConnection.Close();
                    mConnection.Dispose();

                    int lastindex = listBox4.SelectedIndex;

                    listBox4.Items.RemoveAt(lastindex);

                    if (listBox4.Items.Count == 0)
                    {
                        button21.Enabled = false;
                        button22.Enabled = false;
                    }
                    else
                        listBox4.SelectedIndex = listBox4.SelectedIndex - 1;

                    ipbandict = GetIPBans();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            try
            {
                string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.logondb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                MySqlConnection mConnection = new MySqlConnection(connection);

                mConnection.Open();

                string qry = "TRUNCATE TABLE ipbans;";

                MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                cmd.ExecuteReader();

                mConnection.Close();
                mConnection.Dispose();

                listBox4.Items.Clear();

                ipbandict = GetIPBans();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private List<string> GetBannedNames()
        {
            try
            {
                string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.chardb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                MySqlConnection mConnection = new MySqlConnection(connection);

                mConnection.Open();

                string qry = "SELECT * FROM banned_names";

                MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                MySqlDataReader Reader = cmd.ExecuteReader();

                List<string> bname = new List<string>();

                while (Reader.Read())
                {
                    bname.Add(Reader.GetString("name"));
                }

                if (bname.Count == 0)
                    return null;

                button23.Enabled = true;
                button24.Enabled = true;

                mConnection.Close();
                mConnection.Dispose();

                return bname;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return null;
            }
        }

        private void button25_Click(object sender, EventArgs e)
        {
            if (textBox25.Text != String.Empty)
            {
                try
                {
                    string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.chardb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                    MySqlConnection mConnection = new MySqlConnection(connection);

                    mConnection.Open();

                    string qry = String.Format("INSERT INTO banned_names (name) VALUES ('{0}')", textBox25.Text);

                    MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                    cmd.ExecuteReader();

                    mConnection.Close();
                    mConnection.Dispose();

                    listBox5.Items.Add(textBox25.Text);

                    listBox5.SelectedIndex = listBox5.Items.Count - 1;

                    bnamelist = GetBannedNames();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("You must fill out all fields!", "Error");
            }
        }

        private void button24_Click(object sender, EventArgs e)
        {
            if (listBox5.SelectedIndex != -1)
            {
                try
                {

                    string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.chardb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                    MySqlConnection mConnection = new MySqlConnection(connection);

                    mConnection.Open();

                    string qry = String.Format("DELETE FROM banned_names WHERE name='{0}'", bnamelist[listBox5.SelectedIndex]);

                    MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                    cmd.ExecuteReader();

                    mConnection.Close();
                    mConnection.Dispose();

                    int lastindex = listBox5.SelectedIndex;

                    listBox5.Items.Clear();

                    bnamelist = GetBannedNames();

                    if (bnamelist != null)
                    {
                        listBox5.Items.AddRange(bnamelist.ToArray());
                    }

                    if (listBox5.Items.Count == 0)
                    {
                        button23.Enabled = false;
                        button24.Enabled = false;
                    }
                    else
                        listBox5.SelectedIndex = lastindex - 1;

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button23_Click(object sender, EventArgs e)
        {
            try
            {
                string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.chardb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                MySqlConnection mConnection = new MySqlConnection(connection);

                mConnection.Open();

                string qry = "TRUNCATE TABLE banned_names;";

                MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                cmd.ExecuteReader();

                mConnection.Close();
                mConnection.Dispose();

                listBox5.Items.Clear();

                bnamelist = GetBannedNames();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button27_Click(object sender, EventArgs e)
        {

            bool exists = false;

            foreach (Process p in Process.GetProcesses())
            {
                if (p.Id == loginprocid && loginprocid != 0)
                {
                    exists = true;
                }
            }
            if (exists == true)
            {
                if (!loginproc.HasExited)
                {
                    loginproc.Kill();

                    loginproc.Close();
                    loginproc.Dispose();

                    button27.Visible = false;
                    button5.Visible = true;
                }
            }
            else
            {
                button27.Visible = false;
                button5.Visible = true;

                MessageBox.Show("Logon Server is Not Running!");
            }
        }

        private void button28_Click(object sender, EventArgs e)
        {
            bool exists = false;

            foreach (Process p in Process.GetProcesses())
            {
                if (p.Id == worldprocid && worldprocid != 0)
                {
                    exists = true;
                }
            }
            if (exists == true)
            {
                if (!worldproc.HasExited)
                {
                    worldproc.Kill();

                    worldproc.Close();
                    worldproc.Dispose();

                    button28.Visible = false;
                    button7.Visible = true;
                }
            }
            else
            {
                button28.Visible = false;
                button7.Visible = true;

                MessageBox.Show("World Server is Not Running!");
            }
        }

        private void otherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7();

            form7.Show();
        }

        private void button29_Click(object sender, EventArgs e)
        {
            Form8 form8 = new Form8();

            form8.FormClosing += new FormClosingEventHandler(form8_FormClosing);

            form8.Show();
        }

        private void form8_FormClosing(object sender, EventArgs e)
        {
            Form8 form8 = (Form8)sender;

            string acctname = form8.GetAccountName();
            string pword = form8.GetAccountPassword();
            string gmpermissions = form8.GetGMPermissions();
            string flags = form8.GetFlags();
            string email = form8.GetEmail();

            if (acctname != string.Empty)
            {
                acctdict = GetAccounts();
                comboBox1.Items.Add(acctname);
                comboBox1.SelectedIndex = comboBox1.Items.Count - 1;
                setAccounts();
            }
        }

        private void button30_Click(object sender, EventArgs e)
        {
            if (comboBox1.Items.Count != 0)
            {
                string confirm = String.Format("Are you sure you want to delete the account: {0}", acctdict["login"][comboBox1.SelectedIndex]);

                if (MessageBox.Show(this, confirm, "Confirm", MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    try
                    {

                        string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.logondb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                        MySqlConnection mConnection = new MySqlConnection(connection);

                        mConnection.Open();

                        string qry = String.Format("DELETE FROM accounts WHERE acct = '{0}'", acctdict["acct"][comboBox1.SelectedIndex]);

                        MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                        MySqlDataReader Reader = cmd.ExecuteReader();

                        mConnection.Close();
                        mConnection.Dispose();

                        comboBox1.Items.RemoveAt(comboBox1.SelectedIndex);

                        if (comboBox1.Items.Count != 0)
                        {
                            comboBox1.SelectedIndex = comboBox1.Items.Count - 1;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void button31_Click(object sender, EventArgs e)
        {

            string confirm = String.Format("Are you sure you want to delete the character: {0}", chardict["name"][listBox1.SelectedIndex]);

            if (MessageBox.Show(this, confirm, "Confirm", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                try
                {
                    string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.chardb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                    MySqlConnection mConnection = new MySqlConnection(connection);

                    mConnection.Open();

                    string qry = String.Format("DELETE FROM characters WHERE guid = '{0}'", chardict["guid"][listBox1.SelectedIndex]);

                    MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                    cmd.ExecuteReader();

                    mConnection.Close();

                    MessageBox.Show(String.Format("Character {0} Removed!", textBox7.Text));

                    int currentIndex = listBox1.SelectedIndex;

                    listBox1.Items.Clear();

                    chardict = GetCharacters();

                    for (int i = 0; i < chardict["name"].Count; i++)
                    {
                        listBox1.Items.Add(chardict["name"][i]);
                    }

                    if (listBox1.Items.Count != 0)
                    {
                        listBox1.SelectedIndex = currentIndex - 1;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button33_Click(object sender, EventArgs e)
        {
            Form9 form9 = new Form9();

            form9.Show();

            form9.FormClosing += new FormClosingEventHandler(form9_FormClosing);
        }

        private void form9_FormClosing(object sender, FormClosingEventArgs e)
        {

            Form9 form9 = (Form9)sender;

            try
            {
                if (form9.GetItem() != null && form9.buttonPressed == true)
                {

                    string itementry = form9.GetItem().ElementAt(0).Value;

                    textBox26.Text = itementry;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button32_Click(object sender, EventArgs e)
        {
            try
            {
                if (Settings.Default.host != String.Empty && Settings.Default.port != String.Empty && Settings.Default.username != String.Empty && Settings.Default.password != String.Empty && Settings.Default.logondb != String.Empty && Settings.Default.chardb != String.Empty && Settings.Default.worlddb != String.Empty)
                {
                    if (textBox27.Text != String.Empty && richTextBox1.Text != String.Empty && mailGoldTextBox.Text != String.Empty && textBox26.Text != String.Empty &&
                        ((Control)mailSilverNumericUpDown).Text != String.Empty && ((Control)mailCopperNumericUpDown).Text != String.Empty)
                    {

                        int totalmoney = (Convert.ToInt32(mailCopperNumericUpDown.Value) % 100) + (Convert.ToInt32(mailSilverNumericUpDown.Value) * 100) + (int.Parse(mailGoldTextBox.Text) * 10000);

                        string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.chardb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                        MySqlConnection mConnection = new MySqlConnection(connection);

                        mConnection.Open();

                        string values = String.Format("('0', '{0}', '{1}', '{2}', '61', '{3}', '{4}', '1')", chardict["guid"][comboBox13.SelectedIndex], textBox27.Text,
                            richTextBox1.Text, totalmoney, textBox26.Text);

                        string qry = String.Format("INSERT INTO mailbox_insert_queue (sender_guid, receiver_guid, subject, body, stationary, money, item_id, item_stack) VALUES {0}", values);

                        MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                        cmd.ExecuteReader();

                        mConnection.Close();

                        MessageBox.Show("Message Sent!");
                    }
                    else
                    {
                        MessageBox.Show("You must fill out all fields!");
                    }
                }
                else
                {
                    MessageBox.Show("You must configure MySQL to use this feature!");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button34_Click(object sender, EventArgs e)
        {
            if (chardict != null)
            {
                comboBox13.SelectedIndex = 0;
            }

            textBox27.Text = String.Empty;
            richTextBox1.Text = String.Empty;
            textBox26.Text = String.Empty;
            mailGoldTextBox.Text = Convert.ToString(0);
            mailSilverNumericUpDown.Value = 0;
            mailCopperNumericUpDown.Value = 0;
        }

        private void mailGoldTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void button35_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                richTextBox2.Text = String.Empty;

                logdirname = Path.GetDirectoryName(openFileDialog1.FileName);

                logfile = Path.Combine(logdirname, openFileDialog1.FileName);

                string text = String.Empty;

                try
                {
                    using (FileStream fileStream = new FileStream(
                        logfile,
                        FileMode.Open,
                        FileAccess.Read,
                        FileShare.ReadWrite))
                    {
                        using (StreamReader streamReader = new StreamReader(fileStream))
                        {
                            text = streamReader.ReadToEnd();
                        }

                        richTextBox2.Text = text;
                        richTextBox2.SelectionLength = 0;
                        richTextBox2.SelectionStart = richTextBox2.Text.Length;
                        richTextBox2.ScrollToCaret();

                        _watchFile = new FileSystemWatcher();

                        _watchFile.Path = logdirname;
                        _watchFile.Changed += new FileSystemEventHandler(_watchFile_Changed);
                        _watchFile.EnableRaisingEvents = true;

                        _watchFolder = new FileSystemWatcher();
                        _watchFolder.Path = logdirname;
                        _watchFolder.Created += new FileSystemEventHandler(watcher_Created);
                        _watchFolder.EnableRaisingEvents = true;
                        //_watchFolder.NotifyFilter = NotifyFilters.LastWrite;
                        _watchFolder.Filter = "*.log";

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void _watchFile_Changed(object sender, System.IO.FileSystemEventArgs e)
        {
            if (e.FullPath == logfile)
            {
                try
                {
                    _watchFile.EnableRaisingEvents = false;
                }

                finally
                {

                    _watchFile.EnableRaisingEvents = true;

                    string text = String.Empty;

                    try
                    {
                        using (FileStream fileStream = new FileStream(
                        logfile,
                        FileMode.Open,
                        FileAccess.Read,
                        FileShare.ReadWrite))
                        {
                            using (StreamReader streamReader = new StreamReader(fileStream))
                            {
                                text = streamReader.ReadToEnd();
                            }

                            richTextBox2.Text = text;
                            richTextBox2.SelectionLength = 0;
                            richTextBox2.SelectionStart = richTextBox2.Text.Length;
                            richTextBox2.ScrollToCaret();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void watcher_Created(object sender, FileSystemEventArgs e)
        {

            if (e.ChangeType == WatcherChangeTypes.Created)
            {
                if (MessageBox.Show("A new log file has appeared. Change to that file?", "New File", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    logfile = e.FullPath;
                    string text = String.Empty;

                    try
                    {
                        using (FileStream fileStream = new FileStream(
                            logfile,
                            FileMode.Open,
                            FileAccess.Read,
                            FileShare.ReadWrite))
                        {
                            using (StreamReader streamReader = new StreamReader(fileStream))
                            {
                                text = streamReader.ReadToEnd();
                            }
                        }

                        richTextBox2.Invoke(new UpdateText(this.UpdateLogText), new object[] { text });
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void UpdateLogText(string message)
        {
            richTextBox2.Text += message;
        }

        private void Refresh_Timer(object sender, EventArgs eArgs)
        {
            if (logfile != String.Empty)
            {

                string text = String.Empty;

                try
                {
                    using (FileStream fileStream = new FileStream(
                        logfile,
                        FileMode.Open,
                        FileAccess.Read,
                        FileShare.ReadWrite))
                    {
                        using (StreamReader streamReader = new StreamReader(fileStream))
                        {
                            text = streamReader.ReadToEnd();
                        }
                    }

                    richTextBox2.Text = text;
                    richTextBox2.SelectionLength = 0;
                    richTextBox2.SelectionStart = richTextBox2.Text.Length;
                    richTextBox2.ScrollToCaret();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void creatorTabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (creatorTabControl.SelectedTab == itemsTabPage)
            {
                if (itemsTabControl.SelectedTab == itemDetailsTabPage)
                {

                }
            }
            else if (creatorTabControl.SelectedTab == npcTabPage)
            {
                if (npcTabControl.SelectedTab == npcDetailsTabPage)
                {

                }
            }
            else if (creatorTabControl.SelectedTab == weaponsTabPage)
            {

            }
        }

        private void itemsAllClasses_CheckedChanged(object sender, EventArgs e)
        {
            if (itemsAllClasses.Checked == true)
            {
                itemsWarriorCheckBox.Checked = true;
                itemsPaladinCheckBox.Checked = true;
                itemsHunterCheckBox.Checked = true;
                itemsRogueCheckBox.Checked = true;
                itemsPriestCheckBox.Checked = true;
                itemsDruidCheckBox.Checked = true;
                itemsShamanCheckBox.Checked = true;
                itemsMageCheckBox.Checked = true;
                itemsWarlockCheckBox.Checked = true;
                itemsDeathKnightCheckBox.Checked = true;
            }
            else
            {
                itemsWarriorCheckBox.Checked = false;
                itemsPaladinCheckBox.Checked = false;
                itemsHunterCheckBox.Checked = false;
                itemsRogueCheckBox.Checked = false;
                itemsPriestCheckBox.Checked = false;
                itemsDruidCheckBox.Checked = false;
                itemsShamanCheckBox.Checked = false;
                itemsMageCheckBox.Checked = false;
                itemsWarlockCheckBox.Checked = false;
                itemsDeathKnightCheckBox.Checked = false;
            }
        }

        private void itemsAllRaces_CheckedChanged(object sender, EventArgs e)
        {
            if (itemsAllRaces.Checked == true)
            {
                itemsHumanCheckBox.Checked = true;
                itemsOrcCheckBox.Checked = true;
                itemsDwarfCheckBox.Checked = true;
                itemsNightElfCheckBox.Checked = true;
                itemsUndeadCheckBox.Checked = true;
                itemsTaurenCheckBox.Checked = true;
                itemsGnomeCheckBox.Checked = true;
                itemsTrollCheckBox.Checked = true;
                itemsBloodElfCheckBox.Checked = true;
                itemsDraeneiCheckBox.Checked = true;
            }
            else
            {
                itemsHumanCheckBox.Checked = false;
                itemsOrcCheckBox.Checked = false;
                itemsDwarfCheckBox.Checked = false;
                itemsNightElfCheckBox.Checked = false;
                itemsUndeadCheckBox.Checked = false;
                itemsTaurenCheckBox.Checked = false;
                itemsGnomeCheckBox.Checked = false;
                itemsTrollCheckBox.Checked = false;
                itemsBloodElfCheckBox.Checked = false;
                itemsDraeneiCheckBox.Checked = false;
            }
        }

        private void button39_Click(object sender, EventArgs e)
        {
            SearchItemDisplayID search = new SearchItemDisplayID();

            search.Show();

            search.FormClosing += new FormClosingEventHandler(search_FormClosing);
        }

        private void search_FormClosing(object sender, FormClosingEventArgs e)
        {
            SearchItemDisplayID search = (SearchItemDisplayID)sender;

            if (search.GetDisplayID() != String.Empty && search.buttonPressed == true)
            {
                itemDisplayidTextBox.Text = search.GetDisplayID();
            }
        }

        private void itemDetailsNextButton_Click(object sender, EventArgs e)
        {
            if (itemNameTextBox.Text != String.Empty && itemDisplayidTextBox.Text != String.Empty && itemEntryTextBox.Text != String.Empty && itemLevelTextBox.Text != String.Empty)
            {
                if (!itemsTabControl.Contains(itemRequirementsTabPage))
                {
                    itemsTabControl.TabPages.Add(itemRequirementsTabPage);
                    itemsTabControl.SelectedIndex = itemsTabControl.TabPages.IndexOf(itemRequirementsTabPage);
                }
                else
                {
                    itemsTabControl.SelectedIndex = itemsTabControl.TabPages.IndexOf(itemRequirementsTabPage);
                }
            }
            else
            {
                MessageBox.Show("You must fill out the required fields!");
            }
        }

        private void itemRequirementsNextButton_Click(object sender, EventArgs e)
        {
            if (itemRequiredLevelTextBox.Text != String.Empty && itemSkillLevelTextBox.Text != String.Empty && itemsMaxTextBox.Text != String.Empty)
            {
                if (!itemsTabControl.Contains(itemPriceTabPage))
                {
                    itemsTabControl.TabPages.Add(itemPriceTabPage);
                    itemsTabControl.SelectedIndex = itemsTabControl.TabPages.IndexOf(itemPriceTabPage);
                }
                else
                {
                    itemsTabControl.SelectedIndex = itemsTabControl.TabPages.IndexOf(itemPriceTabPage);
                }
            }
            else
            {
                MessageBox.Show("You must fill out all requried fields!");
            }
        }

        private void itemsPriceNextButton_Click(object sender, EventArgs e)
        {
            if (itemsBuyGoldTextBox.Text != String.Empty && itemsSellGoldTextBox.Text != String.Empty && ((Control)itemsBuySilverNumericUpDown).Text != String.Empty &&
                ((Control)itemsBuyCopperNumericUpDown).Text != String.Empty && ((Control)itemsSellSilverNumericUpDown).Text != String.Empty && ((Control)itemsSellCopperNumericUpDown).Text != String.Empty)
            {
                if (!itemsTabControl.Contains(itemFinishTabPage))
                {

                    itemsTabControl.TabPages.Add(itemFinishTabPage);
                    itemsTabControl.SelectedIndex = itemsTabControl.TabPages.IndexOf(itemFinishTabPage);

                    itemsTabControl.TabPages.Remove(itemDetailsTabPage);
                    itemsTabControl.TabPages.Remove(itemRequirementsTabPage);
                    itemsTabControl.TabPages.Remove(itemPriceTabPage);
                }
            }
            else
            {
                MessageBox.Show("You must fill out all of the fields!");
            }
        }

        private void itemsStartOverButton_Click(object sender, EventArgs e)
        {
            itemsTabControl.TabPages.Remove(itemRequirementsTabPage);
            itemsTabControl.TabPages.Remove(itemPriceTabPage);
            itemsTabControl.TabPages.Remove(itemFinishTabPage);

            itemsTabControl.SelectedTab = itemDetailsTabPage;

            itemsTabControl.TabPages.Add(itemDetailsTabPage);

            //Item Details

            itemNameTextBox.Text = String.Empty;
            itemQuoteTextBox.Text = String.Empty;

            itemQualityComboBox.SelectedIndex = 0;

            itemDisplayidTextBox.Text = String.Empty;
            itemEntryTextBox.Text = String.Empty;

            itemTypeComboBox.SelectedIndex = 0;
            itemBindsComboBox.SelectedIndex = 0;

            itemLevelTextBox.Text = Convert.ToString(0);

            //Requirements Tab//

            itemRequiredLevelTextBox.Text = Convert.ToString(0);

            itemSkillProfessionComboBox.SelectedIndex = 0;

            itemSkillLevelTextBox.Text = Convert.ToString(0);
            itemsMaxTextBox.Text = Convert.ToString(0);

            //Allowable Classes
            itemsAllClasses.Checked = false;
            itemsWarriorCheckBox.Checked = false;
            itemsPaladinCheckBox.Checked = false;
            itemsHunterCheckBox.Checked = false;
            itemsRogueCheckBox.Checked = false;
            itemsPriestCheckBox.Checked = false;
            itemsDruidCheckBox.Checked = false;
            itemsShamanCheckBox.Checked = false;
            itemsMageCheckBox.Checked = false;
            itemsWarlockCheckBox.Checked = false;
            itemsDeathKnightCheckBox.Checked = false;

            //Allowable Races
            itemsAllRaces.Checked = false;
            itemsHumanCheckBox.Checked = false;
            itemsOrcCheckBox.Checked = false;
            itemsDwarfCheckBox.Checked = false;
            itemsNightElfCheckBox.Checked = false;
            itemsUndeadCheckBox.Checked = false;
            itemsTaurenCheckBox.Checked = false;
            itemsGnomeCheckBox.Checked = false;
            itemsTrollCheckBox.Checked = false;
            itemsBloodElfCheckBox.Checked = false;
            itemsDraeneiCheckBox.Checked = false;

            //Price Tab//

            itemsBuyGoldTextBox.Text = Convert.ToString(0);
            itemsBuySilverNumericUpDown.Value = 0;
            itemsBuyCopperNumericUpDown.Value = 0;

            itemsSellGoldTextBox.Text = Convert.ToString(0);
            itemsSellSilverNumericUpDown.Value = 0;
            itemsSellCopperNumericUpDown.Value = 0;
        }

        private void itemDisplayidTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void itemEntryTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void itemLevelTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void itemRequiredLevelTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void itemSkillLevelTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void itemsMaxTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void itemsBuyGoldTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void itemsSellGoldTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void itemsSaveToDBButton_Click(object sender, EventArgs e)
        {
            int type = itemTypeComboBox.SelectedIndex;
            int bind = 0;
            int buymoney = 0;
            int sellmoney = 0;

            switch (itemBindsComboBox.SelectedIndex)
            {
                case 1:
                    bind = 1;
                    break;
                case 2:
                    bind = 3;
                    break;
                default:
                    bind = 0;
                    break;
            }

            buymoney = (Convert.ToInt32(itemsBuyCopperNumericUpDown.Value) % 100) + (Convert.ToInt32(itemsBuySilverNumericUpDown.Value) * 100) + (int.Parse(itemsBuyGoldTextBox.Text) * 10000);
            sellmoney = (Convert.ToInt32(itemsSellCopperNumericUpDown.Value) % 100) + (Convert.ToInt32(itemsSellSilverNumericUpDown.Value) * 100) + (int.Parse(itemsSellGoldTextBox.Text) * 10000);

            List<int> AllowableClasses = new List<int>();
            int allowableclass = 0;

            //Allowable Classes

            if (itemsWarriorCheckBox.Checked)
                AllowableClasses.Add(1);

            if (itemsPaladinCheckBox.Checked)
                AllowableClasses.Add(2);

            if (itemsHunterCheckBox.Checked)
                AllowableClasses.Add(4);

            if (itemsRogueCheckBox.Checked)
                AllowableClasses.Add(8);

            if (itemsPriestCheckBox.Checked)
                AllowableClasses.Add(16);

            if (itemsDruidCheckBox.Checked)
                AllowableClasses.Add(1024);

            if (itemsShamanCheckBox.Checked)
                AllowableClasses.Add(64);

            if (itemsMageCheckBox.Checked)
                AllowableClasses.Add(128);

            if (itemsWarlockCheckBox.Checked)
                AllowableClasses.Add(256);

            if (itemsDeathKnightCheckBox.Checked)
                AllowableClasses.Add(32);

            foreach (int p in AllowableClasses)
                allowableclass += p;

            if (allowableclass == 0)
                allowableclass = -1;

            List<int> AllowableRaces = new List<int>();
            int allowablerace = 0;

            if (itemsHumanCheckBox.Checked)
                AllowableRaces.Add(1);

            if (itemsOrcCheckBox.Checked)
                AllowableRaces.Add(2);

            if (itemsDwarfCheckBox.Checked)
                AllowableRaces.Add(4);

            if (itemsNightElfCheckBox.Checked)
                AllowableRaces.Add(8);

            if (itemsUndeadCheckBox.Checked)
                AllowableRaces.Add(16);

            if (itemsTaurenCheckBox.Checked)
                AllowableRaces.Add(32);

            if (itemsGnomeCheckBox.Checked)
                AllowableRaces.Add(64);

            if (itemsTrollCheckBox.Checked)
                AllowableRaces.Add(128);

            if (itemsBloodElfCheckBox.Checked)
                AllowableRaces.Add(512);

            if (itemsDraeneiCheckBox.Checked)
                AllowableRaces.Add(1024);

            foreach (int p in AllowableRaces)
                allowablerace += p;

            if (allowablerace == 0)
                allowablerace = -1;

            int requiredskill = 0;

            switch (itemSkillProfessionComboBox.SelectedIndex)
            {
                case 1:
                    requiredskill = 129;
                    break;
                case 2:
                    requiredskill = 164;
                    break;
                case 3:
                    requiredskill = 165;
                    break;
                case 4:
                    requiredskill = 171;
                    break;
                case 5:
                    requiredskill = 182;
                    break;
                case 6:
                    requiredskill = 185;
                    break;
                case 7:
                    requiredskill = 186;
                    break;
                case 8:
                    requiredskill = 197;
                    break;
                case 9:
                    requiredskill = 202;
                    break;
                case 10:
                    requiredskill = 333;
                    break;
                case 11:
                    requiredskill = 356;
                    break;
                case 12:
                    requiredskill = 393;
                    break;
                case 13:
                    requiredskill = 755;
                    break;
                case 14:
                    requiredskill = 0;
                    break;
                case 15:
                    requiredskill = 43;
                    break;
                case 16:
                    requiredskill = 44;
                    break;
                case 17:
                    requiredskill = 46;
                    break;
                case 18:
                    requiredskill = 54;
                    break;
                case 19:
                    requiredskill = 55;
                    break;
                case 20:
                    requiredskill = 95;
                    break;
                case 21:
                    requiredskill = 136;
                    break;
                case 22:
                    requiredskill = 160;
                    break;
                case 23:
                    requiredskill = 162;
                    break;
                case 24:
                    requiredskill = 172;
                    break;
                case 25:
                    requiredskill = 173;
                    break;
                case 26:
                    requiredskill = 176;
                    break;
                case 27:
                    requiredskill = 226;
                    break;
                case 28:
                    requiredskill = 228;
                    break;
                case 29:
                    requiredskill = 229;
                    break;
                case 30:
                    requiredskill = 473;
                    break;
                case 31:
                    requiredskill = 762;
                    break;
                default:
                    requiredskill = 0;
                    break;
            }

            try
            {
                string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.worlddb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                MySqlConnection mConnection = new MySqlConnection(connection);

                mConnection.Open();

                string values = String.Format("('{0}', '0', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', '{14}', '{15}');",
                    itemEntryTextBox.Text, itemTypeComboBox.SelectedIndex, itemNameTextBox.Text, itemDisplayidTextBox.Text, itemQualityComboBox.SelectedIndex, buymoney, sellmoney, allowableclass, allowablerace,
                    itemLevelTextBox.Text, itemRequiredLevelTextBox.Text, requiredskill, itemSkillLevelTextBox.Text, itemsMaxTextBox.Text, bind, itemQuoteTextBox.Text);

                string qry = String.Format("INSERT INTO items (entry, `class`, subclass, name1, displayid, quality, buyprice, sellprice, allowableclass, allowablerace, itemlevel, requiredlevel, RequiredSkill, RequiredSkillRank, maxcount, bonding, description) VALUES {0}", values);

                MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                MySqlDataReader Reader = cmd.ExecuteReader();

                mConnection.Close();

                MessageBox.Show("Item Added To Database!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void itemsSaveToSQLButton_Click(object sender, EventArgs e)
        {
            int type = itemTypeComboBox.SelectedIndex;
            int bind = 0;
            int buymoney = 0;
            int sellmoney = 0;

            switch (itemBindsComboBox.SelectedIndex)
            {
                case 1:
                    bind = 1;
                    break;
                case 2:
                    bind = 3;
                    break;
                default:
                    bind = 0;
                    break;
            }

            buymoney = (Convert.ToInt32(itemsBuyCopperNumericUpDown.Value) % 100) + (Convert.ToInt32(itemsBuySilverNumericUpDown.Value) * 100) + (int.Parse(itemsBuyGoldTextBox.Text) * 10000);
            sellmoney = (Convert.ToInt32(itemsSellCopperNumericUpDown.Value) % 100) + (Convert.ToInt32(itemsSellSilverNumericUpDown.Value) * 100) + (int.Parse(itemsSellGoldTextBox.Text) * 10000);

            List<int> AllowableClasses = new List<int>();
            int allowableclass = 0;

            //Allowable Classes

            if (itemsWarriorCheckBox.Checked)
                AllowableClasses.Add(1);

            if (itemsPaladinCheckBox.Checked)
                AllowableClasses.Add(2);

            if (itemsHunterCheckBox.Checked)
                AllowableClasses.Add(4);

            if (itemsRogueCheckBox.Checked)
                AllowableClasses.Add(8);

            if (itemsPriestCheckBox.Checked)
                AllowableClasses.Add(16);

            if (itemsDruidCheckBox.Checked)
                AllowableClasses.Add(1024);

            if (itemsShamanCheckBox.Checked)
                AllowableClasses.Add(64);

            if (itemsMageCheckBox.Checked)
                AllowableClasses.Add(128);

            if (itemsWarlockCheckBox.Checked)
                AllowableClasses.Add(256);

            if (itemsDeathKnightCheckBox.Checked)
                AllowableClasses.Add(32);

            foreach (int p in AllowableClasses)
                allowableclass += p;

            if (allowableclass == 0)
                allowableclass = -1;

            List<int> AllowableRaces = new List<int>();
            int allowablerace = 0;

            if (itemsHumanCheckBox.Checked)
                AllowableRaces.Add(1);

            if (itemsOrcCheckBox.Checked)
                AllowableRaces.Add(2);

            if (itemsDwarfCheckBox.Checked)
                AllowableRaces.Add(4);

            if (itemsNightElfCheckBox.Checked)
                AllowableRaces.Add(8);

            if (itemsUndeadCheckBox.Checked)
                AllowableRaces.Add(16);

            if (itemsTaurenCheckBox.Checked)
                AllowableRaces.Add(32);

            if (itemsGnomeCheckBox.Checked)
                AllowableRaces.Add(64);

            if (itemsTrollCheckBox.Checked)
                AllowableRaces.Add(128);

            if (itemsBloodElfCheckBox.Checked)
                AllowableRaces.Add(512);

            if (itemsDraeneiCheckBox.Checked)
                AllowableRaces.Add(1024);

            foreach (int p in AllowableRaces)
                allowablerace += p;

            if (allowablerace == 0)
                allowablerace = -1;

            int requiredskill = 0;

            switch (itemSkillProfessionComboBox.SelectedIndex)
            {
                case 1:
                    requiredskill = 129;
                    break;
                case 2:
                    requiredskill = 164;
                    break;
                case 3:
                    requiredskill = 165;
                    break;
                case 4:
                    requiredskill = 171;
                    break;
                case 5:
                    requiredskill = 182;
                    break;
                case 6:
                    requiredskill = 185;
                    break;
                case 7:
                    requiredskill = 186;
                    break;
                case 8:
                    requiredskill = 197;
                    break;
                case 9:
                    requiredskill = 202;
                    break;
                case 10:
                    requiredskill = 333;
                    break;
                case 11:
                    requiredskill = 356;
                    break;
                case 12:
                    requiredskill = 393;
                    break;
                case 13:
                    requiredskill = 755;
                    break;
                case 14:
                    requiredskill = 0;
                    break;
                case 15:
                    requiredskill = 43;
                    break;
                case 16:
                    requiredskill = 44;
                    break;
                case 17:
                    requiredskill = 46;
                    break;
                case 18:
                    requiredskill = 54;
                    break;
                case 19:
                    requiredskill = 55;
                    break;
                case 20:
                    requiredskill = 95;
                    break;
                case 21:
                    requiredskill = 136;
                    break;
                case 22:
                    requiredskill = 160;
                    break;
                case 23:
                    requiredskill = 162;
                    break;
                case 24:
                    requiredskill = 172;
                    break;
                case 25:
                    requiredskill = 173;
                    break;
                case 26:
                    requiredskill = 176;
                    break;
                case 27:
                    requiredskill = 226;
                    break;
                case 28:
                    requiredskill = 228;
                    break;
                case 29:
                    requiredskill = 229;
                    break;
                case 30:
                    requiredskill = 473;
                    break;
                case 31:
                    requiredskill = 762;
                    break;
                default:
                    requiredskill = 0;
                    break;
            }

            try
            {
                if (SaveItemSQLFile.ShowDialog() == DialogResult.OK)
                {

                    StreamWriter writer = new StreamWriter(SaveItemSQLFile.FileName);

                    string values = String.Format("('{0}', '0', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', '{14}', '{15}');",
                        itemEntryTextBox.Text, itemTypeComboBox.SelectedIndex, itemNameTextBox.Text, itemDisplayidTextBox.Text, itemQualityComboBox.SelectedIndex, buymoney, sellmoney, allowableclass, allowablerace,
                        itemLevelTextBox.Text, itemRequiredLevelTextBox.Text, requiredskill, itemSkillLevelTextBox.Text, itemsMaxTextBox.Text, bind, itemQuoteTextBox.Text);

                    string qry = String.Format("INSERT INTO items (entry, `class`, subclass, name1, displayid, quality, buyprice, sellprice, allowableclass, allowablerace, itemlevel, requiredlevel, RequiredSkill, RequiredSkillRank, maxcount, bonding, description) VALUES {0}", values);

                    writer.WriteLine(qry);

                    writer.Close();

                    MessageBox.Show("SQL File Saved!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void vendorAddButton_Click(object sender, EventArgs e)
        {
            if (vendorEntryIDTextBox.Text != String.Empty && vendorItemEntryIDTextBox.Text != String.Empty)
            {

                bool duplicate = false;

                for (int i = 0; i < vendorGridView.Rows.Count; i++)
                {
                    if (vendorGridView.Rows[i].Cells[1].Value.ToString() == vendorItemEntryIDTextBox.Text)
                    {
                        duplicate = true;
                    }
                }


                if (duplicate != true)
                {
                    int n = vendorGridView.Rows.Add();

                    vendorGridView.Rows[n].Cells[0].Value = vendorEntryIDTextBox.Text;
                    vendorGridView.Rows[n].Cells[1].Value = vendorItemEntryIDTextBox.Text;
                    vendorGridView.Rows[n].Cells[2].Value = vendorAmountNumericUpDown.Value;
                }
                else
                {
                    MessageBox.Show(String.Format("Cannot add a duplicate item entry ({0})", vendorItemEntryIDTextBox.Text));
                }
            }
            else
            {
                MessageBox.Show("You must fill out all fields!");
            }
        }

        private void vendorRemoveRowButton_Click(object sender, EventArgs e)
        {
            if (vendorGridView.Rows.Count != 0)
            {
                if (vendorGridView.SelectedRows.Count != 0)
                {
                    if (vendorGridView.SelectedRows.Count == vendorGridView.Rows.Count)
                    {
                        vendorGridView.Rows.Clear();
                    }
                    foreach (DataGridViewRow row in vendorGridView.SelectedRows)
                    {
                        vendorGridView.Rows.Remove(row);
                    }
                }
                else
                {
                    MessageBox.Show("You have not selected a row to delete!");
                }
            }
            else
            {
                MessageBox.Show("There are no rows to delete!");
            }
        }


        private void vendorSaveToDBButton_Click(object sender, EventArgs e)
        {

            if (vendorGridView.Rows.Count != 0)
            {

                try
                {
                    string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.worlddb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                    MySqlConnection mConnection = new MySqlConnection(connection);

                    mConnection.Open();

                    string values = String.Empty;

                    for (int i = 0; i < vendorGridView.Rows.Count; i++)
                    {
                        if (i == vendorGridView.Rows.Count - 1)
                            values += String.Format("('{0}','{1}','{2}');", vendorGridView.Rows[i].Cells[0].Value, vendorGridView.Rows[i].Cells[1].Value, vendorGridView.Rows[i].Cells[2].Value);
                        else
                            values += String.Format("('{0}','{1}','{2}'), ", vendorGridView.Rows[i].Cells[0].Value, vendorGridView.Rows[i].Cells[1].Value, vendorGridView.Rows[i].Cells[2].Value);
                    }

                    string qry = String.Format("INSERT INTO `vendors` (`entry`,`item`,`amount`) VALUES {0}", values);

                    MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                    MySqlDataReader Reader = cmd.ExecuteReader();

                    mConnection.Close();

                    MessageBox.Show("Vendor Saved!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                if (vendorEntryIDTextBox.Text != String.Empty && vendorItemEntryIDTextBox.Text != String.Empty)
                {
                    MessageBox.Show("You must first use the add button");
                }
                else
                {
                    MessageBox.Show("You must fill out all fields!");
                }
            }
        }

        private void vendorSaveToSQLButton_Click(object sender, EventArgs e)
        {
            if (vendorGridView.Rows.Count != 0)
            {

                if (VendorSaveSQLFile.ShowDialog() == DialogResult.OK)
                {

                    try
                    {

                        string values = String.Empty;

                        for (int i = 0; i < vendorGridView.Rows.Count; i++)
                        {
                            if (i == vendorGridView.Rows.Count - 1)
                                values += String.Format("('{0}','{1}','{2}');", vendorGridView.Rows[i].Cells[0].Value, vendorGridView.Rows[i].Cells[1].Value, vendorGridView.Rows[i].Cells[2].Value);
                            else
                                values += String.Format("('{0}','{1}','{2}'), ", vendorGridView.Rows[i].Cells[0].Value, vendorGridView.Rows[i].Cells[1].Value, vendorGridView.Rows[i].Cells[2].Value);
                        }

                        string qry = String.Format("INSERT INTO `vendors` (`entry`,`item`,`amount`) VALUES {0}", values);

                        StreamWriter writer = new StreamWriter(VendorSaveSQLFile.FileName);

                        writer.WriteLine(qry);

                        writer.Close();
                        writer.Dispose();

                        MessageBox.Show("SQL File Saved!");

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                if (vendorEntryIDTextBox.Text != String.Empty && vendorItemEntryIDTextBox.Text != String.Empty)
                {
                    MessageBox.Show("You must first use the add button");
                }
                else
                {
                    MessageBox.Show("You must fill out all fields!");
                }
            }
        }

        private void vendorEntryIDTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void vendorItemEntryIDTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void npcDetailsNextButton_Click(object sender, EventArgs e)
        {
            if (npcNameTextBox.Text != String.Empty && npcDisplayidTextBox.Text != String.Empty && npcEntryIDTextBox.Text != String.Empty)
            {
                if (!npcTabControl.Contains(npcBehaviorTabPage))
                {
                    npcTabControl.TabPages.Add(npcBehaviorTabPage);
                    npcTabControl.SelectedIndex = npcTabControl.TabPages.IndexOf(npcBehaviorTabPage);
                }
                else
                {
                    npcTabControl.SelectedIndex = npcTabControl.TabPages.IndexOf(npcBehaviorTabPage);
                }
            }
            else
            {
                MessageBox.Show("You must fill out all required fields!");
            }
        }

        private void npcSearchDisplayIDs_Click(object sender, EventArgs e)
        {
            SearchNPCDisplayID npcsearch = new SearchNPCDisplayID();

            npcsearch.Show();

            npcsearch.FormClosing += new FormClosingEventHandler(npcsearch_FormClosing);
        }

        private void npcsearch_FormClosing(object sender, FormClosingEventArgs e)
        {
            SearchNPCDisplayID search = (SearchNPCDisplayID)sender;

            if (search.GetDisplayID() != String.Empty && search.buttonPressed == true)
            {
                npcDisplayidTextBox.Text = search.GetDisplayID();
            }
        }

        private void npcDisplayidTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void npcEntryIDTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void npcHoursTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void npcBehaviorNextButton_Click(object sender, EventArgs e)
        {
            if (((Control)npcModelSizeNumericUpDown).Text != String.Empty && ((Control)npcMinutesNumericUpDown).Text != String.Empty && ((Control)npcSecondsNumericUpDown).Text != String.Empty)
            {
                if (!npcTabControl.Contains(npcStatsTabPage))
                {
                    npcTabControl.TabPages.Add(npcStatsTabPage);
                    npcTabControl.SelectedIndex = npcTabControl.TabPages.IndexOf(npcStatsTabPage);
                }
                else
                {
                    npcTabControl.SelectedIndex = npcTabControl.TabPages.IndexOf(npcStatsTabPage);
                }
            }
            else
            {
                MessageBox.Show("You must fill out all fields!");
            }
        }

        private void npcStatsNextButton_Click(object sender, EventArgs e)
        {
            if (npcArmorTextBox.Text != String.Empty && npcManaTextBox.Text != String.Empty && npcMinHealthTextBox.Text != String.Empty && npcMaxHealthTextBox.Text != String.Empty &&
                npcMinLevelTextBox.Text != String.Empty && npcMaxLevelTextBox.Text != String.Empty && npcMinDamageTextBox.Text != String.Empty && npcMaxDamageTextBox.Text != String.Empty &&
                npcSpeedTextBox.Text != String.Empty)
            {
                if (!npcTabControl.Contains(npcResistsTabPage))
                {
                    npcTabControl.TabPages.Add(npcResistsTabPage);
                    npcTabControl.SelectedIndex = npcTabControl.TabPages.IndexOf(npcResistsTabPage);
                }
                else
                {
                    npcTabControl.SelectedIndex = npcTabControl.TabPages.IndexOf(npcResistsTabPage);
                }
            }
            else
            {
                MessageBox.Show("You must fill out all fields!");
            }
        }

        private void npcResistsNextButton_Click(object sender, EventArgs e)
        {
            if (npcResistHolyTextBox.Text != String.Empty && npcResistNatureTextBox.Text != String.Empty && npcResistShadowTextBox.Text != String.Empty && npcResistFireTextBox.Text != String.Empty &&
                npcResistFrostTextBox.Text != String.Empty && npcResistArcaneTextBox.Text != String.Empty)
            {
                if (!npcTabControl.Contains(npcOptionsTabPage))
                {
                    npcTabControl.TabPages.Add(npcOptionsTabPage);
                    npcTabControl.SelectedIndex = npcTabControl.TabPages.IndexOf(npcOptionsTabPage);
                }
                else
                {
                    npcTabControl.SelectedIndex = npcTabControl.TabPages.IndexOf(npcOptionsTabPage);
                }
            }
            else
            {
                MessageBox.Show("You must fill out all fields!");
            }
        }

        private void npcResistHolyTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void npcResistNatureTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void npcResistShadowTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void npcResistFireTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void npcResistFrostTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void npcResistArcaneTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void npcArmorTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void npcManaTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void npcMinHealthTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void npcMaxHealthTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void npcMinLevelTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void npcMaxLevelTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void npcMinDamageTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void npcMaxDamageTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void npcSpeedTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void npcOptionsNextButton_Click(object sender, EventArgs e)
        {
            if (!npcTabControl.Contains(npcLootTabPage))
            {
                npcTabControl.TabPages.Add(npcLootTabPage);
                npcTabControl.SelectedIndex = npcTabControl.TabPages.IndexOf(npcLootTabPage);
            }
            else
            {
                npcTabControl.SelectedIndex = npcTabControl.TabPages.IndexOf(npcLootTabPage);
            }
        }

        private void npcLootFinishButton_Click(object sender, EventArgs e)
        {
            if (npcLootGoldTextBox.Text != String.Empty)
            {
                if (!npcTabControl.Contains(npcFinishTabPage))
                {
                    npcTabControl.TabPages.Add(npcFinishTabPage);
                    npcTabControl.SelectedIndex = npcTabControl.TabPages.IndexOf(npcFinishTabPage);
                }
                else
                {
                    npcTabControl.SelectedIndex = npcTabControl.TabPages.IndexOf(npcFinishTabPage);
                }

                npcTabControl.TabPages.Remove(npcDetailsTabPage);
                npcTabControl.TabPages.Remove(npcBehaviorTabPage);
                npcTabControl.TabPages.Remove(npcStatsTabPage);
                npcTabControl.TabPages.Remove(npcResistsTabPage);
                npcTabControl.TabPages.Remove(npcOptionsTabPage);
                npcTabControl.TabPages.Remove(npcLootTabPage);

                npcTabControl.SelectedTab = npcFinishTabPage;
            }
            else
            {
                MessageBox.Show("You must fill out all fields!");
            }
        }

        private void npcLootGoldTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void npcStartOverButton_Click(object sender, EventArgs e)
        {

            npcTabControl.TabPages.Remove(npcFinishTabPage);

            npcTabControl.TabPages.Add(npcDetailsTabPage);

            npcTabControl.SelectedTab = npcDetailsTabPage;

            //Starting Over//

            //NPC Details
            npcNameTextBox.Text = String.Empty;
            npcSubnameTextbox.Text = String.Empty;

            npcRankComboBox.SelectedIndex = 0;

            npcDisplayidTextBox.Text = String.Empty;
            npcEntryIDTextBox.Text = String.Empty;

            npcFactionComboBox.SelectedIndex = 0;
            npcTypeComboBox.SelectedIndex = 0;

            npcBossYesRadioButton.Checked = false;
            npcBossNoRadioButton.Checked = true;

            //Behavior

            npcModelSizeNumericUpDown.Value = 1;

            npcHoursTextBox.Text = Convert.ToString(0);
            npcMinutesNumericUpDown.Value = 0;
            npcSecondsNumericUpDown.Value = 0;

            //Stats

            npcArmorTextBox.Text = Convert.ToString(0);
            npcManaTextBox.Text = Convert.ToString(0);
            npcMinHealthTextBox.Text = Convert.ToString(0);
            npcMaxHealthTextBox.Text = Convert.ToString(0);
            npcMinLevelTextBox.Text = Convert.ToString(0);
            npcMaxLevelTextBox.Text = Convert.ToString(0);
            npcMinDamageTextBox.Text = Convert.ToString(0);
            npcMaxDamageTextBox.Text = Convert.ToString(0);
            npcSpeedTextBox.Text = Convert.ToString(0);

            //Resists

            npcResistHolyTextBox.Text = Convert.ToString(0);
            npcResistNatureTextBox.Text = Convert.ToString(0);
            npcResistShadowTextBox.Text = Convert.ToString(0);
            npcResistFireTextBox.Text = Convert.ToString(0);
            npcResistFrostTextBox.Text = Convert.ToString(0);

            //Options

            npcGossipYesRadioButton.Checked = false;
            npcGossipNoRadioButton.Checked = true;

            npcVendorYesRadioButton.Checked = false;
            npcVendorNoRadioButton.Checked = true;

            npcArmorerYesRadioButton.Checked = false;
            npcArmorerNoRadioButton.Checked = true;

            npcInnkeeperYesRadioButton.Checked = false;
            npcInnkeeperNoRadioButton.Checked = true;

            npcBankerYesRadioButton.Checked = false;
            npcBankerNoRadioButton.Checked = true;

            npcAuctioneerYesRadioButton.Checked = false;
            npcAuctioneerNoRadioButton.Checked = true;

            npcStableYesRadioButton.Checked = false;
            npcStableNoRadioButton.Checked = true;

            npcGuildBankYesRadioButton.Checked = false;
            npcGuildBankNoRadioButton.Checked = true;

            //Loot

            npcLootGoldTextBox.Text = Convert.ToString(0);

            npcLootSilverNumericUpDown.Value = 0;
            npcLootCopperNumericUpDown.Value = 0;

        }

        private void npcSaveToDBButton_Click(object sender, EventArgs e)
        {
            try
            {
                string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.worlddb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                MySqlConnection mConnection = new MySqlConnection(connection);

                mConnection.Open();

                string values = String.Format("('{0}', '{1}', '{2}', '{3}', '{4}', '{5}');", npcEntryIDTextBox.Text, npcNameTextBox.Text, npcSubnameTextbox.Text, npcTypeComboBox.SelectedIndex, npcRankComboBox.SelectedIndex, npcDisplayidTextBox.Text);

                string qry = String.Format("INSERT INTO creature_names (entry, name, subname, type, rank, male_displayid) VALUES {0}", values);

                MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                cmd.ExecuteReader();

                mConnection.Close();
                mConnection.Dispose();

                int boss = 0;
                int flags = 0;
                int money = 0;
                int faction = 7;


                int respawntime = 0;

                if (npcBossYesRadioButton.Checked)
                    boss = 1;

                if (npcGossipYesRadioButton.Checked)
                    flags += 1;

                if (npcVendorYesRadioButton.Checked)
                    flags += 128;

                if (npcArmorerYesRadioButton.Checked)
                    flags += 4096;

                if (npcInnkeeperYesRadioButton.Checked)
                    flags += 65536;

                if (npcBankerYesRadioButton.Checked)
                    flags += 131072;

                if (npcAuctioneerYesRadioButton.Checked)
                    flags += 2097152;

                if (npcStableYesRadioButton.Checked)
                    flags += 4194304;

                if (npcGuildBankYesRadioButton.Checked)
                    flags += 8388608;

                switch (npcFactionComboBox.SelectedIndex)
                {
                    case 0:
                        faction = 7;
                        break;
                    case 1:
                        faction = 14;
                        break;
                    case 2:
                        faction = 35;
                        break;
                }

                respawntime = Convert.ToInt32(TimeSpan.FromHours(double.Parse(npcHoursTextBox.Text)).TotalMilliseconds + TimeSpan.FromMinutes(Convert.ToDouble(npcMinutesNumericUpDown.Value)).TotalMilliseconds + TimeSpan.FromSeconds(Convert.ToDouble(npcSecondsNumericUpDown.Value)).TotalMilliseconds);

                money = (Convert.ToInt32(npcLootCopperNumericUpDown.Value) % 100) + (Convert.ToInt32(npcLootSilverNumericUpDown.Value) * 100) + (int.Parse(npcLootGoldTextBox.Text) * 10000);

                connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.worlddb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                mConnection = new MySqlConnection(connection);

                mConnection.Open();

                values = String.Format("('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', '{14}', '{15}', '{16}', '{17}', '{18}', '{19}', '{20}', '0', '{21}', '{22}');",
                npcEntryIDTextBox.Text, npcMinLevelTextBox.Text, npcMaxLevelTextBox.Text, faction, npcMinHealthTextBox.Text, npcMaxHealthTextBox.Text, npcManaTextBox.Text, npcModelSizeNumericUpDown.Value, flags, npcSpeedTextBox.Text, npcTypeComboBox.SelectedIndex, npcMinDamageTextBox.Text, npcMaxDamageTextBox.Text, respawntime, npcArmorTextBox.Text, npcResistHolyTextBox.Text, npcResistFireTextBox.Text, npcResistNatureTextBox.Text, npcResistFrostTextBox.Text, npcResistShadowTextBox.Text, npcResistArcaneTextBox.Text, boss, money);

                qry = String.Format("INSERT INTO creature_proto (entry, minlevel, maxlevel, faction, minhealth, maxhealth, mana, scale, npcflags, attacktime, attacktype, mindamage, maxdamage, respawntime, armor, resistance1, resistance2, resistance3, resistance4, resistance5, resistance6, auras, boss, money) VALUES {0}", values);

                cmd = new MySqlCommand(qry, mConnection);

                cmd.ExecuteReader();

                mConnection.Close();
                mConnection.Dispose();

                MessageBox.Show("Saved To Database!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void npcSaveToSQLFileButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (SaveNPCSQLFile.ShowDialog() == DialogResult.OK)
                {

                    string values = String.Format("('{0}', '{1}', '{2}', '{3}', '{4}', '{5}');", npcEntryIDTextBox.Text, npcNameTextBox.Text, npcSubnameTextbox.Text, npcTypeComboBox.SelectedIndex, npcRankComboBox.SelectedIndex, npcDisplayidTextBox.Text);

                    string qry1 = String.Format("INSERT INTO creature_names (entry, name, subname, type, rank, male_displayid) VALUES {0}", values);


                    int boss = 0;
                    int flags = 0;
                    int money = 0;
                    int faction = 7;


                    int respawntime = 0;

                    if (npcBossYesRadioButton.Checked)
                        boss = 1;

                    if (npcGossipYesRadioButton.Checked)
                        flags += 1;

                    if (npcVendorYesRadioButton.Checked)
                        flags += 128;

                    if (npcArmorerYesRadioButton.Checked)
                        flags += 4096;

                    if (npcInnkeeperYesRadioButton.Checked)
                        flags += 65536;

                    if (npcBankerYesRadioButton.Checked)
                        flags += 131072;

                    if (npcAuctioneerYesRadioButton.Checked)
                        flags += 2097152;

                    if (npcStableYesRadioButton.Checked)
                        flags += 4194304;

                    if (npcGuildBankYesRadioButton.Checked)
                        flags += 8388608;

                    if (npcBossYesRadioButton.Checked)
                        boss = 1;

                    switch (npcFactionComboBox.SelectedIndex)
                    {
                        case 0:
                            faction = 7;
                            break;
                        case 1:
                            faction = 14;
                            break;
                        case 2:
                            faction = 35;
                            break;
                    }

                    respawntime = Convert.ToInt32(TimeSpan.FromHours(double.Parse(npcHoursTextBox.Text)).TotalMilliseconds + TimeSpan.FromMinutes(Convert.ToDouble(npcMinutesNumericUpDown.Value)).TotalMilliseconds + TimeSpan.FromSeconds(Convert.ToDouble(npcSecondsNumericUpDown.Value)).TotalMilliseconds);

                    money = (Convert.ToInt32(npcLootCopperNumericUpDown.Value) % 100) + (Convert.ToInt32(npcLootSilverNumericUpDown.Value) * 100) + (int.Parse(npcLootGoldTextBox.Text) * 10000);

                    values = String.Format("('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', '{14}', '{15}', '{16}', '{17}', '{18}', '{19}', '{20}', '0', '{21}', '{22}');",
                    npcEntryIDTextBox.Text, npcMinLevelTextBox.Text, npcMaxLevelTextBox.Text, faction, npcMinHealthTextBox.Text, npcMaxHealthTextBox.Text, npcManaTextBox.Text, npcModelSizeNumericUpDown.Value, flags, npcSpeedTextBox.Text, npcTypeComboBox.SelectedIndex, npcMinDamageTextBox.Text, npcMaxDamageTextBox.Text, respawntime, npcArmorTextBox.Text, npcResistHolyTextBox.Text, npcResistFireTextBox.Text, npcResistNatureTextBox.Text, npcResistFrostTextBox.Text, npcResistShadowTextBox.Text, npcResistArcaneTextBox.Text, boss, money);

                    string qry2 = String.Format("INSERT INTO creature_proto (entry, minlevel, maxlevel, faction, minhealth, maxhealth, mana, scale, npcflags, attacktime, attacktype, mindamage, maxdamage, respawntime, armor, resistance1, resistance2, resistance3, resistance4, resistance5, resistance6, auras, boss, money) VALUES {0}", values);

                    StreamWriter writer = new StreamWriter(SaveNPCSQLFile.FileName);

                    writer.WriteLine(qry1);
                    writer.WriteLine(qry2);

                    writer.Close();

                    MessageBox.Show("SQL File Saved!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void lootAddButton_Click(object sender, EventArgs e)
        {
            if (lootNPCEntryIDTextBox.Text != String.Empty && lootItemEntryIDTextBox.Text != String.Empty && lootChanceTextBox.Text != String.Empty)
            {

                bool duplicate = false;

                for (int i = 0; i < lootGridView.Rows.Count; i++)
                {
                    if (lootGridView.Rows[i].Cells[1].Value.ToString() == lootItemEntryIDTextBox.Text)
                    {
                        duplicate = true;
                    }
                }


                if (duplicate != true)
                {
                    int n = lootGridView.Rows.Add();

                    lootGridView.Rows[n].Cells[0].Value = lootNPCEntryIDTextBox.Text;
                    lootGridView.Rows[n].Cells[1].Value = lootItemEntryIDTextBox.Text;
                    lootGridView.Rows[n].Cells[2].Value = lootChanceTextBox.Text;
                    lootGridView.Rows[n].Cells[3].Value = lootMinAmountNumericUpDown.Value;
                    lootGridView.Rows[n].Cells[4].Value = lootMaxAmountNumericUpDown.Value;
                }
                else
                {
                    MessageBox.Show(String.Format("Cannot add a duplicate item entry ({0})", lootItemEntryIDTextBox.Text));
                }
            }
            else
            {
                MessageBox.Show("You must fill out all fields!");
            }
        }

        private void lootRemoveButton_Click(object sender, EventArgs e)
        {
            if (lootGridView.Rows.Count != 0)
            {
                if (lootGridView.SelectedRows.Count != 0)
                {
                    if (lootGridView.SelectedRows.Count == lootGridView.Rows.Count)
                    {
                        lootGridView.Rows.Clear();
                    }
                    foreach (DataGridViewRow row in lootGridView.SelectedRows)
                    {
                        lootGridView.Rows.Remove(row);
                    }
                }
                else
                {
                    MessageBox.Show("You have not selected a row to delete!");
                }
            }
            else
            {
                MessageBox.Show("There are no rows to delete!");
            }
        }

        private void lootNPCEntryIDTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void lootItemEntryIDTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void lootChanceTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void lootSaveToDBButton_Click(object sender, EventArgs e)
        {
            if (lootGridView.Rows.Count != 0)
            {

                try
                {
                    string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.worlddb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                    MySqlConnection mConnection = new MySqlConnection(connection);

                    mConnection.Open();

                    string values = String.Empty;

                    for (int i = 0; i < lootGridView.Rows.Count; i++)
                    {
                        if (i == lootGridView.Rows.Count - 1)
                            values += String.Format("('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '0');", lootGridView.Rows[i].Cells[0].Value, lootGridView.Rows[i].Cells[1].Value, lootGridView.Rows[i].Cells[2].Value, lootGridView.Rows[i].Cells[2].Value, lootGridView.Rows[i].Cells[2].Value, lootGridView.Rows[i].Cells[2].Value, lootGridView.Rows[i].Cells[3].Value, lootGridView.Rows[i].Cells[4].Value);
                        else
                            values += String.Format("('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '0'),", lootGridView.Rows[i].Cells[0].Value, lootGridView.Rows[i].Cells[1].Value, lootGridView.Rows[i].Cells[2].Value, lootGridView.Rows[i].Cells[2].Value, lootGridView.Rows[i].Cells[2].Value, lootGridView.Rows[i].Cells[2].Value, lootGridView.Rows[i].Cells[3].Value, lootGridView.Rows[i].Cells[4].Value);
                    }

                    string qry = String.Format("INSERT INTO `loot_creatures` (`entryid`,`itemid`,`heroic10percentchance`,`heroic25percentchance`,`normal10percentchance`,`normal25percentchance`,`mincount`,`maxcount`,`ffa_loot`) VALUES {0}", values);

                    MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                    MySqlDataReader Reader = cmd.ExecuteReader();

                    mConnection.Close();

                    MessageBox.Show("Loot Saved!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                if (lootNPCEntryIDTextBox.Text != String.Empty && lootItemEntryIDTextBox.Text != String.Empty && lootChanceTextBox.Text != String.Empty)
                {
                    MessageBox.Show("You must first use the add button");
                }
                else
                {
                    MessageBox.Show("You must fill out all fields!");
                }
            }
        }

        private void lootSaveToSQLFileButton_Click(object sender, EventArgs e)
        {
            if (lootGridView.Rows.Count != 0)
            {

                if (LootSaveSQLFile.ShowDialog() == DialogResult.OK)
                {

                    string values = String.Empty;

                    for (int i = 0; i < lootGridView.Rows.Count; i++)
                    {
                        if (i == lootGridView.Rows.Count - 1)
                            values += String.Format("('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '0');", lootGridView.Rows[i].Cells[0].Value, lootGridView.Rows[i].Cells[1].Value, lootGridView.Rows[i].Cells[2].Value, lootGridView.Rows[i].Cells[2].Value, lootGridView.Rows[i].Cells[2].Value, lootGridView.Rows[i].Cells[2].Value, lootGridView.Rows[i].Cells[3].Value, lootGridView.Rows[i].Cells[4].Value);
                        else
                            values += String.Format("('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '0'),", lootGridView.Rows[i].Cells[0].Value, lootGridView.Rows[i].Cells[1].Value, lootGridView.Rows[i].Cells[2].Value, lootGridView.Rows[i].Cells[2].Value, lootGridView.Rows[i].Cells[2].Value, lootGridView.Rows[i].Cells[2].Value, lootGridView.Rows[i].Cells[3].Value, lootGridView.Rows[i].Cells[4].Value);
                    }

                    string qry = String.Format("INSERT INTO `loot_creatures` (`entryid`,`itemid`,`heroic10percentchance`,`heroic25percentchance`,`normal10percentchance`,`normal25percentchance`,`mincount`,`maxcount`,`ffa_loot`) VALUES {0}", values);

                    StreamWriter writer = new StreamWriter(LootSaveSQLFile.FileName);

                    writer.WriteLine(qry);

                    writer.Close();
                    writer.Dispose();

                    MessageBox.Show("SQL File Saved!");
                }
            }
            else
            {
                if (vendorEntryIDTextBox.Text != String.Empty && vendorItemEntryIDTextBox.Text != String.Empty)
                {
                    MessageBox.Show("You must first use the add button");
                }
                else
                {
                    MessageBox.Show("You must fill out all fields!");
                }
            }
        }

        private void weaponDetailsNextButton_Click(object sender, EventArgs e)
        {
            if (weaponNameTextBox.Text != String.Empty && weaponDisplayIDTextBox.Text != String.Empty && weaponEntryIDTextBox.Text != String.Empty &&
                weaponDurabilityTextBox.Text != String.Empty)
            {
                if (!weaponsTabControl.Contains(weaponStatsTabPage))
                {
                    weaponsTabControl.TabPages.Add(weaponStatsTabPage);
                    weaponsTabControl.SelectedIndex = weaponsTabControl.TabPages.IndexOf(weaponStatsTabPage);
                }
                else
                {
                    weaponsTabControl.SelectedIndex = weaponsTabControl.TabPages.IndexOf(weaponStatsTabPage);
                }
            }
            else
            {
                MessageBox.Show("You must fill out the required fields!");
            }
        }

        private void weaponSearchDisplayIDButton_Click(object sender, EventArgs e)
        {
            SearchWeaponDisplayID weaponsearch = new SearchWeaponDisplayID();

            weaponsearch.Show();

            weaponsearch.FormClosing += new FormClosingEventHandler(weaponsearch_FormClosing);
        }

        private void weaponsearch_FormClosing(object sender, FormClosingEventArgs e)
        {
            SearchWeaponDisplayID weaponsearch = (SearchWeaponDisplayID)sender;

            if (weaponsearch.GetDisplayID() != String.Empty && weaponsearch.buttonPressed == true)
            {
                weaponDisplayIDTextBox.Text = weaponsearch.GetDisplayID();
            }
        }

        private void weaponStatsNextButton_Click(object sender, EventArgs e)
        {
            if (weaponBlockTextBox.Text != String.Empty && weaponBlockArmorTextBox.Text != String.Empty)
            {
                if (!weaponsTabControl.Contains(weaponRequirementsTabPage))
                {
                    weaponsTabControl.TabPages.Add(weaponRequirementsTabPage);
                    weaponsTabControl.SelectedIndex = weaponsTabControl.TabPages.IndexOf(weaponRequirementsTabPage);
                }
                else
                {
                    weaponsTabControl.SelectedIndex = weaponsTabControl.TabPages.IndexOf(weaponRequirementsTabPage);
                }
            }
            else
            {
                MessageBox.Show("You must fill out the required fields!");
            }
        }

        private void weaponRequirementsNextButton_Click(object sender, EventArgs e)
        {
            if (weaponRequiredLevelTextBox.Text != String.Empty && weaponItemLevelTextBox.Text != String.Empty && weaponMaxTextBox.Text != String.Empty && weaponStackableTextBox.Text != String.Empty)
            {
                if (!weaponsTabControl.Contains(weaponDamageTabPage))
                {
                    weaponsTabControl.TabPages.Add(weaponDamageTabPage);
                    weaponsTabControl.SelectedIndex = weaponsTabControl.TabPages.IndexOf(weaponDamageTabPage);
                }
                else
                {
                    weaponsTabControl.SelectedIndex = weaponsTabControl.TabPages.IndexOf(weaponDamageTabPage);
                }
            }
            else
            {
                MessageBox.Show("You must fill out the required fields!");
            }
        }

        private void weaponDamageNextButton_Click(object sender, EventArgs e)
        {
            if (weaponDamageMin1TextBox.Text != String.Empty && weaponDamageMax1TextBox.Text != String.Empty && weaponDamageMin2TextBox.Text != String.Empty && weaponDamageMax2TextBox.Text != String.Empty)
            {
                if (!weaponsTabControl.Contains(weaponResistsTabPage))
                {
                    weaponsTabControl.TabPages.Add(weaponResistsTabPage);
                    weaponsTabControl.SelectedIndex = weaponsTabControl.TabPages.IndexOf(weaponResistsTabPage);
                }
                else
                {
                    weaponsTabControl.SelectedIndex = weaponsTabControl.TabPages.IndexOf(weaponResistsTabPage);
                }
            }
            else
            {
                MessageBox.Show("You must fill out the required fields!");
            }
        }

        private void weaponResistsNextButton_Click(object sender, EventArgs e)
        {
            if (weaponHolyTextBox.Text != String.Empty && weaponNatureTextBox.Text != String.Empty && weaponShadowTextBox.Text != String.Empty && weaponFireTextBox.Text != String.Empty &&
                weaponFrostTextBox.Text != String.Empty && weaponArcaneTextBox.Text != String.Empty)
            {
                if (!weaponsTabControl.Contains(weaponSocketsTabPage))
                {
                    weaponsTabControl.TabPages.Add(weaponSocketsTabPage);
                    weaponsTabControl.SelectedIndex = weaponsTabControl.TabPages.IndexOf(weaponSocketsTabPage);
                }
                else
                {
                    weaponsTabControl.SelectedIndex = weaponsTabControl.TabPages.IndexOf(weaponSocketsTabPage);
                }
            }
            else
            {
                MessageBox.Show("You must fill out the required fields!");
            }
        }

        private void weaponSocketsNextButton_Click(object sender, EventArgs e)
        {
            if (!weaponsTabControl.Contains(weaponPriceTabPage))
            {
                weaponsTabControl.TabPages.Add(weaponPriceTabPage);
                weaponsTabControl.SelectedIndex = weaponsTabControl.TabPages.IndexOf(weaponPriceTabPage);
            }
            else
            {
                weaponsTabControl.SelectedIndex = weaponsTabControl.TabPages.IndexOf(weaponPriceTabPage);
            }
        }

        private void weaponPriceNextButton_Click(object sender, EventArgs e)
        {
            if (weaponBuyGoldTextBox.Text != String.Empty && ((Control)weaponBuySilverNumericUpDown).Text != String.Empty && ((Control)weaponBuyCopperNumericUpDown).Text != String.Empty &&
                weaponSellGoldTextBox.Text != String.Empty && ((Control)weaponBuySilverNumericUpDown).Text != String.Empty && ((Control)weaponBuyCopperNumericUpDown).Text != String.Empty)
            {
                if (!weaponsTabControl.Contains(weaponFinishTabPage))
                {
                    weaponsTabControl.TabPages.Add(weaponFinishTabPage);

                    weaponsTabControl.TabPages.Remove(weaponDetailsTabPage);
                    weaponsTabControl.TabPages.Remove(weaponStatsTabPage);
                    weaponsTabControl.TabPages.Remove(weaponRequirementsTabPage);
                    weaponsTabControl.TabPages.Remove(weaponDamageTabPage);
                    weaponsTabControl.TabPages.Remove(weaponResistsTabPage);
                    weaponsTabControl.TabPages.Remove(weaponSocketsTabPage);
                    weaponsTabControl.TabPages.Remove(weaponPriceTabPage);

                    weaponsTabControl.SelectedIndex = weaponsTabControl.TabPages.IndexOf(weaponFinishTabPage);
                }
                else
                {
                    weaponsTabControl.SelectedIndex = weaponsTabControl.TabPages.IndexOf(weaponFinishTabPage);
                }
            }
            else
            {
                MessageBox.Show("You must fill out the required fields!");
            }
        }

        private void weaponStartOverButton_Click(object sender, EventArgs e)
        {

            weaponsTabControl.TabPages.Add(weaponDetailsTabPage);

            weaponsTabControl.TabPages.Remove(weaponStatsTabPage);
            weaponsTabControl.TabPages.Remove(weaponRequirementsTabPage);
            weaponsTabControl.TabPages.Remove(weaponDamageTabPage);
            weaponsTabControl.TabPages.Remove(weaponResistsTabPage);
            weaponsTabControl.TabPages.Remove(weaponSocketsTabPage);
            weaponsTabControl.TabPages.Remove(weaponPriceTabPage);
            weaponsTabControl.TabPages.Remove(weaponFinishTabPage);


            //Details

            weaponNameTextBox.Text = String.Empty;
            weaponQuoteTextBox.Text = String.Empty;

            weaponQualityComboBox.SelectedIndex = 0;

            weaponDisplayIDTextBox.Text = String.Empty;
            weaponEntryIDTextBox.Text = String.Empty;

            weaponEquipComboBox.SelectedIndex = 0;
            weaponTypeComboBox.SelectedIndex = 0;

            weaponDurabilityTextBox.Text = Convert.ToString(0);

            weaponBindComboBox.SelectedIndex = 0;

            //Stats

            weaponSheathComboBox.SelectedIndex = 0;
            weaponAmmoTypeComboBox.SelectedIndex = 0;

            weaponSpeedNumericUpDown.Value = 2.0m;
            weaponBlockTextBox.Text = Convert.ToString(0);
            weaponBlockArmorTextBox.Text = Convert.ToString(0);

            //Requirements

            weaponRequiredLevelTextBox.Text = Convert.ToString(0);
            weaponItemLevelTextBox.Text = Convert.ToString(0);
            weaponMaxTextBox.Text = Convert.ToString(1);
            weaponStackableTextBox.Text = Convert.ToString(0);

            weaponClassAllCheckBox.Checked = false;
            weaponWarriorCheckBox.Checked = false;
            weaponPaladinCheckBox.Checked = false;
            weaponHunterCheckBox.Checked = false;
            weaponRogueCheckBox.Checked = false;
            weaponPriestCheckBox.Checked = false;
            weaponDruidCheckBox.Checked = false;
            weaponShamanCheckBox.Checked = false;
            weaponMageCheckBox.Checked = false;
            weaponWarlockCheckBox.Checked = false;
            weaponDeathKnightCheckBox.Checked = false;

            weaponRaceAllCheckBox.Checked = false;
            weaponHumanCheckBox.Checked = false;
            weaponOrcCheckBox.Checked = false;
            weaponDwarfCheckBox.Checked = false;
            weaponNightElfCheckBox.Checked = false;
            weaponUndeadCheckBox.Checked = false;
            weaponTaurenCheckBox.Checked = false;
            weaponGnomeCheckBox.Checked = false;
            weaponTrollCheckBox.Checked = false;
            weaponBloodElfCheckBox.Checked = false;
            weaponDraeneiCheckBox.Checked = false;

            //Damage

            weaponDamageMin1TextBox.Text = Convert.ToString(0);
            weaponDamageMax1TextBox.Text = Convert.ToString(0);
            weaponDamageType1ComboBox.SelectedIndex = 0;

            weaponDamageMin2TextBox.Text = Convert.ToString(0);
            weaponDamageMax2TextBox.Text = Convert.ToString(0);
            weaponDamageType2ComboBox.SelectedIndex = 0;

            //Resists

            weaponHolyTextBox.Text = Convert.ToString(0);
            weaponNatureTextBox.Text = Convert.ToString(0);
            weaponShadowTextBox.Text = Convert.ToString(0);
            weaponFireTextBox.Text = Convert.ToString(0); ;
            weaponFrostTextBox.Text = Convert.ToString(0);
            weaponArcaneTextBox.Text = Convert.ToString(0);

            //Sockets

            weaponSocket1NoneButton.Enabled = false;
            weaponSocket1BlueButton.Enabled = true;
            weaponSocket1RedButton.Enabled = true;
            weaponSocket1YellowButton.Enabled = true;

            weaponSocket2NoneButton.Enabled = false;
            weaponSocket2BlueButton.Enabled = true;
            weaponSocket2RedButton.Enabled = true;
            weaponSocket2YellowButton.Enabled = true;

            weaponSocket3NoneButton.Enabled = false;
            weaponSocket3BlueButton.Enabled = true;
            weaponSocket3RedButton.Enabled = true;
            weaponSocket3YellowButton.Enabled = true;

            weaponSocketBonusComboBox.SelectedIndex = 0;

            //Price

            weaponBuyGoldTextBox.Text = Convert.ToString(0);
            weaponBuySilverNumericUpDown.Value = 0;
            weaponBuyCopperNumericUpDown.Value = 0;

            weaponSellGoldTextBox.Text = Convert.ToString(0);
            weaponSellSilverNumericUpDown.Value = 0;
            weaponSellCopperNumericUpDown.Value = 0;
        }

        private void weaponSaveToDBButton_Click(object sender, EventArgs e)
        {
            try
            {
                string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.worlddb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                MySqlConnection mConnection = new MySqlConnection(connection);

                mConnection.Open();

                int sheath = 0;
                int subclass = 0;
                int inventorytype = 0;
                int socket_bonus = 0;

                int weapon_speed = Convert.ToInt32(TimeSpan.FromSeconds(Convert.ToDouble(weaponSpeedNumericUpDown.Value)).TotalMilliseconds);
                int buymoney = (Convert.ToInt32(weaponBuyCopperNumericUpDown.Value) % 100) + (Convert.ToInt32(weaponBuySilverNumericUpDown.Value) * 100) + (int.Parse(weaponBuyGoldTextBox.Text) * 10000);
                int sellmoney = (Convert.ToInt32(weaponSellCopperNumericUpDown.Value) % 100) + (Convert.ToInt32(weaponSellSilverNumericUpDown.Value) * 100) + (int.Parse(weaponSellGoldTextBox.Text) * 10000);

                switch (weaponTypeComboBox.SelectedIndex)
                {
                    case 9:
                        subclass = 10;
                        break;
                    case 10:
                        subclass = 13;
                        break;
                    case 11:
                        subclass = 15;
                        break;
                    case 12:
                        subclass = 16;
                        break;
                    case 13:
                        subclass = 17;
                        break;
                    case 14:
                        subclass = 18;
                        break;
                    case 15:
                        subclass = 19;
                        break;
                    default:
                        subclass = weaponTypeComboBox.SelectedIndex;
                        break;
                }

                switch (weaponEquipComboBox.SelectedIndex)
                {
                    case 0:
                        inventorytype = 13;
                        break;
                    case 1:
                        inventorytype = 21;
                        break;
                    case 2:
                        inventorytype = 22;
                        break;
                    case 3:
                        inventorytype = 17;
                        break;
                    case 4:
                        inventorytype = 15;
                        break;
                    case 5:
                        inventorytype = 25;
                        break;
                    case 6:
                        inventorytype = 26;
                        break;
                    case 7:
                        inventorytype = 26;
                        break;
                    default:
                        inventorytype = 13;
                        break;
                }

                switch (weaponSheathComboBox.SelectedIndex)
                {
                    case 0:
                        sheath = 3;
                        break;
                    case 1:
                        sheath = 1;
                        break;
                    case 2:
                        sheath = 2;
                        break;
                    case 3:
                        sheath = 0;
                        break;
                    case 4:
                        sheath = 0;
                        break;
                }

                List<int> AllowableClasses = new List<int>();
                int allowableclass = 0;

                //Allowable Classes

                if (weaponWarriorCheckBox.Checked)
                    AllowableClasses.Add(1);

                if (weaponPaladinCheckBox.Checked)
                    AllowableClasses.Add(2);

                if (weaponHunterCheckBox.Checked)
                    AllowableClasses.Add(4);

                if (weaponRogueCheckBox.Checked)
                    AllowableClasses.Add(8);

                if (weaponPriestCheckBox.Checked)
                    AllowableClasses.Add(16);

                if (weaponDruidCheckBox.Checked)
                    AllowableClasses.Add(1024);

                if (weaponShamanCheckBox.Checked)
                    AllowableClasses.Add(64);

                if (weaponMageCheckBox.Checked)
                    AllowableClasses.Add(128);

                if (weaponWarlockCheckBox.Checked)
                    AllowableClasses.Add(256);

                if (weaponDeathKnightCheckBox.Checked)
                    AllowableClasses.Add(32);

                foreach (int p in AllowableClasses)
                    allowableclass += p;

                if (allowableclass == 0)
                    allowableclass = -1;

                List<int> AllowableRaces = new List<int>();
                int allowablerace = 0;

                if (weaponHumanCheckBox.Checked)
                    AllowableRaces.Add(1);

                if (weaponOrcCheckBox.Checked)
                    AllowableRaces.Add(2);

                if (weaponDwarfCheckBox.Checked)
                    AllowableRaces.Add(4);

                if (weaponNightElfCheckBox.Checked)
                    AllowableRaces.Add(8);

                if (weaponUndeadCheckBox.Checked)
                    AllowableRaces.Add(16);

                if (weaponTaurenCheckBox.Checked)
                    AllowableRaces.Add(32);

                if (weaponGnomeCheckBox.Checked)
                    AllowableRaces.Add(64);

                if (weaponTrollCheckBox.Checked)
                    AllowableRaces.Add(128);

                if (weaponBloodElfCheckBox.Checked)
                    AllowableRaces.Add(512);

                if (weaponDraeneiCheckBox.Checked)
                    AllowableRaces.Add(1024);

                foreach (int p in AllowableRaces)
                    allowablerace += p;

                if (allowablerace == 0)
                    allowablerace = -1;

                switch (weaponSocketBonusComboBox.SelectedIndex)
                {
                    case 1:
                        socket_bonus = 90;
                        break;
                    case 2:
                        socket_bonus = 106;
                        break;
                    case 3:
                        socket_bonus = 2883;
                        break;
                    case 4:
                        socket_bonus = 2869;
                        break;
                    case 5:
                        socket_bonus = 2890;
                        break;
                    case 6:
                        socket_bonus = 2900;
                        break;
                    case 7:
                        socket_bonus = 1583;
                        break;
                    case 8:
                        socket_bonus = 2873;
                        break;
                    case 9:
                        socket_bonus = 2874;
                        break;
                }

                int socket_1 = 0;
                int socket_2 = 0;
                int socket_3 = 0;

                if (!weaponSocket1BlueButton.Enabled)
                    socket_1 = 8;

                else if (!weaponSocket1RedButton.Enabled)
                    socket_1 = 2;

                else if (!weaponSocket1YellowButton.Enabled)
                    socket_1 = 4;


                if (!weaponSocket2BlueButton.Enabled)
                    socket_2 = 8;

                else if (!weaponSocket2RedButton.Enabled)
                    socket_2 = 2;

                else if (!weaponSocket2YellowButton.Enabled)
                    socket_2 = 4;


                if (!weaponSocket3BlueButton.Enabled)
                    socket_3 = 8;

                else if (!weaponSocket3RedButton.Enabled)
                    socket_3 = 2;

                else if (!weaponSocket3YellowButton.Enabled)
                    socket_3 = 4;


                string values = String.Format("('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', '{14}', '{15}', '{16}', '{17}', '{18}', '{19}', '{20}', '{21}', '{22}', '{23}', '{24}', '{25}', '{26}', '{27}', '{28}', '{29}', '{30}', '{31}', '{32}', '{33}', '{34}', '{35}', '{36}');",
                         weaponEntryIDTextBox.Text, "2", subclass, weaponNameTextBox.Text, weaponDisplayIDTextBox.Text, weaponQualityComboBox.SelectedIndex, buymoney, sellmoney, inventorytype,
                         allowableclass, allowablerace, weaponItemLevelTextBox.Text, weaponRequiredLevelTextBox.Text, weaponMaxTextBox.Text, weaponDamageMin1TextBox.Text, weaponDamageMax1TextBox.Text, weaponDamageType1ComboBox.SelectedIndex, weaponDamageMin2TextBox.Text, weaponDamageMax2TextBox.Text, weaponDamageType2ComboBox.SelectedIndex, weaponBlockArmorTextBox.Text, weaponHolyTextBox.Text, weaponFireTextBox.Text, weaponNatureTextBox.Text, weaponFrostTextBox.Text, weaponShadowTextBox.Text, weaponArcaneTextBox.Text, weapon_speed, weaponAmmoTypeComboBox.SelectedIndex, weaponBindComboBox.SelectedIndex, weaponQuoteTextBox.Text, sheath, weaponDurabilityTextBox.Text, socket_1, socket_2, socket_3, socket_bonus);

                string qry = String.Format("INSERT INTO items (entry, class, subclass, name1, displayid, quality, buyprice, sellprice, inventorytype, allowableclass, allowablerace, itemlevel, requiredlevel, maxcount, dmg_min1, dmg_max1, dmg_type1, dmg_min2, dmg_max2, dmg_type2, armor, holy_res, fire_res, nature_res, frost_res, shadow_res, arcane_res, delay, ammo_type, bonding, description, sheathID, MaxDurability, socket_color_1, socket_color_2, socket_color_3, socket_bonus) VALUES {0}", values);

                MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                MySqlDataReader Reader = cmd.ExecuteReader();

                mConnection.Close();

                MessageBox.Show("Weapon added to Database!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void weaponSaveToSQLFileButton_Click(object sender, EventArgs e)
        {
            if (WeaponSaveSQLFile.ShowDialog() == DialogResult.OK)
            {
                try
                {

                    int sheath = 0;
                    int subclass = 0;
                    int inventorytype = 0;
                    int socket_bonus = 0;

                    int weapon_speed = Convert.ToInt32(TimeSpan.FromSeconds(Convert.ToDouble(weaponSpeedNumericUpDown.Value)).TotalMilliseconds);
                    int buymoney = (Convert.ToInt32(weaponBuyCopperNumericUpDown.Value) % 100) + (Convert.ToInt32(weaponBuySilverNumericUpDown.Value) * 100) + (int.Parse(weaponBuyGoldTextBox.Text) * 10000);
                    int sellmoney = (Convert.ToInt32(weaponSellCopperNumericUpDown.Value) % 100) + (Convert.ToInt32(weaponSellSilverNumericUpDown.Value) * 100) + (int.Parse(weaponSellGoldTextBox.Text) * 10000);

                    switch (weaponTypeComboBox.SelectedIndex)
                    {
                        case 9:
                            subclass = 10;
                            break;
                        case 10:
                            subclass = 13;
                            break;
                        case 11:
                            subclass = 15;
                            break;
                        case 12:
                            subclass = 16;
                            break;
                        case 13:
                            subclass = 17;
                            break;
                        case 14:
                            subclass = 18;
                            break;
                        case 15:
                            subclass = 19;
                            break;
                        default:
                            subclass = weaponTypeComboBox.SelectedIndex;
                            break;
                    }

                    switch (weaponEquipComboBox.SelectedIndex)
                    {
                        case 0:
                            inventorytype = 13;
                            break;
                        case 1:
                            inventorytype = 21;
                            break;
                        case 2:
                            inventorytype = 22;
                            break;
                        case 3:
                            inventorytype = 17;
                            break;
                        case 4:
                            inventorytype = 15;
                            break;
                        case 5:
                            inventorytype = 25;
                            break;
                        case 6:
                            inventorytype = 26;
                            break;
                        case 7:
                            inventorytype = 26;
                            break;
                        default:
                            inventorytype = 13;
                            break;
                    }

                    switch (weaponSheathComboBox.SelectedIndex)
                    {
                        case 0:
                            sheath = 3;
                            break;
                        case 1:
                            sheath = 1;
                            break;
                        case 2:
                            sheath = 2;
                            break;
                        case 3:
                            sheath = 0;
                            break;
                        case 4:
                            sheath = 0;
                            break;
                    }

                    List<int> AllowableClasses = new List<int>();
                    int allowableclass = 0;

                    //Allowable Classes

                    if (weaponWarriorCheckBox.Checked)
                        AllowableClasses.Add(1);

                    if (weaponPaladinCheckBox.Checked)
                        AllowableClasses.Add(2);

                    if (weaponHunterCheckBox.Checked)
                        AllowableClasses.Add(4);

                    if (weaponRogueCheckBox.Checked)
                        AllowableClasses.Add(8);

                    if (weaponPriestCheckBox.Checked)
                        AllowableClasses.Add(16);

                    if (weaponDruidCheckBox.Checked)
                        AllowableClasses.Add(1024);

                    if (weaponShamanCheckBox.Checked)
                        AllowableClasses.Add(64);

                    if (weaponMageCheckBox.Checked)
                        AllowableClasses.Add(128);

                    if (weaponWarlockCheckBox.Checked)
                        AllowableClasses.Add(256);

                    if (weaponDeathKnightCheckBox.Checked)
                        AllowableClasses.Add(32);

                    foreach (int p in AllowableClasses)
                        allowableclass += p;

                    if (allowableclass == 0)
                        allowableclass = -1;

                    List<int> AllowableRaces = new List<int>();
                    int allowablerace = 0;

                    if (weaponHumanCheckBox.Checked)
                        AllowableRaces.Add(1);

                    if (weaponOrcCheckBox.Checked)
                        AllowableRaces.Add(2);

                    if (weaponDwarfCheckBox.Checked)
                        AllowableRaces.Add(4);

                    if (weaponNightElfCheckBox.Checked)
                        AllowableRaces.Add(8);

                    if (weaponUndeadCheckBox.Checked)
                        AllowableRaces.Add(16);

                    if (weaponTaurenCheckBox.Checked)
                        AllowableRaces.Add(32);

                    if (weaponGnomeCheckBox.Checked)
                        AllowableRaces.Add(64);

                    if (weaponTrollCheckBox.Checked)
                        AllowableRaces.Add(128);

                    if (weaponBloodElfCheckBox.Checked)
                        AllowableRaces.Add(512);

                    if (weaponDraeneiCheckBox.Checked)
                        AllowableRaces.Add(1024);

                    foreach (int p in AllowableRaces)
                        allowablerace += p;

                    if (allowablerace == 0)
                        allowablerace = -1;

                    switch (weaponSocketBonusComboBox.SelectedIndex)
                    {
                        case 1:
                            socket_bonus = 90;
                            break;
                        case 2:
                            socket_bonus = 106;
                            break;
                        case 3:
                            socket_bonus = 2883;
                            break;
                        case 4:
                            socket_bonus = 2869;
                            break;
                        case 5:
                            socket_bonus = 2890;
                            break;
                        case 6:
                            socket_bonus = 2900;
                            break;
                        case 7:
                            socket_bonus = 1583;
                            break;
                        case 8:
                            socket_bonus = 2873;
                            break;
                        case 9:
                            socket_bonus = 2874;
                            break;
                    }

                    int socket_1 = 0;
                    int socket_2 = 0;
                    int socket_3 = 0;

                    if (!weaponSocket1BlueButton.Enabled)
                        socket_1 = 8;

                    else if (!weaponSocket1RedButton.Enabled)
                        socket_1 = 2;

                    else if (!weaponSocket1YellowButton.Enabled)
                        socket_1 = 4;


                    if (!weaponSocket2BlueButton.Enabled)
                        socket_2 = 8;

                    else if (!weaponSocket2RedButton.Enabled)
                        socket_2 = 2;

                    else if (!weaponSocket2YellowButton.Enabled)
                        socket_2 = 4;


                    if (!weaponSocket3BlueButton.Enabled)
                        socket_3 = 8;

                    else if (!weaponSocket3RedButton.Enabled)
                        socket_3 = 2;

                    else if (!weaponSocket3YellowButton.Enabled)
                        socket_3 = 4;


                    string values = String.Format("('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', '{14}', '{15}', '{16}', '{17}', '{18}', '{19}', '{20}', '{21}', '{22}', '{23}', '{24}', '{25}', '{26}', '{27}', '{28}', '{29}', '{30}', '{31}', '{32}', '{33}', '{34}', '{35}', '{36}');",
                             weaponEntryIDTextBox.Text, "2", subclass, weaponNameTextBox.Text, weaponDisplayIDTextBox.Text, weaponQualityComboBox.SelectedIndex, buymoney, sellmoney, inventorytype,
                             allowableclass, allowablerace, weaponItemLevelTextBox.Text, weaponRequiredLevelTextBox.Text, weaponMaxTextBox.Text, weaponDamageMin1TextBox.Text, weaponDamageMax1TextBox.Text, weaponDamageType1ComboBox.SelectedIndex, weaponDamageMin2TextBox.Text, weaponDamageMax2TextBox.Text, weaponDamageType2ComboBox.SelectedIndex, weaponBlockArmorTextBox.Text, weaponHolyTextBox.Text, weaponFireTextBox.Text, weaponNatureTextBox.Text, weaponFrostTextBox.Text, weaponShadowTextBox.Text, weaponArcaneTextBox.Text, weapon_speed, weaponAmmoTypeComboBox.SelectedIndex, weaponBindComboBox.SelectedIndex, weaponQuoteTextBox.Text, sheath, weaponDurabilityTextBox.Text, socket_1, socket_2, socket_3, socket_bonus);

                    string qry = String.Format("INSERT INTO items (entry, class, subclass, name1, displayid, quality, buyprice, sellprice, inventorytype, allowableclass, allowablerace, itemlevel, requiredlevel, maxcount, dmg_min1, dmg_max1, dmg_type1, dmg_min2, dmg_max2, dmg_type2, armor, holy_res, fire_res, nature_res, frost_res, shadow_res, arcane_res, delay, ammo_type, bonding, description, sheathID, MaxDurability, socket_color_1, socket_color_2, socket_color_3, socket_bonus) VALUES {0}", values);

                    StreamWriter writer = new StreamWriter(WeaponSaveSQLFile.FileName);

                    writer.WriteLine(qry);

                    writer.Close();

                    MessageBox.Show("SQL File Saved!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void weaponDisplayIDTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponEntryIDTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponDurabilityTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponSpeedTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponBlockTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponBlockArmorTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponRequiredLevelTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponItemLevelTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponMaxTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponStackableTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponDamageMin1TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponDamageMax1TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponDamageMin2TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponDamageMax2TextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponHolyTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponNatureTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponShadowTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponFireTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponFrostTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponArcaneTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponBuyGoldTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponSellGoldTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void weaponSocket1NoneButton_Click(object sender, EventArgs e)
        {
            weaponSocket1NoneButton.Enabled = false;
            weaponSocket1BlueButton.Enabled = true;
            weaponSocket1RedButton.Enabled = true;
            weaponSocket1YellowButton.Enabled = true;
        }

        private void weaponSocket1BlueButton_Click(object sender, EventArgs e)
        {
            weaponSocket1BlueButton.Enabled = false;
            weaponSocket1NoneButton.Enabled = true;
            weaponSocket1RedButton.Enabled = true;
            weaponSocket1YellowButton.Enabled = true;
        }

        private void weaponSocket1RedButton_Click(object sender, EventArgs e)
        {
            weaponSocket1RedButton.Enabled = false;
            weaponSocket1NoneButton.Enabled = true;
            weaponSocket1BlueButton.Enabled = true;
            weaponSocket1YellowButton.Enabled = true;
        }

        private void weaponSocket1YellowButton_Click(object sender, EventArgs e)
        {
            weaponSocket1YellowButton.Enabled = false;
            weaponSocket1NoneButton.Enabled = true;
            weaponSocket1BlueButton.Enabled = true;
            weaponSocket1RedButton.Enabled = true;
        }

        private void weaponSocket2NoneButton_Click(object sender, EventArgs e)
        {
            weaponSocket2NoneButton.Enabled = false;
            weaponSocket2BlueButton.Enabled = true;
            weaponSocket2RedButton.Enabled = true;
            weaponSocket2YellowButton.Enabled = true;
        }

        private void weaponSocket2BlueButton_Click(object sender, EventArgs e)
        {
            weaponSocket2BlueButton.Enabled = false;
            weaponSocket2NoneButton.Enabled = true;
            weaponSocket2RedButton.Enabled = true;
            weaponSocket2YellowButton.Enabled = true;
        }

        private void weaponSocket2RedButton_Click(object sender, EventArgs e)
        {
            weaponSocket2RedButton.Enabled = false;
            weaponSocket2NoneButton.Enabled = true;
            weaponSocket2BlueButton.Enabled = true;
            weaponSocket2YellowButton.Enabled = true;
        }

        private void weaponSocket2YellowButton_Click(object sender, EventArgs e)
        {
            weaponSocket2YellowButton.Enabled = false;
            weaponSocket2NoneButton.Enabled = true;
            weaponSocket2BlueButton.Enabled = true;
            weaponSocket2RedButton.Enabled = true;
        }

        private void weaponSocket3NoneButton_Click(object sender, EventArgs e)
        {
            weaponSocket3NoneButton.Enabled = false;
            weaponSocket3BlueButton.Enabled = true;
            weaponSocket3RedButton.Enabled = true;
            weaponSocket3YellowButton.Enabled = true;
        }

        private void weaponSocket3BlueButton_Click(object sender, EventArgs e)
        {
            weaponSocket3BlueButton.Enabled = false;
            weaponSocket3NoneButton.Enabled = true;
            weaponSocket3RedButton.Enabled = true;
            weaponSocket3YellowButton.Enabled = true;
        }

        private void weaponSocket3RedButton_Click(object sender, EventArgs e)
        {
            weaponSocket3RedButton.Enabled = false;
            weaponSocket3NoneButton.Enabled = true;
            weaponSocket3BlueButton.Enabled = true;
            weaponSocket3YellowButton.Enabled = true;
        }

        private void weaponSocket3YellowButton_Click(object sender, EventArgs e)
        {
            weaponSocket3YellowButton.Enabled = false;
            weaponSocket3NoneButton.Enabled = true;
            weaponSocket3BlueButton.Enabled = true;
            weaponSocket3RedButton.Enabled = true;
        }

        private void weaponClassAllCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (weaponClassAllCheckBox.Checked == true)
            {
                weaponWarriorCheckBox.Checked = true;
                weaponPaladinCheckBox.Checked = true;
                weaponHunterCheckBox.Checked = true;
                weaponRogueCheckBox.Checked = true;
                weaponPriestCheckBox.Checked = true;
                weaponDruidCheckBox.Checked = true;
                weaponShamanCheckBox.Checked = true;
                weaponMageCheckBox.Checked = true;
                weaponWarlockCheckBox.Checked = true;
                weaponDeathKnightCheckBox.Checked = true;
            }
            else
            {
                weaponWarriorCheckBox.Checked = false;
                weaponPaladinCheckBox.Checked = false;
                weaponHunterCheckBox.Checked = false;
                weaponRogueCheckBox.Checked = false;
                weaponPriestCheckBox.Checked = false;
                weaponDruidCheckBox.Checked = false;
                weaponShamanCheckBox.Checked = false;
                weaponMageCheckBox.Checked = false;
                weaponWarlockCheckBox.Checked = false;
                weaponDeathKnightCheckBox.Checked = false;
            }
        }

        private void weaponRaceAllCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (weaponRaceAllCheckBox.Checked == true)
            {
                weaponHumanCheckBox.Checked = true;
                weaponOrcCheckBox.Checked = true;
                weaponDwarfCheckBox.Checked = true;
                weaponNightElfCheckBox.Checked = true;
                weaponUndeadCheckBox.Checked = true;
                weaponTaurenCheckBox.Checked = true;
                weaponGnomeCheckBox.Checked = true;
                weaponTrollCheckBox.Checked = true;
                weaponBloodElfCheckBox.Checked = true;
                weaponDraeneiCheckBox.Checked = true;
            }
            else
            {
                weaponHumanCheckBox.Checked = false;
                weaponOrcCheckBox.Checked = false;
                weaponDwarfCheckBox.Checked = false;
                weaponNightElfCheckBox.Checked = false;
                weaponUndeadCheckBox.Checked = false;
                weaponTaurenCheckBox.Checked = false;
                weaponGnomeCheckBox.Checked = false;
                weaponTrollCheckBox.Checked = false;
                weaponBloodElfCheckBox.Checked = false;
                weaponDraeneiCheckBox.Checked = false;
            }
        }

        private void armorDetailsNextButton_Click(object sender, EventArgs e)
        {
            if (armorNameTextBox.Text != String.Empty && armorDisplayIDTextBox.Text != String.Empty && armorEntryIDTextBox.Text != String.Empty && armorDurabilityTextBox.Text != String.Empty)
            {
                if (!armorTabControl.Contains(armorStatsTabPage))
                {
                    armorTabControl.TabPages.Add(armorStatsTabPage);
                    armorTabControl.SelectedIndex = armorTabControl.TabPages.IndexOf(armorStatsTabPage);
                }
                else
                {
                    armorTabControl.SelectedIndex = armorTabControl.TabPages.IndexOf(armorStatsTabPage);
                }
            }
            else
            {
                MessageBox.Show("You must fill out the required fields!");
            }
        }

        private void armorSearchDisplayIDs_Click(object sender, EventArgs e)
        {
            SearchArmorDisplayID armorsearch = new SearchArmorDisplayID();

            armorsearch.Show();

            armorsearch.FormClosing += new FormClosingEventHandler(armorsearch_FormClosing);
        }

        private void armorsearch_FormClosing(object sender, FormClosingEventArgs e)
        {
            SearchArmorDisplayID search = (SearchArmorDisplayID)sender;

            if (search.GetDisplayID() != String.Empty && search.buttonPressed == true)
            {
                armorDisplayIDTextBox.Text = search.GetDisplayID();
            }
        }

        private void armorStatsNextButton_Click(object sender, EventArgs e)
        {
            if (armorStatsBlockTextBox.Text != String.Empty && armorStatsArmorTextBox.Text != String.Empty)
            {
                if (!armorTabControl.Contains(armorRequirementsTabPage))
                {
                    armorTabControl.TabPages.Add(armorRequirementsTabPage);
                    armorTabControl.SelectedIndex = armorTabControl.TabPages.IndexOf(armorRequirementsTabPage);
                }
                else
                {
                    armorTabControl.SelectedIndex = armorTabControl.TabPages.IndexOf(armorRequirementsTabPage);
                }
            }
            else
            {
                MessageBox.Show("You must fill out the required fields!");
            }
        }

        private void armorRequirementsNextButton_Click(object sender, EventArgs e)
        {
            if (armorRequiredLevelTextBox.Text != String.Empty && armorItemLevelTextBox.Text != String.Empty && armorMaxTextBox.Text != String.Empty && armorStackableTextBox.Text != String.Empty)
            {
                if (!armorTabControl.Contains(armorSocketsTabPage))
                {
                    armorTabControl.TabPages.Add(armorSocketsTabPage);
                    armorTabControl.SelectedIndex = armorTabControl.TabPages.IndexOf(armorSocketsTabPage);
                }
                else
                {
                    armorTabControl.SelectedIndex = armorTabControl.TabPages.IndexOf(armorSocketsTabPage);
                }
            }
            else
            {
                MessageBox.Show("You must fill out the required fields!");
            }
        }

        private void armorSocketsNextButton_Click(object sender, EventArgs e)
        {
            if (!armorTabControl.Contains(armorPriceTabPage))
            {
                armorTabControl.TabPages.Add(armorPriceTabPage);
                armorTabControl.SelectedIndex = armorTabControl.TabPages.IndexOf(armorPriceTabPage);
            }
            else
            {
                armorTabControl.SelectedIndex = armorTabControl.TabPages.IndexOf(armorPriceTabPage);
            }
        }

        private void armorSellPriceNextButton_Click(object sender, EventArgs e)
        {
            if (armorBuyGoldTextBox.Text != String.Empty && ((Control)armorBuySilverNumericUpDown).Text != String.Empty && ((Control)armorBuyCopperNumericUpDown).Text != String.Empty &&
                armorSellGoldTextBox.Text != String.Empty && ((Control)armorSellSilverNumericUpDown).Text != String.Empty && ((Control)armorSellCopperNumericUpDown).Text != String.Empty)
            {
                if (!armorTabControl.Contains(armorFinishTabPage))
                {
                    armorTabControl.TabPages.Add(armorFinishTabPage);
                    armorTabControl.SelectedIndex = armorTabControl.TabPages.IndexOf(armorFinishTabPage);

                    armorTabControl.TabPages.Remove(armorDetailsTabPage);
                    armorTabControl.TabPages.Remove(armorStatsTabPage);
                    armorTabControl.TabPages.Remove(armorRequirementsTabPage);
                    armorTabControl.TabPages.Remove(armorSocketsTabPage);
                    armorTabControl.TabPages.Remove(armorPriceTabPage);
                }
                else
                {
                    armorTabControl.SelectedIndex = armorTabControl.TabPages.IndexOf(armorFinishTabPage);
                }
            }
            else
            {
                MessageBox.Show("You must fill out the required fields!");
            }
        }

        private void armorStartOverButton_Click(object sender, EventArgs e)
        {
            //Start Over

            armorTabControl.TabPages.Remove(armorFinishTabPage);

            armorTabControl.TabPages.Add(armorDetailsTabPage);

            armorTabControl.SelectedIndex = armorTabControl.TabPages.IndexOf(armorDetailsTabPage);

            //Reset Everything//

            //Details

            armorNameTextBox.Text = String.Empty;
            armorQuoteTextBox.Text = String.Empty;
            armorDisplayIDTextBox.Text = String.Empty;
            armorEntryIDTextBox.Text = String.Empty;
            armorQualityComboBox.SelectedIndex = 0;
            armorEquipComboBox.SelectedIndex = 0;
            armorMaterialComboBox.SelectedIndex = 0;
            armorDurabilityTextBox.Text = Convert.ToString(0);
            armorBindsComboBox.SelectedIndex = 0;

            //Stats

            armorStatsBlockTextBox.Text = Convert.ToString(0);
            armorStatsArmorTextBox.Text = Convert.ToString(0);

            //Requirements

            armorRequiredLevelTextBox.Text = Convert.ToString(0);
            armorItemLevelTextBox.Text = Convert.ToString(0);
            armorMaxTextBox.Text = Convert.ToString(1);
            armorStackableTextBox.Text = Convert.ToString(0);

            armorClassAllCheckBox.Checked = false;

            armorWarriorCheckBox.Checked = false;
            armorPaladinCheckBox.Checked = false;
            armorHunterCheckBox.Checked = false;
            armorRogueCheckBox.Checked = false;
            armorPriestCheckBox.Checked = false;
            armorDruidCheckBox.Checked = false;
            armorShamanCheckBox.Checked = false;
            armorMageCheckBox.Checked = false;
            armorWarlockCheckBox.Checked = false;
            armorDeathKnightCheckBox.Checked = false;

            armorRaceAllCheckBox.Checked = false;

            armorHumanCheckBox.Checked = false;
            armorOrcCheckBox.Checked = false;
            armorDwarfCheckBox.Checked = false;
            armorNightElfCheckBox.Checked = false;
            armorUndeadCheckBox.Checked = false;
            armorTaurenCheckBox.Checked = false;
            armorGnomeCheckBox.Checked = false;
            armorTrollCheckBox.Checked = false;
            armorBloodElfCheckBox.Checked = false;
            armorDraeneiCheckBox.Checked = false;

            //Sockets

            armorSocket1NoneButton.Enabled = false;

            armorSocket1BlueButton.Enabled = true;
            armorSocket1RedButton.Enabled = true;
            armorSocket1YellowButton.Enabled = true;

            armorSocket2NoneButton.Enabled = false;

            armorSocket2BlueButton.Enabled = true;
            armorSocket2RedButton.Enabled = true;
            armorSocket2YellowButton.Enabled = true;

            armorSocket3NoneButton.Enabled = false;
            armorSocket3BlueButton.Enabled = true;
            armorSocket3RedButtton.Enabled = true;
            armorSocket3YellowButton.Enabled = true;

            armorBonusComboBox.SelectedIndex = 0;

            //Price

            armorBuyGoldTextBox.Text = Convert.ToString(0);
            armorBuySilverNumericUpDown.Value = 0;
            armorBuyCopperNumericUpDown.Value = 0;

            armorSellGoldTextBox.Text = Convert.ToString(0);
            armorSellSilverNumericUpDown.Value = 0;
            armorSellCopperNumericUpDown.Value = 0;

            //End Reset//

        }

        private void armorSaveToDBButton_Click(object sender, EventArgs e)
        {
            try
            {
                string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.worlddb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                MySqlConnection mConnection = new MySqlConnection(connection);

                mConnection.Open();

                int inventorytype = 0;
                int socket_bonus = 0;

                int buymoney = (Convert.ToInt32(armorBuyCopperNumericUpDown.Value) % 100) + (Convert.ToInt32(armorBuySilverNumericUpDown.Value) * 100) + (int.Parse(armorBuyGoldTextBox.Text) * 10000);
                int sellmoney = (Convert.ToInt32(armorSellCopperNumericUpDown.Value) % 100) + (Convert.ToInt32(armorSellSilverNumericUpDown.Value) * 100) + (int.Parse(armorSellGoldTextBox.Text) * 10000);

                switch (armorEquipComboBox.SelectedIndex)
                {
                    case 0:
                        inventorytype = 1;
                        break;
                    case 1:
                        inventorytype = 3;
                        break;
                    case 2:
                        inventorytype = 4;
                        break;
                    case 3:
                        inventorytype = 5;
                        break;
                    case 4:
                        inventorytype = 6;
                        break;
                    case 5:
                        inventorytype = 7;
                        break;
                    case 6:
                        inventorytype = 8;
                        break;
                    case 7:
                        inventorytype = 9;
                        break;
                    case 8:
                        inventorytype = 16;
                        break;
                    case 9:
                        inventorytype = 19;
                        break;
                    case 10:
                        inventorytype = 20;
                        break;
                    case 11:
                        inventorytype = 14;
                        break;
                    case 12:
                        inventorytype = 23;
                        break;
                }

                List<int> AllowableClasses = new List<int>();
                int allowableclass = 0;

                //Allowable Classes

                if (weaponWarriorCheckBox.Checked)
                    AllowableClasses.Add(1);

                if (weaponPaladinCheckBox.Checked)
                    AllowableClasses.Add(2);

                if (weaponHunterCheckBox.Checked)
                    AllowableClasses.Add(4);

                if (weaponRogueCheckBox.Checked)
                    AllowableClasses.Add(8);

                if (weaponPriestCheckBox.Checked)
                    AllowableClasses.Add(16);

                if (weaponDruidCheckBox.Checked)
                    AllowableClasses.Add(1024);

                if (weaponShamanCheckBox.Checked)
                    AllowableClasses.Add(64);

                if (weaponMageCheckBox.Checked)
                    AllowableClasses.Add(128);

                if (weaponWarlockCheckBox.Checked)
                    AllowableClasses.Add(256);

                if (weaponDeathKnightCheckBox.Checked)
                    AllowableClasses.Add(32);

                foreach (int p in AllowableClasses)
                    allowableclass += p;

                if (allowableclass == 0)
                    allowableclass = -1;

                List<int> AllowableRaces = new List<int>();
                int allowablerace = 0;

                if (weaponHumanCheckBox.Checked)
                    AllowableRaces.Add(1);

                if (weaponOrcCheckBox.Checked)
                    AllowableRaces.Add(2);

                if (weaponDwarfCheckBox.Checked)
                    AllowableRaces.Add(4);

                if (weaponNightElfCheckBox.Checked)
                    AllowableRaces.Add(8);

                if (weaponUndeadCheckBox.Checked)
                    AllowableRaces.Add(16);

                if (weaponTaurenCheckBox.Checked)
                    AllowableRaces.Add(32);

                if (weaponGnomeCheckBox.Checked)
                    AllowableRaces.Add(64);

                if (weaponTrollCheckBox.Checked)
                    AllowableRaces.Add(128);

                if (weaponBloodElfCheckBox.Checked)
                    AllowableRaces.Add(512);

                if (weaponDraeneiCheckBox.Checked)
                    AllowableRaces.Add(1024);

                foreach (int p in AllowableRaces)
                    allowablerace += p;

                if (allowablerace == 0)
                    allowablerace = -1;

                switch (armorBonusComboBox.SelectedIndex)
                {
                    case 1:
                        socket_bonus = 90;
                        break;
                    case 2:
                        socket_bonus = 106;
                        break;
                    case 3:
                        socket_bonus = 2883;
                        break;
                    case 4:
                        socket_bonus = 2869;
                        break;
                    case 5:
                        socket_bonus = 2890;
                        break;
                    case 6:
                        socket_bonus = 2900;
                        break;
                    case 7:
                        socket_bonus = 1583;
                        break;
                    case 8:
                        socket_bonus = 2873;
                        break;
                    case 9:
                        socket_bonus = 2874;
                        break;
                }

                int socket_1 = 0;
                int socket_2 = 0;
                int socket_3 = 0;

                if (!armorSocket1BlueButton.Enabled)
                    socket_1 = 8;

                else if (!armorSocket1RedButton.Enabled)
                    socket_1 = 2;

                else if (!armorSocket1YellowButton.Enabled)
                    socket_1 = 4;


                if (!armorSocket3BlueButton.Enabled)
                    socket_2 = 8;

                else if (!armorSocket2RedButton.Enabled)
                    socket_2 = 2;

                else if (!armorSocket2YellowButton.Enabled)
                    socket_2 = 4;


                if (!armorSocket3BlueButton.Enabled)
                    socket_3 = 8;

                else if (!armorSocket3RedButtton.Enabled)
                    socket_3 = 2;

                else if (!armorSocket3YellowButton.Enabled)
                    socket_3 = 4;

                int subclass = armorMaterialComboBox.SelectedIndex + 1;

                string values = String.Format("('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', '{14}', '{15}', '{16}', '{17}', '{18}', '{19}', '{20}', '{21}');",
                         armorEntryIDTextBox.Text, "4", subclass, armorNameTextBox.Text, armorDisplayIDTextBox.Text, armorQualityComboBox.SelectedIndex, buymoney, sellmoney, inventorytype,
                         allowableclass, allowablerace, armorItemLevelTextBox.Text, armorRequiredLevelTextBox.Text, armorMaxTextBox.Text, armorStatsArmorTextBox.Text, armorBindsComboBox.SelectedIndex, armorQuoteTextBox.Text, armorDurabilityTextBox.Text, socket_1, socket_2, socket_3, socket_bonus);

                string qry = String.Format("INSERT INTO items (entry, class, subclass, name1, displayid, quality, buyprice, sellprice, inventorytype, allowableclass, allowablerace, itemlevel, requiredlevel, maxcount, armor, bonding, description, MaxDurability, socket_color_1, socket_color_2, socket_color_3, socket_bonus) VALUES {0}", values);

                MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                MySqlDataReader Reader = cmd.ExecuteReader();

                mConnection.Close();

                MessageBox.Show("Item added to Database!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void armorSaveToSQLButton_Click(object sender, EventArgs e)
        {
            if (ArmorSaveSQLFile.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    int inventorytype = 0;
                    int socket_bonus = 0;

                    int buymoney = (Convert.ToInt32(armorBuyCopperNumericUpDown.Value) % 100) + (Convert.ToInt32(armorBuySilverNumericUpDown.Value) * 100) + (int.Parse(armorBuyGoldTextBox.Text) * 10000);
                    int sellmoney = (Convert.ToInt32(armorSellCopperNumericUpDown.Value) % 100) + (Convert.ToInt32(armorSellSilverNumericUpDown.Value) * 100) + (int.Parse(armorSellGoldTextBox.Text) * 10000);

                    switch (armorEquipComboBox.SelectedIndex)
                    {
                        case 0:
                            inventorytype = 1;
                            break;
                        case 1:
                            inventorytype = 3;
                            break;
                        case 2:
                            inventorytype = 4;
                            break;
                        case 3:
                            inventorytype = 5;
                            break;
                        case 4:
                            inventorytype = 6;
                            break;
                        case 5:
                            inventorytype = 7;
                            break;
                        case 6:
                            inventorytype = 8;
                            break;
                        case 7:
                            inventorytype = 9;
                            break;
                        case 8:
                            inventorytype = 16;
                            break;
                        case 9:
                            inventorytype = 19;
                            break;
                        case 10:
                            inventorytype = 20;
                            break;
                        case 11:
                            inventorytype = 14;
                            break;
                        case 12:
                            inventorytype = 23;
                            break;
                    }

                    List<int> AllowableClasses = new List<int>();
                    int allowableclass = 0;

                    //Allowable Classes

                    if (weaponWarriorCheckBox.Checked)
                        AllowableClasses.Add(1);

                    if (weaponPaladinCheckBox.Checked)
                        AllowableClasses.Add(2);

                    if (weaponHunterCheckBox.Checked)
                        AllowableClasses.Add(4);

                    if (weaponRogueCheckBox.Checked)
                        AllowableClasses.Add(8);

                    if (weaponPriestCheckBox.Checked)
                        AllowableClasses.Add(16);

                    if (weaponDruidCheckBox.Checked)
                        AllowableClasses.Add(1024);

                    if (weaponShamanCheckBox.Checked)
                        AllowableClasses.Add(64);

                    if (weaponMageCheckBox.Checked)
                        AllowableClasses.Add(128);

                    if (weaponWarlockCheckBox.Checked)
                        AllowableClasses.Add(256);

                    if (weaponDeathKnightCheckBox.Checked)
                        AllowableClasses.Add(32);

                    foreach (int p in AllowableClasses)
                        allowableclass += p;

                    if (allowableclass == 0)
                        allowableclass = -1;

                    List<int> AllowableRaces = new List<int>();
                    int allowablerace = 0;

                    if (weaponHumanCheckBox.Checked)
                        AllowableRaces.Add(1);

                    if (weaponOrcCheckBox.Checked)
                        AllowableRaces.Add(2);

                    if (weaponDwarfCheckBox.Checked)
                        AllowableRaces.Add(4);

                    if (weaponNightElfCheckBox.Checked)
                        AllowableRaces.Add(8);

                    if (weaponUndeadCheckBox.Checked)
                        AllowableRaces.Add(16);

                    if (weaponTaurenCheckBox.Checked)
                        AllowableRaces.Add(32);

                    if (weaponGnomeCheckBox.Checked)
                        AllowableRaces.Add(64);

                    if (weaponTrollCheckBox.Checked)
                        AllowableRaces.Add(128);

                    if (weaponBloodElfCheckBox.Checked)
                        AllowableRaces.Add(512);

                    if (weaponDraeneiCheckBox.Checked)
                        AllowableRaces.Add(1024);

                    foreach (int p in AllowableRaces)
                        allowablerace += p;

                    if (allowablerace == 0)
                        allowablerace = -1;

                    switch (armorBonusComboBox.SelectedIndex)
                    {
                        case 1:
                            socket_bonus = 90;
                            break;
                        case 2:
                            socket_bonus = 106;
                            break;
                        case 3:
                            socket_bonus = 2883;
                            break;
                        case 4:
                            socket_bonus = 2869;
                            break;
                        case 5:
                            socket_bonus = 2890;
                            break;
                        case 6:
                            socket_bonus = 2900;
                            break;
                        case 7:
                            socket_bonus = 1583;
                            break;
                        case 8:
                            socket_bonus = 2873;
                            break;
                        case 9:
                            socket_bonus = 2874;
                            break;
                    }

                    int socket_1 = 0;
                    int socket_2 = 0;
                    int socket_3 = 0;

                    if (!armorSocket1BlueButton.Enabled)
                        socket_1 = 8;

                    else if (!armorSocket1RedButton.Enabled)
                        socket_1 = 2;

                    else if (!armorSocket1YellowButton.Enabled)
                        socket_1 = 4;


                    if (!armorSocket3BlueButton.Enabled)
                        socket_2 = 8;

                    else if (!armorSocket2RedButton.Enabled)
                        socket_2 = 2;

                    else if (!armorSocket2YellowButton.Enabled)
                        socket_2 = 4;


                    if (!armorSocket3BlueButton.Enabled)
                        socket_3 = 8;

                    else if (!armorSocket3RedButtton.Enabled)
                        socket_3 = 2;

                    else if (!armorSocket3YellowButton.Enabled)
                        socket_3 = 4;

                    int subclass = armorMaterialComboBox.SelectedIndex + 1;

                    string values = String.Format("('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', '{14}', '{15}', '{16}', '{17}', '{18}', '{19}', '{20}', '{21}');",
                         armorEntryIDTextBox.Text, "4", subclass, armorNameTextBox.Text, armorDisplayIDTextBox.Text, armorQualityComboBox.SelectedIndex, buymoney, sellmoney, inventorytype,
                         allowableclass, allowablerace, armorItemLevelTextBox.Text, armorRequiredLevelTextBox.Text, armorMaxTextBox.Text, armorStatsArmorTextBox.Text, armorBindsComboBox.SelectedIndex, armorQuoteTextBox.Text, armorDurabilityTextBox.Text, socket_1, socket_2, socket_3, socket_bonus);

                    string qry = String.Format("INSERT INTO items (entry, class, subclass, name1, displayid, quality, buyprice, sellprice, inventorytype, allowableclass, allowablerace, itemlevel, requiredlevel, maxcount, armor, bonding, description, MaxDurability, socket_color_1, socket_color_2, socket_color_3, socket_bonus) VALUES {0}", values);

                    StreamWriter writer = new StreamWriter(ArmorSaveSQLFile.FileName);

                    writer.WriteLine(qry);

                    writer.Close();

                    MessageBox.Show("SQL File Saved!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void armorDisplayIDTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void armorEntryIDTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void armorDurabilityTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void armorStatsBlockTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void armorStatsArmorTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void armorRequiredLevelTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void armorItemLevelTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void armorMaxTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void armorStackableTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void armorBuyGoldTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void armorSellGoldTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void armorClassAllCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (armorClassAllCheckBox.Checked == true)
            {
                armorWarriorCheckBox.Checked = true;
                armorPaladinCheckBox.Checked = true;
                armorHunterCheckBox.Checked = true;
                armorRogueCheckBox.Checked = true;
                armorPriestCheckBox.Checked = true;
                armorDruidCheckBox.Checked = true;
                armorShamanCheckBox.Checked = true;
                armorMageCheckBox.Checked = true;
                armorWarlockCheckBox.Checked = true;
                armorDeathKnightCheckBox.Checked = true;
            }
            else
            {
                armorWarriorCheckBox.Checked = false;
                armorPaladinCheckBox.Checked = false;
                armorHunterCheckBox.Checked = false;
                armorRogueCheckBox.Checked = false;
                armorPriestCheckBox.Checked = false;
                armorDruidCheckBox.Checked = false;
                armorShamanCheckBox.Checked = false;
                armorMageCheckBox.Checked = false;
                armorWarlockCheckBox.Checked = false;
                armorDeathKnightCheckBox.Checked = false;
            }
        }

        private void armorRaceAllCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (armorRaceAllCheckBox.Checked == true)
            {
                armorHumanCheckBox.Checked = true;
                armorOrcCheckBox.Checked = true;
                armorDwarfCheckBox.Checked = true;
                armorNightElfCheckBox.Checked = true;
                armorUndeadCheckBox.Checked = true;
                armorTaurenCheckBox.Checked = true;
                armorGnomeCheckBox.Checked = true;
                armorTrollCheckBox.Checked = true;
                armorBloodElfCheckBox.Checked = true;
                armorDraeneiCheckBox.Checked = true;
            }
            else
            {
                armorHumanCheckBox.Checked = false;
                armorOrcCheckBox.Checked = false;
                armorDwarfCheckBox.Checked = false;
                armorNightElfCheckBox.Checked = false;
                armorUndeadCheckBox.Checked = false;
                armorTaurenCheckBox.Checked = false;
                armorGnomeCheckBox.Checked = false;
                armorTrollCheckBox.Checked = false;
                armorBloodElfCheckBox.Checked = false;
                armorDraeneiCheckBox.Checked = false;
            }
        }

        private void armorSocket1NoneButton_Click(object sender, EventArgs e)
        {
            armorSocket1NoneButton.Enabled = false;

            armorSocket1BlueButton.Enabled = true;
            armorSocket1RedButton.Enabled = true;
            armorSocket1YellowButton.Enabled = true;
        }

        private void armorSocket1BlueButton_Click(object sender, EventArgs e)
        {
            armorSocket1BlueButton.Enabled = false;

            armorSocket1NoneButton.Enabled = true;
            armorSocket1RedButton.Enabled = true;
            armorSocket1YellowButton.Enabled = true;
        }

        private void armorSocket1RedButton_Click(object sender, EventArgs e)
        {
            armorSocket1RedButton.Enabled = false;

            armorSocket1NoneButton.Enabled = true;
            armorSocket1BlueButton.Enabled = true;
            armorSocket1YellowButton.Enabled = true;
        }

        private void armorSocket1YellowButton_Click(object sender, EventArgs e)
        {
            armorSocket1YellowButton.Enabled = false;

            armorSocket1NoneButton.Enabled = true;
            armorSocket1BlueButton.Enabled = true;
            armorSocket1RedButton.Enabled = true;
        }

        private void armorSocket2NoneButton_Click(object sender, EventArgs e)
        {
            armorSocket2NoneButton.Enabled = false;

            armorSocket2BlueButton.Enabled = true;
            armorSocket2RedButton.Enabled = true;
            armorSocket2YellowButton.Enabled = true;
        }

        private void armorSocket2BlueButton_Click(object sender, EventArgs e)
        {
            armorSocket2BlueButton.Enabled = false;

            armorSocket2NoneButton.Enabled = true;
            armorSocket2RedButton.Enabled = true;
            armorSocket2YellowButton.Enabled = true;
        }

        private void armorSocket2RedButton_Click(object sender, EventArgs e)
        {
            armorSocket2RedButton.Enabled = false;

            armorSocket2NoneButton.Enabled = true;
            armorSocket2BlueButton.Enabled = true;
            armorSocket2YellowButton.Enabled = true;
        }

        private void armorSocket2YellowButton_Click(object sender, EventArgs e)
        {
            armorSocket2YellowButton.Enabled = false;

            armorSocket2NoneButton.Enabled = true;
            armorSocket2BlueButton.Enabled = true;
            armorSocket2RedButton.Enabled = true;
        }

        private void armorSocket3NoneButton_Click(object sender, EventArgs e)
        {
            armorSocket3NoneButton.Enabled = false;

            armorSocket3BlueButton.Enabled = true;
            armorSocket3RedButtton.Enabled = true;
            armorSocket3YellowButton.Enabled = true;
        }

        private void armorSocket3BlueButton_Click(object sender, EventArgs e)
        {
            armorSocket3BlueButton.Enabled = false;

            armorSocket3NoneButton.Enabled = true;
            armorSocket3RedButtton.Enabled = true;
            armorSocket3YellowButton.Enabled = true;
        }

        private void armorSocket3RedButtton_Click(object sender, EventArgs e)
        {
            armorSocket3RedButtton.Enabled = false;

            armorSocket3NoneButton.Enabled = true;
            armorSocket3BlueButton.Enabled = true;
            armorSocket3YellowButton.Enabled = true;
        }

        private void armorSocket3YellowButton_Click(object sender, EventArgs e)
        {
            armorSocket3YellowButton.Enabled = false;

            armorSocket3NoneButton.Enabled = true;
            armorSocket3BlueButton.Enabled = true;
            armorSocket3RedButtton.Enabled = true;
        }

        private void lootSearchNPCButton_Click(object sender, EventArgs e)
        {
            SearchNPCDisplayID lootnpcsearch = new SearchNPCDisplayID();

            lootnpcsearch.Show();

            lootnpcsearch.FormClosing += new FormClosingEventHandler(lootnpcsearch_FormClosing);
        }

        private void lootnpcsearch_FormClosing(object sender, FormClosingEventArgs e)
        {
            SearchNPCDisplayID search = (SearchNPCDisplayID)sender;

            if (search.GetEntryID() != String.Empty && search.buttonPressed == true)
            {
                lootNPCEntryIDTextBox.Text = search.GetEntryID();
            }
        }

        private void lootSearchItemButton_Click(object sender, EventArgs e)
        {
            SearchItemDisplayID lootsearchitem = new SearchItemDisplayID();

            lootsearchitem.Show();

            lootsearchitem.FormClosing += new FormClosingEventHandler(lootsearchitem_FormClosing);
        }

        private void lootsearchitem_FormClosing(object sender, FormClosingEventArgs e)
        {
            SearchItemDisplayID search = (SearchItemDisplayID)sender;

            if (search.GetEntryID() != String.Empty && search.buttonPressed == true)
            {
                lootItemEntryIDTextBox.Text = search.GetEntryID();
            }
        }

        private void searchVendorNPCEntryIDsButton_Click(object sender, EventArgs e)
        {
            SearchNPCDisplayID vendorNPCEntryIDSearch = new SearchNPCDisplayID();

            vendorNPCEntryIDSearch.Show();

            vendorNPCEntryIDSearch.FormClosing += new FormClosingEventHandler(vendorNPCEntryIDSearch_FormClosing);
        }

        private void vendorNPCEntryIDSearch_FormClosing(object sender, FormClosingEventArgs e)
        {
            SearchNPCDisplayID search = (SearchNPCDisplayID)sender;

            if (search.GetEntryID() != String.Empty && search.buttonPressed == true)
            {
                vendorEntryIDTextBox.Text = search.GetEntryID();
            }
        }

        private void vendorResetButton_Click(object sender, EventArgs e)
        {
            if (vendorGridView.Rows.Count != 0)
            {
                vendorGridView.Rows.Clear();
            }
            else
            {
                MessageBox.Show("There are no rows to delete", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
