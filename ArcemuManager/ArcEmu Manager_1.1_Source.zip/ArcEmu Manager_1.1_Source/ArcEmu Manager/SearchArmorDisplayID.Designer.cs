﻿namespace ArcEmu_Manager
{
    partial class SearchArmorDisplayID
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchArmorDisplayID));
            this.submit = new System.Windows.Forms.Button();
            this.armorSearchButton = new System.Windows.Forms.Button();
            this.armorNameLabel = new System.Windows.Forms.Label();
            this.armorNameTextBox = new System.Windows.Forms.TextBox();
            this.armorListBox = new System.Windows.Forms.ListBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.armorDisplayIDLabel = new System.Windows.Forms.Label();
            this.armorEntryIDLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // submit
            // 
            this.submit.Location = new System.Drawing.Point(298, 321);
            this.submit.Name = "submit";
            this.submit.Size = new System.Drawing.Size(103, 36);
            this.submit.TabIndex = 19;
            this.submit.Text = "Submit";
            this.submit.UseVisualStyleBackColor = true;
            this.submit.Click += new System.EventHandler(this.submit_Click_1);
            // 
            // armorSearchButton
            // 
            this.armorSearchButton.Location = new System.Drawing.Point(456, 39);
            this.armorSearchButton.Name = "armorSearchButton";
            this.armorSearchButton.Size = new System.Drawing.Size(75, 23);
            this.armorSearchButton.TabIndex = 18;
            this.armorSearchButton.Text = "Search";
            this.armorSearchButton.UseVisualStyleBackColor = true;
            this.armorSearchButton.Click += new System.EventHandler(this.armorSearchButton_Click);
            // 
            // armorNameLabel
            // 
            this.armorNameLabel.AutoSize = true;
            this.armorNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorNameLabel.Location = new System.Drawing.Point(176, 39);
            this.armorNameLabel.Name = "armorNameLabel";
            this.armorNameLabel.Size = new System.Drawing.Size(93, 18);
            this.armorNameLabel.TabIndex = 17;
            this.armorNameLabel.Text = "Armor Name";
            // 
            // armorNameTextBox
            // 
            this.armorNameTextBox.Location = new System.Drawing.Point(285, 40);
            this.armorNameTextBox.Name = "armorNameTextBox";
            this.armorNameTextBox.Size = new System.Drawing.Size(153, 20);
            this.armorNameTextBox.TabIndex = 15;
            // 
            // armorListBox
            // 
            this.armorListBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorListBox.FormattingEnabled = true;
            this.armorListBox.ItemHeight = 20;
            this.armorListBox.Location = new System.Drawing.Point(12, 91);
            this.armorListBox.Name = "armorListBox";
            this.armorListBox.Size = new System.Drawing.Size(690, 224);
            this.armorListBox.TabIndex = 16;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(614, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(82, 64);
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // armorDisplayIDLabel
            // 
            this.armorDisplayIDLabel.AutoSize = true;
            this.armorDisplayIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorDisplayIDLabel.Location = new System.Drawing.Point(570, 329);
            this.armorDisplayIDLabel.Name = "armorDisplayIDLabel";
            this.armorDisplayIDLabel.Size = new System.Drawing.Size(78, 18);
            this.armorDisplayIDLabel.TabIndex = 30;
            this.armorDisplayIDLabel.Text = "Display ID:";
            // 
            // armorEntryIDLabel
            // 
            this.armorEntryIDLabel.AutoSize = true;
            this.armorEntryIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorEntryIDLabel.Location = new System.Drawing.Point(448, 329);
            this.armorEntryIDLabel.Name = "armorEntryIDLabel";
            this.armorEntryIDLabel.Size = new System.Drawing.Size(64, 18);
            this.armorEntryIDLabel.TabIndex = 29;
            this.armorEntryIDLabel.Text = "Entry ID:";
            // 
            // SearchArmorDisplayID
            // 
            this.AcceptButton = this.armorSearchButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(708, 366);
            this.Controls.Add(this.armorDisplayIDLabel);
            this.Controls.Add(this.armorEntryIDLabel);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.submit);
            this.Controls.Add(this.armorSearchButton);
            this.Controls.Add(this.armorNameLabel);
            this.Controls.Add(this.armorNameTextBox);
            this.Controls.Add(this.armorListBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SearchArmorDisplayID";
            this.Text = "Search For Armor Display IDs";
            this.Load += new System.EventHandler(this.SearchArmorDisplayID_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button submit;
        private System.Windows.Forms.Button armorSearchButton;
        private System.Windows.Forms.Label armorNameLabel;
        private System.Windows.Forms.TextBox armorNameTextBox;
        private System.Windows.Forms.ListBox armorListBox;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label armorDisplayIDLabel;
        private System.Windows.Forms.Label armorEntryIDLabel;
    }
}