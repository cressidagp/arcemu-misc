﻿/* ArcEmu Manager
 * 
 * Copyright (C) 2010 Mitchell Kutchuk (Mitch528)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *  
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *  
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *  
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ArcEmu_Manager.Properties;
using MySql.Data.MySqlClient;
using System.Xml;
using System.Net;
using System.IO;

namespace ArcEmu_Manager
{
    public partial class SearchItemDisplayID : Form
    {
        public SearchItemDisplayID()
        {
            InitializeComponent();
        }

        private void SearchDisplayID_Load(object sender, EventArgs e)
        {
            textBox1.Focus();

            listBox1.SelectedIndexChanged += new EventHandler(listBox1_SelectedIndexChanged);
        }

        private XmlReader reader;
        private WebRequest request;

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            itemDisplayIDLabel.Text = String.Format("Display ID: {0}", displayids[listBox1.SelectedIndex]);
            itemEntryIDLabel.Text = String.Format("Entry ID: {0}", entryids[listBox1.SelectedIndex]);

            BackgroundWorker iconSearchWorker = new BackgroundWorker();
            iconSearchWorker.DoWork += new DoWorkEventHandler(iconSearchWorker_DoWork);
            iconSearchWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(iconSearchWorker_RunWorkerCompleted);
            iconSearchWorker.RunWorkerAsync(listBox1.SelectedItem.ToString());
        }

        private void iconSearchWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                reader = XmlReader.Create(String.Format("http://www.wowhead.com/item={0}&xml", e.Argument.ToString()));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void iconSearchWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {

            string name = String.Empty;

            while (reader.Read())
            {
                if (reader.IsStartElement())
                {
                    switch (reader.Name)
                    {
                        case "icon":
                            if (reader["displayId"] == displayids[listBox1.SelectedIndex])
                                name = reader.ReadElementString();
                            break;
                    }
                }
            }

            if (name != String.Empty)
            {
                try
                {
                    BackgroundWorker downloadIcon = new BackgroundWorker();
                    downloadIcon.DoWork += new DoWorkEventHandler(downloadIcon_DoWork);
                    downloadIcon.RunWorkerCompleted += new RunWorkerCompletedEventHandler(downloadIcon_RunWorkerCompleted);
                    downloadIcon.RunWorkerAsync(name.ToLower());
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                Stream theResource = this.GetType().Assembly.GetManifestResourceStream("ArcEmu_Manager.questionmark.png");

                pictureBox1.Image = Image.FromStream(theResource);
            }
        }

        private void downloadIcon_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                WebResponse response = request.GetResponse();

                Stream stream = response.GetResponseStream();

                byte[] bytes;

                using (BinaryReader br = new BinaryReader(stream))
                {
                    bytes = br.ReadBytes(1000000);
                    br.Close();
                }

                response.Close();

                using (MemoryStream imageStream = new MemoryStream(bytes, 0, bytes.Length))
                {
                    imageStream.Write(bytes, 0, bytes.Length);
                    pictureBox1.Image = Image.FromStream(imageStream, true);
                    imageStream.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void downloadIcon_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                request = WebRequest.Create(String.Format("http://static.wowhead.com/images/wow/icons/large/{0}.jpg", e.Argument));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public bool buttonPressed = false;

        private List<string> displayids = new List<string>();
        private List<string> entryids = new List<string>();

        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count != 0)
                listBox1.Items.Clear();

            if (displayids.Count != 0)
                displayids.Clear();

            if (textBox1.Text != String.Empty)
            {
                try
                {
                    this.Cursor = Cursors.WaitCursor;

                    string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.worlddb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                    MySqlConnection mConnection = new MySqlConnection(connection);

                    mConnection.Open();

                    string qry = String.Format("SELECT * FROM items WHERE name1 LIKE '%{0}%' LIMIT 1000", textBox1.Text);

                    MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                    MySqlDataReader Reader = cmd.ExecuteReader();

                    while (Reader.Read())
                    {
                        listBox1.Items.Add(Reader.GetString("name1"));
                        displayids.Add(Reader.GetString("displayid"));
                        entryids.Add(Reader.GetString("entry"));
                    }

                    mConnection.Close();
                    mConnection.Dispose();

                    this.Cursor = Cursors.Default;

                    if (listBox1.Items.Count != 0)
                    {
                        listBox1.SelectedIndex = 0;
                    }

                    listBox1.Focus();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("You must supply an item name to proceed!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (listBox1.Items.Count != 0)
            {
                buttonPressed = true;
                this.Close();
            }
            else
            {
                MessageBox.Show("You must select an item first!");
            }
        }

        public string GetDisplayID()
        {
            if (listBox1.Items.Count != 0)
            {
                return displayids[listBox1.SelectedIndex];
            }
            else
            {
                return null;
            }
        }

        public string GetEntryID()
        {
            if (listBox1.Items.Count != 0)
            {
                return entryids[listBox1.SelectedIndex];
            }
            else
            {
                return null;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
