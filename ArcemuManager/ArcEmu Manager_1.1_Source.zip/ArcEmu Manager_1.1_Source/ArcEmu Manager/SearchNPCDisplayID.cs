﻿/* ArcEmu Manager
 * 
 * Copyright (C) 2010 Mitchell Kutchuk (Mitch528)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *  
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *  
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *  
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ArcEmu_Manager.Properties;
using MySql.Data.MySqlClient;

namespace ArcEmu_Manager
{
    public partial class SearchNPCDisplayID : Form
    {
        public SearchNPCDisplayID()
        {
            InitializeComponent();
        }

        private void SearchNPCDisplayID_Load(object sender, EventArgs e)
        {
            searchTextBox.Focus();
        }

        public bool buttonPressed = false;

        private List<string> displayids = new List<string>();
        private List<string> entryids = new List<string>();

        private void searchButton_Click(object sender, EventArgs e)
        {
            if (searchListBox.Items.Count != 0)
                searchListBox.Items.Clear();

            if (displayids.Count != 0)
                displayids.Clear();

            if (searchTextBox.Text != String.Empty)
            {
                try
                {
                    this.Cursor = Cursors.WaitCursor;

                    string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.worlddb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                    MySqlConnection mConnection = new MySqlConnection(connection);

                    mConnection.Open();

                    string qry = String.Format("SELECT * FROM creature_names WHERE name LIKE '%{0}%' LIMIT 1000", searchTextBox.Text);

                    MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                    MySqlDataReader Reader = cmd.ExecuteReader();

                    while (Reader.Read())
                    {
                        searchListBox.Items.Add(Reader.GetString("name"));
                        displayids.Add(Reader.GetString("male_displayid"));
                        entryids.Add(Reader.GetString("entry"));
                    }

                    mConnection.Close();
                    mConnection.Dispose();

                    this.Cursor = Cursors.Default;

                    if (searchListBox.Items.Count != 0)
                    {
                        searchListBox.SelectedIndex = 0;
                    }

                    searchListBox.Focus();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("You must supply an NPC name to proceed!");
            }
        }

        private void Submit_Click(object sender, EventArgs e)
        {
            if (searchListBox.Items.Count != 0)
            {
                buttonPressed = true;
                this.Close();
            }
            else
            {
                MessageBox.Show("You must select an NPC first!");
            }
        }

        public string GetDisplayID()
        {
            if (searchListBox.Items.Count != 0)
            {
                return displayids[searchListBox.SelectedIndex];
            }
            else
            {
                return null;
            }
        }

        public string GetEntryID()
        {
            if (searchListBox.Items.Count != 0)
            {
                return entryids[searchListBox.SelectedIndex];
            }
            else
            {
                return null;
            }
        }
    }
}
