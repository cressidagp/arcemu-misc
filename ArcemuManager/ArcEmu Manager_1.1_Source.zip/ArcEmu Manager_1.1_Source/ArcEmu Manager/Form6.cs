﻿/* ArcEmu Manager
 * 
 * Copyright (C) 2010 Mitchell Kutchuk (Mitch528)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *  
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *  
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *  
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ArcEmu_Manager.Properties;
using MySql.Data.MySqlClient;

namespace ArcEmu_Manager
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        public bool buttonPressed = false;

        private List<string> entryids = new List<string>();

        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count != 0)
                listBox1.Items.Clear();

            if (textBox1.Text != String.Empty)
            {
                try
                {
                    this.Cursor = Cursors.WaitCursor;

                    string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.worlddb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                    MySqlConnection mConnection = new MySqlConnection(connection);

                    mConnection.Open();

                    string qry = String.Format("SELECT * FROM items WHERE name1 LIKE '%{0}%' LIMIT 1000", textBox1.Text);

                    MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                    MySqlDataReader Reader = cmd.ExecuteReader();

                    while (Reader.Read())
                    {
                        listBox1.Items.Add(Reader.GetString("name1"));
                        entryids.Add(Reader.GetString("entry"));
                    }

                    mConnection.Close();
                    mConnection.Dispose();

                    this.Cursor = Cursors.Default;

                    if (listBox1.Items.Count != 0)
                    {
                        listBox1.SelectedIndex = 0;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("You must supply an item name to proceed!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (listBox1.Items.Count != 0)
            {
                buttonPressed = true;
                this.Close();
            }
            else
            {
                MessageBox.Show("You must select an item first!");
            }
        }

        public Dictionary<string, string> GetItem()
        {

            if (listBox1.Items.Count != 0)
            {

                Dictionary<string, string> tempdict = new Dictionary<string, string>();

                tempdict.Add(listBox1.Items[listBox1.SelectedIndex].ToString(), entryids[listBox1.SelectedIndex]);

                return tempdict;
            }
            else
            {
                return null;
            }
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            textBox1.Focus();
        }
    }
}
