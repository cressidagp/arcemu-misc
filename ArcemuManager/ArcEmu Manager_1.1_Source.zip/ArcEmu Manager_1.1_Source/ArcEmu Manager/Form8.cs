﻿/* ArcEmu Manager
 * 
 * Copyright (C) 2010 Mitchell Kutchuk (Mitch528)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *  
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *  
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *  
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ArcEmu_Manager.Properties;
using MySql.Data.MySqlClient;

namespace ArcEmu_Manager
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text != String.Empty && textBox4.Text != String.Empty && textBox3.Text != String.Empty)
                {

                    string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.logondb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                    MySqlConnection mConnection = new MySqlConnection(connection);

                    mConnection.Open();

                    string qry = String.Format("INSERT INTO accounts (login, password, gm, banned, email, flags) VALUES('{0}', '{1}', '{2}', '0', '{3}', '{4}');", textBox1.Text, textBox4.Text, textBox2.Text, textBox5.Text,
                        textBox3.Text);

                    MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                    MySqlDataReader Reader = cmd.ExecuteReader();

                    mConnection.Close();
                    mConnection.Dispose();

                    this.Close();
                }
                else
                {
                    MessageBox.Show("You have not filled out the required fields!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public string GetAccountName()
        {
            return textBox1.Text;
        }

        public string GetAccountPassword()
        {
            return textBox4.Text;
        }

        public string GetGMPermissions()
        {
            return textBox2.Text;
        }

        public string GetFlags()
        {
            return textBox3.Text;
        }

        public string GetEmail()
        {
            return textBox5.Text;
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            textBox3.Text = Convert.ToString(24);
        }
    }
}
