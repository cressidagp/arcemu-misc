﻿namespace ArcEmu_Manager
{
    partial class SearchWeaponDisplayID
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchWeaponDisplayID));
            this.submit = new System.Windows.Forms.Button();
            this.weaponSearchButton = new System.Windows.Forms.Button();
            this.weaponNameLabel = new System.Windows.Forms.Label();
            this.weaponNameTextBox = new System.Windows.Forms.TextBox();
            this.weaponListBox = new System.Windows.Forms.ListBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.weaponDisplayIDLabel = new System.Windows.Forms.Label();
            this.weaponEntryIDLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // submit
            // 
            this.submit.Location = new System.Drawing.Point(298, 325);
            this.submit.Name = "submit";
            this.submit.Size = new System.Drawing.Size(103, 36);
            this.submit.TabIndex = 14;
            this.submit.Text = "Submit";
            this.submit.UseVisualStyleBackColor = true;
            this.submit.Click += new System.EventHandler(this.submit_Click);
            // 
            // weaponSearchButton
            // 
            this.weaponSearchButton.Location = new System.Drawing.Point(467, 46);
            this.weaponSearchButton.Name = "weaponSearchButton";
            this.weaponSearchButton.Size = new System.Drawing.Size(75, 23);
            this.weaponSearchButton.TabIndex = 13;
            this.weaponSearchButton.Text = "Search";
            this.weaponSearchButton.UseVisualStyleBackColor = true;
            this.weaponSearchButton.Click += new System.EventHandler(this.weaponSearchButton_Click);
            // 
            // weaponNameLabel
            // 
            this.weaponNameLabel.AutoSize = true;
            this.weaponNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponNameLabel.Location = new System.Drawing.Point(182, 47);
            this.weaponNameLabel.Name = "weaponNameLabel";
            this.weaponNameLabel.Size = new System.Drawing.Size(108, 18);
            this.weaponNameLabel.TabIndex = 12;
            this.weaponNameLabel.Text = "Weapon Name";
            // 
            // weaponNameTextBox
            // 
            this.weaponNameTextBox.Location = new System.Drawing.Point(296, 47);
            this.weaponNameTextBox.Name = "weaponNameTextBox";
            this.weaponNameTextBox.Size = new System.Drawing.Size(153, 20);
            this.weaponNameTextBox.TabIndex = 10;
            // 
            // weaponListBox
            // 
            this.weaponListBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponListBox.FormattingEnabled = true;
            this.weaponListBox.ItemHeight = 20;
            this.weaponListBox.Location = new System.Drawing.Point(12, 95);
            this.weaponListBox.Name = "weaponListBox";
            this.weaponListBox.Size = new System.Drawing.Size(690, 224);
            this.weaponListBox.TabIndex = 11;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(614, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(82, 64);
            this.pictureBox1.TabIndex = 21;
            this.pictureBox1.TabStop = false;
            // 
            // weaponDisplayIDLabel
            // 
            this.weaponDisplayIDLabel.AutoSize = true;
            this.weaponDisplayIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponDisplayIDLabel.Location = new System.Drawing.Point(555, 333);
            this.weaponDisplayIDLabel.Name = "weaponDisplayIDLabel";
            this.weaponDisplayIDLabel.Size = new System.Drawing.Size(78, 18);
            this.weaponDisplayIDLabel.TabIndex = 32;
            this.weaponDisplayIDLabel.Text = "Display ID:";
            // 
            // weaponEntryIDLabel
            // 
            this.weaponEntryIDLabel.AutoSize = true;
            this.weaponEntryIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponEntryIDLabel.Location = new System.Drawing.Point(433, 333);
            this.weaponEntryIDLabel.Name = "weaponEntryIDLabel";
            this.weaponEntryIDLabel.Size = new System.Drawing.Size(64, 18);
            this.weaponEntryIDLabel.TabIndex = 31;
            this.weaponEntryIDLabel.Text = "Entry ID:";
            // 
            // SearchWeaponDisplayID
            // 
            this.AcceptButton = this.weaponSearchButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(708, 366);
            this.Controls.Add(this.weaponDisplayIDLabel);
            this.Controls.Add(this.weaponEntryIDLabel);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.submit);
            this.Controls.Add(this.weaponSearchButton);
            this.Controls.Add(this.weaponNameLabel);
            this.Controls.Add(this.weaponNameTextBox);
            this.Controls.Add(this.weaponListBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SearchWeaponDisplayID";
            this.Text = "Search For Weapon Display IDs";
            this.Load += new System.EventHandler(this.SearchWeaponDisplayID_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button submit;
        private System.Windows.Forms.Button weaponSearchButton;
        private System.Windows.Forms.Label weaponNameLabel;
        private System.Windows.Forms.TextBox weaponNameTextBox;
        private System.Windows.Forms.ListBox weaponListBox;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label weaponDisplayIDLabel;
        private System.Windows.Forms.Label weaponEntryIDLabel;
    }
}