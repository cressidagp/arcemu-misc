﻿/* ArcEmu Manager
 * 
 * Copyright (C) 2010 Mitchell Kutchuk (Mitch528)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *  
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *  
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *  
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ArcEmu_Manager.Properties;
using MySql.Data.MySqlClient;

namespace ArcEmu_Manager
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        public bool buttonPressed = false;

        private void Form2_Load(object sender, EventArgs e)
        {
            textBox1.Text = Settings.Default.host;
            textBox2.Text = Settings.Default.port;
            textBox3.Text = Settings.Default.username;
            textBox4.Text = Settings.Default.password;
            textBox5.Text = Settings.Default.logondb;
            textBox6.Text = Settings.Default.chardb;
            textBox7.Text = Settings.Default.worlddb;

            textBox2.KeyPress += new KeyPressEventHandler(textBox2_KeyPress);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == String.Empty || textBox2.Text == String.Empty || textBox3.Text == String.Empty || textBox4.Text == String.Empty || textBox5.Text == String.Empty || textBox6.Text == String.Empty || textBox7.Text == String.Empty)
            {
                MessageBox.Show("You need to fill out all fields!", "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {

                try
                {
                    //Check to make sure logon database exists

                    string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", textBox1.Text, textBox5.Text, textBox3.Text, textBox4.Text, textBox2.Text);

                    MySqlConnection mConnection = new MySqlConnection(connection);

                    mConnection.Open();

                    mConnection.Close();

                    //Check to make sure characters database exists

                    connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", textBox1.Text, textBox6.Text, textBox3.Text, textBox4.Text, textBox2.Text);

                    mConnection = new MySqlConnection(connection);

                    mConnection.Open();

                    mConnection.Close();

                    //Check to make sure world database exists

                    connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", textBox1.Text, textBox7.Text, textBox3.Text, textBox4.Text, textBox2.Text);

                    mConnection = new MySqlConnection(connection);

                    mConnection.Open();

                    mConnection.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "ArcEmu Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    return;
                }

                Settings.Default.host = textBox1.Text;
                Settings.Default.port = textBox2.Text;
                Settings.Default.username = textBox3.Text;
                Settings.Default.password = textBox4.Text;
                Settings.Default.logondb = textBox5.Text;
                Settings.Default.chardb = textBox6.Text;
                Settings.Default.worlddb = textBox7.Text;

                Settings.Default.sql = true;

                Settings.Default.Save();

                buttonPressed = true;

                this.Close();
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
