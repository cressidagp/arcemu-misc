﻿namespace ArcEmu_Manager
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.arcEmuLocationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mySQLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.otherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.creditsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button7 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button30 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.charactersCopperNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.charactersSilverNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.charactersCopperLabel = new System.Windows.Forms.Label();
            this.charactersSilverLabel = new System.Windows.Forms.Label();
            this.charactersGoldLabel = new System.Windows.Forms.Label();
            this.button31 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.charactersGoldTextBox = new System.Windows.Forms.TextBox();
            this.charactersMoneyLabel = new System.Windows.Forms.Label();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.label52 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.listBox4 = new System.Windows.Forms.ListBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.label55 = new System.Windows.Forms.Label();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.listBox5 = new System.Windows.Forms.ListBox();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.button19 = new System.Windows.Forms.Button();
            this.label51 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.mailCopperNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.mailSilverNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.mailCopperLabel = new System.Windows.Forms.Label();
            this.mailSilverLabel = new System.Windows.Forms.Label();
            this.mailGoldLabel = new System.Windows.Forms.Label();
            this.mailGoldTextBox = new System.Windows.Forms.TextBox();
            this.mailMoneyLabel = new System.Windows.Forms.Label();
            this.button34 = new System.Windows.Forms.Button();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.button33 = new System.Windows.Forms.Button();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label57 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox13 = new System.Windows.Forms.ComboBox();
            this.button32 = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.button8 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.button9 = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.button10 = new System.Windows.Forms.Button();
            this.numericUpDown9 = new System.Windows.Forms.NumericUpDown();
            this.label32 = new System.Windows.Forms.Label();
            this.numericUpDown8 = new System.Windows.Forms.NumericUpDown();
            this.label31 = new System.Windows.Forms.Label();
            this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
            this.label30 = new System.Windows.Forms.Label();
            this.numericUpDown6 = new System.Windows.Forms.NumericUpDown();
            this.label29 = new System.Windows.Forms.Label();
            this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
            this.label28 = new System.Windows.Forms.Label();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.label27 = new System.Windows.Forms.Label();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.label24 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.button11 = new System.Windows.Forms.Button();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.label50 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.button15 = new System.Windows.Forms.Button();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.button16 = new System.Windows.Forms.Button();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.label49 = new System.Windows.Forms.Label();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.label48 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.label45 = new System.Windows.Forms.Label();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.label44 = new System.Windows.Forms.Label();
            this.numericUpDown10 = new System.Windows.Forms.NumericUpDown();
            this.label43 = new System.Windows.Forms.Label();
            this.tabPage18 = new System.Windows.Forms.TabPage();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.button35 = new System.Windows.Forms.Button();
            this.label58 = new System.Windows.Forms.Label();
            this.creatorTabPage = new System.Windows.Forms.TabPage();
            this.creatorTabControl = new System.Windows.Forms.TabControl();
            this.itemsTabPage = new System.Windows.Forms.TabPage();
            this.itemsTabControl = new System.Windows.Forms.TabControl();
            this.itemDetailsTabPage = new System.Windows.Forms.TabPage();
            this.label62 = new System.Windows.Forms.Label();
            this.itemDisplayIDSearch = new System.Windows.Forms.Button();
            this.itemLevelTextBox = new System.Windows.Forms.TextBox();
            this.itemLevelLabel = new System.Windows.Forms.Label();
            this.itemBindsComboBox = new System.Windows.Forms.ComboBox();
            this.itemBindsLabel = new System.Windows.Forms.Label();
            this.itemTypeComboBox = new System.Windows.Forms.ComboBox();
            this.itemTypeLabel = new System.Windows.Forms.Label();
            this.itemDetailsNextButton = new System.Windows.Forms.Button();
            this.itemEntryTextBox = new System.Windows.Forms.TextBox();
            this.itemEntryidLabel = new System.Windows.Forms.Label();
            this.itemDisplayidTextBox = new System.Windows.Forms.TextBox();
            this.itemDisplayidLabel = new System.Windows.Forms.Label();
            this.itemQualityComboBox = new System.Windows.Forms.ComboBox();
            this.itemQualityLabel = new System.Windows.Forms.Label();
            this.itemQuoteTextBox = new System.Windows.Forms.TextBox();
            this.itemQuoteLabel = new System.Windows.Forms.Label();
            this.itemNameTextBox = new System.Windows.Forms.TextBox();
            this.itemNameLabel = new System.Windows.Forms.Label();
            this.itemRequirementsTabPage = new System.Windows.Forms.TabPage();
            this.label60 = new System.Windows.Forms.Label();
            this.itemsDraeneiCheckBox = new System.Windows.Forms.CheckBox();
            this.itemsBloodElfCheckBox = new System.Windows.Forms.CheckBox();
            this.itemsTrollCheckBox = new System.Windows.Forms.CheckBox();
            this.itemsTaurenCheckBox = new System.Windows.Forms.CheckBox();
            this.itemsGnomeCheckBox = new System.Windows.Forms.CheckBox();
            this.itemsUndeadCheckBox = new System.Windows.Forms.CheckBox();
            this.itemsNightElfCheckBox = new System.Windows.Forms.CheckBox();
            this.itemsDwarfCheckBox = new System.Windows.Forms.CheckBox();
            this.itemsOrcCheckBox = new System.Windows.Forms.CheckBox();
            this.itemsHumanCheckBox = new System.Windows.Forms.CheckBox();
            this.itemsAllRaces = new System.Windows.Forms.CheckBox();
            this.itemsDeathKnightCheckBox = new System.Windows.Forms.CheckBox();
            this.label61 = new System.Windows.Forms.Label();
            this.itemsWarlockCheckBox = new System.Windows.Forms.CheckBox();
            this.itemsMageCheckBox = new System.Windows.Forms.CheckBox();
            this.itemsShamanCheckBox = new System.Windows.Forms.CheckBox();
            this.itemsDruidCheckBox = new System.Windows.Forms.CheckBox();
            this.itemsPriestCheckBox = new System.Windows.Forms.CheckBox();
            this.itemsRogueCheckBox = new System.Windows.Forms.CheckBox();
            this.itemsHunterCheckBox = new System.Windows.Forms.CheckBox();
            this.itemsPaladinCheckBox = new System.Windows.Forms.CheckBox();
            this.itemsWarriorCheckBox = new System.Windows.Forms.CheckBox();
            this.itemsAllClasses = new System.Windows.Forms.CheckBox();
            this.itemsAllowableClassesLabel = new System.Windows.Forms.Label();
            this.itemsMaxTextBox = new System.Windows.Forms.TextBox();
            this.itemsMaxLabel = new System.Windows.Forms.Label();
            this.itemSkillLevelTextBox = new System.Windows.Forms.TextBox();
            this.itemSkillLevelLabel = new System.Windows.Forms.Label();
            this.itemSkillProfessionComboBox = new System.Windows.Forms.ComboBox();
            this.itemskillProfressionLabel = new System.Windows.Forms.Label();
            this.itemRequiredLevelTextBox = new System.Windows.Forms.TextBox();
            this.itemRequiredLevelLabel = new System.Windows.Forms.Label();
            this.itemRequirementsNextButton = new System.Windows.Forms.Button();
            this.itemPriceTabPage = new System.Windows.Forms.TabPage();
            this.itemsSellCopperNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.itemsSellSilverNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.itemsBuyCopperNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.itemsBuySilverNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.itemsPriceNextButton = new System.Windows.Forms.Button();
            this.itemsSellCopperLabel = new System.Windows.Forms.Label();
            this.itemsSellSilverLabel = new System.Windows.Forms.Label();
            this.itemsSellGoldLabel = new System.Windows.Forms.Label();
            this.itemsSellGoldTextBox = new System.Windows.Forms.TextBox();
            this.itemsBuyCopperLabel = new System.Windows.Forms.Label();
            this.itemsBuySilverLabel = new System.Windows.Forms.Label();
            this.itemsBuyGoldLabel = new System.Windows.Forms.Label();
            this.itemsSellPriceLabel = new System.Windows.Forms.Label();
            this.itemsBuyGoldTextBox = new System.Windows.Forms.TextBox();
            this.itemsBuyPriceLabel = new System.Windows.Forms.Label();
            this.itemFinishTabPage = new System.Windows.Forms.TabPage();
            this.itemsSaveToSQLButton = new System.Windows.Forms.Button();
            this.itemsSaveToDBButton = new System.Windows.Forms.Button();
            this.itemsStartOverButton = new System.Windows.Forms.Button();
            this.weaponsTabPage = new System.Windows.Forms.TabPage();
            this.weaponsTabControl = new System.Windows.Forms.TabControl();
            this.weaponDetailsTabPage = new System.Windows.Forms.TabPage();
            this.weaponBindComboBox = new System.Windows.Forms.ComboBox();
            this.weaponBindLabel = new System.Windows.Forms.Label();
            this.weaponDurabilityTextBox = new System.Windows.Forms.TextBox();
            this.weaponDurabilityLabel = new System.Windows.Forms.Label();
            this.weaponTypeComboBox = new System.Windows.Forms.ComboBox();
            this.weaponTypeLabel = new System.Windows.Forms.Label();
            this.weaponEquipComboBox = new System.Windows.Forms.ComboBox();
            this.weaponEquipLabel = new System.Windows.Forms.Label();
            this.weaponDetailsRequiredLabel = new System.Windows.Forms.Label();
            this.weaponSearchDisplayIDButton = new System.Windows.Forms.Button();
            this.weaponDetailsNextButton = new System.Windows.Forms.Button();
            this.weaponEntryIDTextBox = new System.Windows.Forms.TextBox();
            this.weaponEntryIDLabel = new System.Windows.Forms.Label();
            this.weaponDisplayIDTextBox = new System.Windows.Forms.TextBox();
            this.weaponDisplayIDLabel = new System.Windows.Forms.Label();
            this.weaponQualityComboBox = new System.Windows.Forms.ComboBox();
            this.weaponQualityLabel = new System.Windows.Forms.Label();
            this.weaponQuoteTextBox = new System.Windows.Forms.TextBox();
            this.weaponQuoteLabel = new System.Windows.Forms.Label();
            this.weaponNameTextBox = new System.Windows.Forms.TextBox();
            this.weaponNameLabel = new System.Windows.Forms.Label();
            this.weaponStatsTabPage = new System.Windows.Forms.TabPage();
            this.weaponStatsNextButton = new System.Windows.Forms.Button();
            this.weaponArmorStatsGroupBox = new System.Windows.Forms.GroupBox();
            this.weaponBlockArmorTextBox = new System.Windows.Forms.TextBox();
            this.weaponBlockArmorLabel = new System.Windows.Forms.Label();
            this.weaponBlockTextBox = new System.Windows.Forms.TextBox();
            this.weaponBlockLabel = new System.Windows.Forms.Label();
            this.weaponStatsGroupBox = new System.Windows.Forms.GroupBox();
            this.weaponSpeedNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.weaponSheathLabel = new System.Windows.Forms.Label();
            this.weaponSpeedLabel = new System.Windows.Forms.Label();
            this.weaponSheathComboBox = new System.Windows.Forms.ComboBox();
            this.weaponAmmoTypeComboBox = new System.Windows.Forms.ComboBox();
            this.weaponAmmoTypeLabel = new System.Windows.Forms.Label();
            this.weaponRequirementsTabPage = new System.Windows.Forms.TabPage();
            this.weaponStackableLabel = new System.Windows.Forms.Label();
            this.weaponStackableTextBox = new System.Windows.Forms.TextBox();
            this.weaponRequirementsNextButton = new System.Windows.Forms.Button();
            this.weaponDraeneiCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponBloodElfCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponTrollCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponTaurenCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponGnomeCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponUndeadCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponNightElfCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponDwarfCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponOrcCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponHumanCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponRaceAllCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponDeathKnightCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponAllowableRaceLabel = new System.Windows.Forms.Label();
            this.weaponWarlockCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponMageCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponShamanCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponDruidCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponPriestCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponRogueCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponHunterCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponPaladinCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponWarriorCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponClassAllCheckBox = new System.Windows.Forms.CheckBox();
            this.weaponAllowableClassLabel = new System.Windows.Forms.Label();
            this.weaponMaxTextBox = new System.Windows.Forms.TextBox();
            this.weaponMaxLabel = new System.Windows.Forms.Label();
            this.weaponItemLevelTextBox = new System.Windows.Forms.TextBox();
            this.weaponItemLevelLabel = new System.Windows.Forms.Label();
            this.weaponRequiredLevelTextBox = new System.Windows.Forms.TextBox();
            this.weaponRequiredLevelLabel = new System.Windows.Forms.Label();
            this.weaponDamageTabPage = new System.Windows.Forms.TabPage();
            this.weaponDamageNextButton = new System.Windows.Forms.Button();
            this.weaponDamageType2ComboBox = new System.Windows.Forms.ComboBox();
            this.weaponDamageType2Label = new System.Windows.Forms.Label();
            this.weaponDamageMax2TextBox = new System.Windows.Forms.TextBox();
            this.weaponDamageMax2Label = new System.Windows.Forms.Label();
            this.weaponDamageMin2TextBox = new System.Windows.Forms.TextBox();
            this.weaponDamageMin2Label = new System.Windows.Forms.Label();
            this.weaponDamageType1ComboBox = new System.Windows.Forms.ComboBox();
            this.weaponDamageType1Label = new System.Windows.Forms.Label();
            this.weaponDamageMax1TextBox = new System.Windows.Forms.TextBox();
            this.weaponDamageMax1Label = new System.Windows.Forms.Label();
            this.weaponDamageMin1TextBox = new System.Windows.Forms.TextBox();
            this.weaponDamageMin1Label = new System.Windows.Forms.Label();
            this.weaponResistsTabPage = new System.Windows.Forms.TabPage();
            this.weaponResistsNextButton = new System.Windows.Forms.Button();
            this.weaponArcaneTextBox = new System.Windows.Forms.TextBox();
            this.weaponArcaneLabel = new System.Windows.Forms.Label();
            this.weaponFrostTextBox = new System.Windows.Forms.TextBox();
            this.weaponFrostLabel = new System.Windows.Forms.Label();
            this.weaponFireTextBox = new System.Windows.Forms.TextBox();
            this.weaponFireLabel = new System.Windows.Forms.Label();
            this.weaponShadowTextBox = new System.Windows.Forms.TextBox();
            this.weaponShadowLabel = new System.Windows.Forms.Label();
            this.weaponNatureTextBox = new System.Windows.Forms.TextBox();
            this.weaponNatureLabel = new System.Windows.Forms.Label();
            this.weaponHolyTextBox = new System.Windows.Forms.TextBox();
            this.weaponHolyLabel = new System.Windows.Forms.Label();
            this.weaponSocketsTabPage = new System.Windows.Forms.TabPage();
            this.weaponSocketBonusLabel = new System.Windows.Forms.Label();
            this.weaponSocketBonusComboBox = new System.Windows.Forms.ComboBox();
            this.weaponSocket3NoneButton = new System.Windows.Forms.Button();
            this.weaponSocket2NoneButton = new System.Windows.Forms.Button();
            this.weaponSocket1NoneButton = new System.Windows.Forms.Button();
            this.weaponSocketsNextButton = new System.Windows.Forms.Button();
            this.weaponSocket3YellowButton = new System.Windows.Forms.Button();
            this.weaponSocket3RedButton = new System.Windows.Forms.Button();
            this.weaponSocket3BlueButton = new System.Windows.Forms.Button();
            this.weaponSocket3Label = new System.Windows.Forms.Label();
            this.weaponSocket2YellowButton = new System.Windows.Forms.Button();
            this.weaponSocket2RedButton = new System.Windows.Forms.Button();
            this.weaponSocket2BlueButton = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.weaponSocket1YellowButton = new System.Windows.Forms.Button();
            this.weaponSocket1RedButton = new System.Windows.Forms.Button();
            this.weaponSocket1BlueButton = new System.Windows.Forms.Button();
            this.weaponSocket1Label = new System.Windows.Forms.Label();
            this.weaponPriceTabPage = new System.Windows.Forms.TabPage();
            this.weaponPriceNextButton = new System.Windows.Forms.Button();
            this.weaponSellCopperNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.weaponSellSilverNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.weaponBuyCopperNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.weaponBuySilverNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.weaponSellCopperLabel = new System.Windows.Forms.Label();
            this.weaponSellSilverLabel = new System.Windows.Forms.Label();
            this.weaponSellGoldLabel = new System.Windows.Forms.Label();
            this.weaponSellGoldTextBox = new System.Windows.Forms.TextBox();
            this.weaponBuyCopperLabel = new System.Windows.Forms.Label();
            this.weaponBuySilverLabel = new System.Windows.Forms.Label();
            this.weaponBuyGoldLabel = new System.Windows.Forms.Label();
            this.weaponSellPriceLabel = new System.Windows.Forms.Label();
            this.weaponBuyGoldTextBox = new System.Windows.Forms.TextBox();
            this.weaponBuyPriceLabel = new System.Windows.Forms.Label();
            this.weaponFinishTabPage = new System.Windows.Forms.TabPage();
            this.weaponSaveToSQLFileButton = new System.Windows.Forms.Button();
            this.weaponSaveToDBButton = new System.Windows.Forms.Button();
            this.weaponStartOverButton = new System.Windows.Forms.Button();
            this.armorTabPage = new System.Windows.Forms.TabPage();
            this.armorTabControl = new System.Windows.Forms.TabControl();
            this.armorDetailsTabPage = new System.Windows.Forms.TabPage();
            this.armorMaterialComboBox = new System.Windows.Forms.ComboBox();
            this.armorMaterialLabel = new System.Windows.Forms.Label();
            this.armorRequiredLabel = new System.Windows.Forms.Label();
            this.armorSearchDisplayIDs = new System.Windows.Forms.Button();
            this.armorDetailsNextButton = new System.Windows.Forms.Button();
            this.armorBindsComboBox = new System.Windows.Forms.ComboBox();
            this.armorBindsLabel = new System.Windows.Forms.Label();
            this.armorDurabilityTextBox = new System.Windows.Forms.TextBox();
            this.armorDurabilityLabel = new System.Windows.Forms.Label();
            this.armorEquipComboBox = new System.Windows.Forms.ComboBox();
            this.armorEquipLabel = new System.Windows.Forms.Label();
            this.armorEntryIDTextBox = new System.Windows.Forms.TextBox();
            this.armorEntryIDLabel = new System.Windows.Forms.Label();
            this.armorDisplayIDTextBox = new System.Windows.Forms.TextBox();
            this.armorDisplayIDLabel = new System.Windows.Forms.Label();
            this.armorQualityComboBox = new System.Windows.Forms.ComboBox();
            this.armorQualityLabel = new System.Windows.Forms.Label();
            this.armorQuoteTextBox = new System.Windows.Forms.TextBox();
            this.armorQuoteLabel = new System.Windows.Forms.Label();
            this.armorNameTextBox = new System.Windows.Forms.TextBox();
            this.armorNameLabel = new System.Windows.Forms.Label();
            this.armorStatsTabPage = new System.Windows.Forms.TabPage();
            this.armorStatsNextButton = new System.Windows.Forms.Button();
            this.armorStatsGroupBox = new System.Windows.Forms.GroupBox();
            this.armorStatsArmorTextBox = new System.Windows.Forms.TextBox();
            this.armorStatsArmorLabel = new System.Windows.Forms.Label();
            this.armorStatsBlockTextBox = new System.Windows.Forms.TextBox();
            this.armorStatsBlockLabel = new System.Windows.Forms.Label();
            this.armorRequirementsTabPage = new System.Windows.Forms.TabPage();
            this.armorStackableLabel = new System.Windows.Forms.Label();
            this.armorStackableTextBox = new System.Windows.Forms.TextBox();
            this.armorRequirementsNextButton = new System.Windows.Forms.Button();
            this.armorDraeneiCheckBox = new System.Windows.Forms.CheckBox();
            this.armorBloodElfCheckBox = new System.Windows.Forms.CheckBox();
            this.armorTrollCheckBox = new System.Windows.Forms.CheckBox();
            this.armorTaurenCheckBox = new System.Windows.Forms.CheckBox();
            this.armorGnomeCheckBox = new System.Windows.Forms.CheckBox();
            this.armorUndeadCheckBox = new System.Windows.Forms.CheckBox();
            this.armorNightElfCheckBox = new System.Windows.Forms.CheckBox();
            this.armorDwarfCheckBox = new System.Windows.Forms.CheckBox();
            this.armorOrcCheckBox = new System.Windows.Forms.CheckBox();
            this.armorHumanCheckBox = new System.Windows.Forms.CheckBox();
            this.armorRaceAllCheckBox = new System.Windows.Forms.CheckBox();
            this.armorDeathKnightCheckBox = new System.Windows.Forms.CheckBox();
            this.armorAllowableRaceLabel = new System.Windows.Forms.Label();
            this.armorWarlockCheckBox = new System.Windows.Forms.CheckBox();
            this.armorMageCheckBox = new System.Windows.Forms.CheckBox();
            this.armorShamanCheckBox = new System.Windows.Forms.CheckBox();
            this.armorDruidCheckBox = new System.Windows.Forms.CheckBox();
            this.armorPriestCheckBox = new System.Windows.Forms.CheckBox();
            this.armorRogueCheckBox = new System.Windows.Forms.CheckBox();
            this.armorHunterCheckBox = new System.Windows.Forms.CheckBox();
            this.armorPaladinCheckBox = new System.Windows.Forms.CheckBox();
            this.armorWarriorCheckBox = new System.Windows.Forms.CheckBox();
            this.armorClassAllCheckBox = new System.Windows.Forms.CheckBox();
            this.armorAllowableClassLabel = new System.Windows.Forms.Label();
            this.armorMaxTextBox = new System.Windows.Forms.TextBox();
            this.armorMaxLabel = new System.Windows.Forms.Label();
            this.armorItemLevelTextBox = new System.Windows.Forms.TextBox();
            this.armorItemLevelLabel = new System.Windows.Forms.Label();
            this.armorRequiredLevelTextBox = new System.Windows.Forms.TextBox();
            this.armorRequiredLevelLabel = new System.Windows.Forms.Label();
            this.armorSocketsTabPage = new System.Windows.Forms.TabPage();
            this.armorBonusLabel = new System.Windows.Forms.Label();
            this.armorBonusComboBox = new System.Windows.Forms.ComboBox();
            this.armorSocket3NoneButton = new System.Windows.Forms.Button();
            this.armorSocket2NoneButton = new System.Windows.Forms.Button();
            this.armorSocket1NoneButton = new System.Windows.Forms.Button();
            this.armorSocketsNextButton = new System.Windows.Forms.Button();
            this.armorSocket3YellowButton = new System.Windows.Forms.Button();
            this.armorSocket3RedButtton = new System.Windows.Forms.Button();
            this.armorSocket3BlueButton = new System.Windows.Forms.Button();
            this.armorSocket3Label = new System.Windows.Forms.Label();
            this.armorSocket2YellowButton = new System.Windows.Forms.Button();
            this.armorSocket2RedButton = new System.Windows.Forms.Button();
            this.armorSocket2BlueButton = new System.Windows.Forms.Button();
            this.armorSocket2Label = new System.Windows.Forms.Label();
            this.armorSocket1YellowButton = new System.Windows.Forms.Button();
            this.armorSocket1RedButton = new System.Windows.Forms.Button();
            this.armorSocket1BlueButton = new System.Windows.Forms.Button();
            this.armorSocket1Label = new System.Windows.Forms.Label();
            this.armorPriceTabPage = new System.Windows.Forms.TabPage();
            this.armorSellPriceNextButton = new System.Windows.Forms.Button();
            this.armorSellCopperNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.armorSellSilverNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.armorBuyCopperNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.armorBuySilverNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.armorSellCopperLabel = new System.Windows.Forms.Label();
            this.armorSellSilverLabel = new System.Windows.Forms.Label();
            this.armorSellGoldLabel = new System.Windows.Forms.Label();
            this.armorSellGoldTextBox = new System.Windows.Forms.TextBox();
            this.armorBuyCopperLabel = new System.Windows.Forms.Label();
            this.armorBuySilverLabel = new System.Windows.Forms.Label();
            this.armorBuyGoldLabel = new System.Windows.Forms.Label();
            this.armorSellLabel = new System.Windows.Forms.Label();
            this.armorBuyGoldTextBox = new System.Windows.Forms.TextBox();
            this.armorBuyPriceLabel = new System.Windows.Forms.Label();
            this.armorFinishTabPage = new System.Windows.Forms.TabPage();
            this.armorSaveToSQLButton = new System.Windows.Forms.Button();
            this.armorSaveToDBButton = new System.Windows.Forms.Button();
            this.armorStartOverButton = new System.Windows.Forms.Button();
            this.npcTabPage = new System.Windows.Forms.TabPage();
            this.npcTabControl = new System.Windows.Forms.TabControl();
            this.npcDetailsTabPage = new System.Windows.Forms.TabPage();
            this.npcDetailsRequiredLabel = new System.Windows.Forms.Label();
            this.npcSearchDisplayIDs = new System.Windows.Forms.Button();
            this.npcBossLabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.npcBossNoRadioButton = new System.Windows.Forms.RadioButton();
            this.npcBossYesRadioButton = new System.Windows.Forms.RadioButton();
            this.npcTypeComboBox = new System.Windows.Forms.ComboBox();
            this.npcTypeLabel = new System.Windows.Forms.Label();
            this.npcFactionComboBox = new System.Windows.Forms.ComboBox();
            this.npcFactionLabel = new System.Windows.Forms.Label();
            this.npcEntryIDTextBox = new System.Windows.Forms.TextBox();
            this.npcEntryidLabel = new System.Windows.Forms.Label();
            this.npcDetailsNextButton = new System.Windows.Forms.Button();
            this.npcDisplayidTextBox = new System.Windows.Forms.TextBox();
            this.npcDisplayidLabel = new System.Windows.Forms.Label();
            this.npcRankComboBox = new System.Windows.Forms.ComboBox();
            this.npcRankLabel = new System.Windows.Forms.Label();
            this.npcSubnameTextbox = new System.Windows.Forms.TextBox();
            this.npcSubnameLabel = new System.Windows.Forms.Label();
            this.npcNameTextBox = new System.Windows.Forms.TextBox();
            this.npcNameLabel = new System.Windows.Forms.Label();
            this.npcBehaviorTabPage = new System.Windows.Forms.TabPage();
            this.npcModelSizeNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.npcBehaviorNextButton = new System.Windows.Forms.Button();
            this.npcModeLSizeLabel = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.npcSecondsLabel = new System.Windows.Forms.Label();
            this.npcHoursLabel = new System.Windows.Forms.Label();
            this.npcMinutesLabel = new System.Windows.Forms.Label();
            this.npcMinutesNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.npcSecondsNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.npcHoursTextBox = new System.Windows.Forms.TextBox();
            this.npcStatsTabPage = new System.Windows.Forms.TabPage();
            this.npcStatsNextButton = new System.Windows.Forms.Button();
            this.npcMaxDamageTextBox = new System.Windows.Forms.TextBox();
            this.npcMaxDamageLabel = new System.Windows.Forms.Label();
            this.npcMinDamageTextBox = new System.Windows.Forms.TextBox();
            this.npcMinDamageLabel = new System.Windows.Forms.Label();
            this.npcStatsGroupBox = new System.Windows.Forms.GroupBox();
            this.npcArmorLabel = new System.Windows.Forms.Label();
            this.npcManaLabel = new System.Windows.Forms.Label();
            this.npcMinHealthLevel = new System.Windows.Forms.Label();
            this.npcMaxHealthLabel = new System.Windows.Forms.Label();
            this.npcMinLevelLabel = new System.Windows.Forms.Label();
            this.npcMaxLevelTextBox = new System.Windows.Forms.TextBox();
            this.npcMaxLevelLabel = new System.Windows.Forms.Label();
            this.npcMinLevelTextBox = new System.Windows.Forms.TextBox();
            this.npcArmorTextBox = new System.Windows.Forms.TextBox();
            this.npcMaxHealthTextBox = new System.Windows.Forms.TextBox();
            this.npcManaTextBox = new System.Windows.Forms.TextBox();
            this.npcMinHealthTextBox = new System.Windows.Forms.TextBox();
            this.npcAttackStatsGroupBox = new System.Windows.Forms.GroupBox();
            this.npcSpeedTextBox = new System.Windows.Forms.TextBox();
            this.npcSpeedLabel = new System.Windows.Forms.Label();
            this.npcResistsTabPage = new System.Windows.Forms.TabPage();
            this.npcResistsNextButton = new System.Windows.Forms.Button();
            this.npcResistArcaneTextBox = new System.Windows.Forms.TextBox();
            this.npcResistArcaneLabel = new System.Windows.Forms.Label();
            this.npcResistFrostTextBox = new System.Windows.Forms.TextBox();
            this.npcResistFrostLabel = new System.Windows.Forms.Label();
            this.npcResistFireTextBox = new System.Windows.Forms.TextBox();
            this.npcResistFireLabel = new System.Windows.Forms.Label();
            this.npcResistShadowTextBox = new System.Windows.Forms.TextBox();
            this.npcResistShadowLabel = new System.Windows.Forms.Label();
            this.npcResistNatureTextBox = new System.Windows.Forms.TextBox();
            this.npcResistNatureLabel = new System.Windows.Forms.Label();
            this.npcResistHolyTextBox = new System.Windows.Forms.TextBox();
            this.npcResistHolyLabel = new System.Windows.Forms.Label();
            this.npcOptionsTabPage = new System.Windows.Forms.TabPage();
            this.npcOptionsNextButton = new System.Windows.Forms.Button();
            this.npcGuildBankGroupBox = new System.Windows.Forms.GroupBox();
            this.npcGuildBankNoRadioButton = new System.Windows.Forms.RadioButton();
            this.npcGuildBankYesRadioButton = new System.Windows.Forms.RadioButton();
            this.npcStableGroupBox = new System.Windows.Forms.GroupBox();
            this.npcStableNoRadioButton = new System.Windows.Forms.RadioButton();
            this.npcStableYesRadioButton = new System.Windows.Forms.RadioButton();
            this.npcAuctioneerGroupBox = new System.Windows.Forms.GroupBox();
            this.npcAuctioneerNoRadioButton = new System.Windows.Forms.RadioButton();
            this.npcAuctioneerYesRadioButton = new System.Windows.Forms.RadioButton();
            this.npcBankerGroupBox = new System.Windows.Forms.GroupBox();
            this.npcBankerNoRadioButton = new System.Windows.Forms.RadioButton();
            this.npcBankerYesRadioButton = new System.Windows.Forms.RadioButton();
            this.npcInnkeeperGroupBox = new System.Windows.Forms.GroupBox();
            this.npcInnkeeperNoRadioButton = new System.Windows.Forms.RadioButton();
            this.npcInnkeeperYesRadioButton = new System.Windows.Forms.RadioButton();
            this.npcArmorerGroupBox = new System.Windows.Forms.GroupBox();
            this.npcArmorerNoRadioButton = new System.Windows.Forms.RadioButton();
            this.npcArmorerYesRadioButton = new System.Windows.Forms.RadioButton();
            this.npcVendorGroupBox = new System.Windows.Forms.GroupBox();
            this.npcVendorNoRadioButton = new System.Windows.Forms.RadioButton();
            this.npcVendorYesRadioButton = new System.Windows.Forms.RadioButton();
            this.npcGossipGroupBox = new System.Windows.Forms.GroupBox();
            this.npcGossipNoRadioButton = new System.Windows.Forms.RadioButton();
            this.npcGossipYesRadioButton = new System.Windows.Forms.RadioButton();
            this.npcLootTabPage = new System.Windows.Forms.TabPage();
            this.npcLootFinishButton = new System.Windows.Forms.Button();
            this.npcLootGroupBox = new System.Windows.Forms.GroupBox();
            this.npcLootGoldTextBox = new System.Windows.Forms.TextBox();
            this.npcLootCopperNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.npcLootGoldLabel = new System.Windows.Forms.Label();
            this.npcLootSilverNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.npcLootSilverLabel = new System.Windows.Forms.Label();
            this.npcLootCopperLabel = new System.Windows.Forms.Label();
            this.npcFinishTabPage = new System.Windows.Forms.TabPage();
            this.npcSaveToSQLFileButton = new System.Windows.Forms.Button();
            this.npcSaveToDBButton = new System.Windows.Forms.Button();
            this.npcStartOverButton = new System.Windows.Forms.Button();
            this.vendorsTabPage = new System.Windows.Forms.TabPage();
            this.vendorResetButton = new System.Windows.Forms.Button();
            this.searchVendorNPCEntryIDsButton = new System.Windows.Forms.Button();
            this.vendorRemoveRowButton = new System.Windows.Forms.Button();
            this.vendorGridView = new System.Windows.Forms.DataGridView();
            this.vendorEntryIDColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vendorItemEntryID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vendorItemAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vendorAmountNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label64 = new System.Windows.Forms.Label();
            this.vendorAddButton = new System.Windows.Forms.Button();
            this.vendorSaveToSQLButton = new System.Windows.Forms.Button();
            this.vendorSaveToDBButton = new System.Windows.Forms.Button();
            this.vendorItemEntryIDTextBox = new System.Windows.Forms.TextBox();
            this.vendorItemEntryIDLabel = new System.Windows.Forms.Label();
            this.vendorEntryIDTextBox = new System.Windows.Forms.TextBox();
            this.vendorEntryIDLabel = new System.Windows.Forms.Label();
            this.lootTabPage = new System.Windows.Forms.TabPage();
            this.lootSearchItemButton = new System.Windows.Forms.Button();
            this.lootSearchNPCButton = new System.Windows.Forms.Button();
            this.lootMaxAmountNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label63 = new System.Windows.Forms.Label();
            this.lootChancePercent = new System.Windows.Forms.Label();
            this.lootChanceTextBox = new System.Windows.Forms.TextBox();
            this.lootChanceLabel = new System.Windows.Forms.Label();
            this.lootRemoveButton = new System.Windows.Forms.Button();
            this.lootGridView = new System.Windows.Forms.DataGridView();
            this.lootNPCEntryIDColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lootItemEntryIDColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lootChanceColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lootMinAmountColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lootMaxAmountColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lootMinAmountNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.lootMinAmountLabel = new System.Windows.Forms.Label();
            this.lootAddButton = new System.Windows.Forms.Button();
            this.lootSaveToSQLFileButton = new System.Windows.Forms.Button();
            this.lootSaveToDBButton = new System.Windows.Forms.Button();
            this.lootItemEntryIDTextBox = new System.Windows.Forms.TextBox();
            this.lootItemEntryIDLabel = new System.Windows.Forms.Label();
            this.lootNPCEntryIDTextBox = new System.Windows.Forms.TextBox();
            this.lootNpcEntryIDLabel = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.SaveItemSQLFile = new System.Windows.Forms.SaveFileDialog();
            this.SaveNPCSQLFile = new System.Windows.Forms.SaveFileDialog();
            this.VendorSaveSQLFile = new System.Windows.Forms.SaveFileDialog();
            this.LootSaveSQLFile = new System.Windows.Forms.SaveFileDialog();
            this.WeaponSaveSQLFile = new System.Windows.Forms.SaveFileDialog();
            this.ArmorSaveSQLFile = new System.Windows.Forms.SaveFileDialog();
            this.menuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.charactersCopperNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.charactersSilverNumericUpDown)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage13.SuspendLayout();
            this.tabPage17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mailCopperNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mailSilverNumericUpDown)).BeginInit();
            this.tabPage6.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.tabPage12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.tabPage14.SuspendLayout();
            this.tabPage16.SuspendLayout();
            this.tabPage15.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tabPage10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).BeginInit();
            this.tabPage18.SuspendLayout();
            this.creatorTabPage.SuspendLayout();
            this.creatorTabControl.SuspendLayout();
            this.itemsTabPage.SuspendLayout();
            this.itemsTabControl.SuspendLayout();
            this.itemDetailsTabPage.SuspendLayout();
            this.itemRequirementsTabPage.SuspendLayout();
            this.itemPriceTabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.itemsSellCopperNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsSellSilverNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBuyCopperNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBuySilverNumericUpDown)).BeginInit();
            this.itemFinishTabPage.SuspendLayout();
            this.weaponsTabPage.SuspendLayout();
            this.weaponsTabControl.SuspendLayout();
            this.weaponDetailsTabPage.SuspendLayout();
            this.weaponStatsTabPage.SuspendLayout();
            this.weaponArmorStatsGroupBox.SuspendLayout();
            this.weaponStatsGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.weaponSpeedNumericUpDown)).BeginInit();
            this.weaponRequirementsTabPage.SuspendLayout();
            this.weaponDamageTabPage.SuspendLayout();
            this.weaponResistsTabPage.SuspendLayout();
            this.weaponSocketsTabPage.SuspendLayout();
            this.weaponPriceTabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.weaponSellCopperNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.weaponSellSilverNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.weaponBuyCopperNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.weaponBuySilverNumericUpDown)).BeginInit();
            this.weaponFinishTabPage.SuspendLayout();
            this.armorTabPage.SuspendLayout();
            this.armorTabControl.SuspendLayout();
            this.armorDetailsTabPage.SuspendLayout();
            this.armorStatsTabPage.SuspendLayout();
            this.armorStatsGroupBox.SuspendLayout();
            this.armorRequirementsTabPage.SuspendLayout();
            this.armorSocketsTabPage.SuspendLayout();
            this.armorPriceTabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.armorSellCopperNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.armorSellSilverNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.armorBuyCopperNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.armorBuySilverNumericUpDown)).BeginInit();
            this.armorFinishTabPage.SuspendLayout();
            this.npcTabPage.SuspendLayout();
            this.npcTabControl.SuspendLayout();
            this.npcDetailsTabPage.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.npcBehaviorTabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.npcModelSizeNumericUpDown)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.npcMinutesNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.npcSecondsNumericUpDown)).BeginInit();
            this.npcStatsTabPage.SuspendLayout();
            this.npcStatsGroupBox.SuspendLayout();
            this.npcAttackStatsGroupBox.SuspendLayout();
            this.npcResistsTabPage.SuspendLayout();
            this.npcOptionsTabPage.SuspendLayout();
            this.npcGuildBankGroupBox.SuspendLayout();
            this.npcStableGroupBox.SuspendLayout();
            this.npcAuctioneerGroupBox.SuspendLayout();
            this.npcBankerGroupBox.SuspendLayout();
            this.npcInnkeeperGroupBox.SuspendLayout();
            this.npcArmorerGroupBox.SuspendLayout();
            this.npcVendorGroupBox.SuspendLayout();
            this.npcGossipGroupBox.SuspendLayout();
            this.npcLootTabPage.SuspendLayout();
            this.npcLootGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.npcLootCopperNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.npcLootSilverNumericUpDown)).BeginInit();
            this.npcFinishTabPage.SuspendLayout();
            this.vendorsTabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.vendorGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vendorAmountNumericUpDown)).BeginInit();
            this.lootTabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lootMaxAmountNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lootGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lootMinAmountNumericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.settingsToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(772, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.arcEmuLocationToolStripMenuItem,
            this.mySQLToolStripMenuItem,
            this.otherToolStripMenuItem});
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.settingsToolStripMenuItem.Text = "Settings";
            // 
            // arcEmuLocationToolStripMenuItem
            // 
            this.arcEmuLocationToolStripMenuItem.Name = "arcEmuLocationToolStripMenuItem";
            this.arcEmuLocationToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.arcEmuLocationToolStripMenuItem.Text = "ArcEmu Location";
            this.arcEmuLocationToolStripMenuItem.Click += new System.EventHandler(this.arcEmuLocationToolStripMenuItem_Click);
            // 
            // mySQLToolStripMenuItem
            // 
            this.mySQLToolStripMenuItem.Name = "mySQLToolStripMenuItem";
            this.mySQLToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.mySQLToolStripMenuItem.Text = "MySQL";
            this.mySQLToolStripMenuItem.Click += new System.EventHandler(this.mySQLToolStripMenuItem_Click);
            // 
            // otherToolStripMenuItem
            // 
            this.otherToolStripMenuItem.Name = "otherToolStripMenuItem";
            this.otherToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.otherToolStripMenuItem.Text = "Other";
            this.otherToolStripMenuItem.Click += new System.EventHandler(this.otherToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.creditsToolStripMenuItem});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.aboutToolStripMenuItem.Text = "About";
            // 
            // creditsToolStripMenuItem
            // 
            this.creditsToolStripMenuItem.Name = "creditsToolStripMenuItem";
            this.creditsToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.creditsToolStripMenuItem.Text = "Credits";
            this.creditsToolStripMenuItem.Click += new System.EventHandler(this.creditsToolStripMenuItem_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage13);
            this.tabControl1.Controls.Add(this.tabPage17);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage18);
            this.tabControl1.Controls.Add(this.creatorTabPage);
            this.tabControl1.Location = new System.Drawing.Point(0, 24);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(772, 450);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.button7);
            this.tabPage3.Controls.Add(this.button5);
            this.tabPage3.Controls.Add(this.button27);
            this.tabPage3.Controls.Add(this.button28);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(764, 424);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Server Management";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.button7.Location = new System.Drawing.Point(8, 237);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(748, 47);
            this.button7.TabIndex = 2;
            this.button7.Text = "Start World Server";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button5
            // 
            this.button5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.button5.Location = new System.Drawing.Point(8, 129);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(748, 47);
            this.button5.TabIndex = 0;
            this.button5.Text = "Start Logon Server";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(8, 129);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(748, 47);
            this.button27.TabIndex = 4;
            this.button27.Text = "Stop Logon Server";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(8, 237);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(748, 47);
            this.button28.TabIndex = 5;
            this.button28.Text = "Stop World Server";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button30);
            this.tabPage1.Controls.Add(this.button29);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.textBox6);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.comboBox3);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.comboBox2);
            this.tabPage1.Controls.Add(this.textBox5);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.textBox4);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.textBox3);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.textBox2);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.comboBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(764, 424);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Accounts";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // button30
            // 
            this.button30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button30.Location = new System.Drawing.Point(305, 54);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(22, 21);
            this.button30.TabIndex = 23;
            this.button30.Text = "-";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(451, 381);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(75, 23);
            this.button29.TabIndex = 22;
            this.button29.Text = "Add Account";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(169, 116);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(121, 20);
            this.textBox1.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(10, 114);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(153, 20);
            this.label11.TabIndex = 21;
            this.label11.Text = "New Account Name:";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(215, 381);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 9;
            this.button2.Text = "Revert";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(338, 381);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 10;
            this.button1.Text = "Save";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(169, 319);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(539, 20);
            this.textBox6.TabIndex = 8;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(61, 317);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(102, 20);
            this.label9.TabIndex = 16;
            this.label9.Text = "Ban Reason:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(433, 246);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 20);
            this.label8.TabIndex = 15;
            this.label8.Text = "Muted";
            // 
            // comboBox3
            // 
            this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "No",
            "Yes"});
            this.comboBox3.Location = new System.Drawing.Point(528, 245);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(57, 21);
            this.comboBox3.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(433, 185);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 20);
            this.label7.TabIndex = 13;
            this.label7.Text = "Banned";
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "No",
            "Yes"});
            this.comboBox2.Location = new System.Drawing.Point(528, 184);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(57, 21);
            this.comboBox2.TabIndex = 5;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(169, 248);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(61, 20);
            this.textBox5.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(111, 246);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 20);
            this.label6.TabIndex = 10;
            this.label6.Text = "Flags:";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(169, 185);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(61, 20);
            this.textBox4.TabIndex = 4;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(35, 185);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(128, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "GM Permissions:";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(528, 120);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(180, 20);
            this.textBox3.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(447, 118);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Email:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(417, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Password:";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(528, 53);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(180, 20);
            this.textBox2.TabIndex = 1;
            this.textBox2.UseSystemPasswordChar = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(287, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "Account ID:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(79, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Account:";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(169, 54);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.charactersCopperNumericUpDown);
            this.tabPage2.Controls.Add(this.charactersSilverNumericUpDown);
            this.tabPage2.Controls.Add(this.charactersCopperLabel);
            this.tabPage2.Controls.Add(this.charactersSilverLabel);
            this.tabPage2.Controls.Add(this.charactersGoldLabel);
            this.tabPage2.Controls.Add(this.button31);
            this.tabPage2.Controls.Add(this.button4);
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Controls.Add(this.charactersGoldTextBox);
            this.tabPage2.Controls.Add(this.charactersMoneyLabel);
            this.tabPage2.Controls.Add(this.comboBox5);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.comboBox4);
            this.tabPage2.Controls.Add(this.textBox7);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.listBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(764, 424);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Characters";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // charactersCopperNumericUpDown
            // 
            this.charactersCopperNumericUpDown.Location = new System.Drawing.Point(560, 285);
            this.charactersCopperNumericUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.charactersCopperNumericUpDown.Name = "charactersCopperNumericUpDown";
            this.charactersCopperNumericUpDown.Size = new System.Drawing.Size(44, 20);
            this.charactersCopperNumericUpDown.TabIndex = 20;
            // 
            // charactersSilverNumericUpDown
            // 
            this.charactersSilverNumericUpDown.Location = new System.Drawing.Point(457, 285);
            this.charactersSilverNumericUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.charactersSilverNumericUpDown.Name = "charactersSilverNumericUpDown";
            this.charactersSilverNumericUpDown.Size = new System.Drawing.Size(44, 20);
            this.charactersSilverNumericUpDown.TabIndex = 19;
            // 
            // charactersCopperLabel
            // 
            this.charactersCopperLabel.AutoSize = true;
            this.charactersCopperLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.charactersCopperLabel.Location = new System.Drawing.Point(610, 286);
            this.charactersCopperLabel.Name = "charactersCopperLabel";
            this.charactersCopperLabel.Size = new System.Drawing.Size(61, 20);
            this.charactersCopperLabel.TabIndex = 18;
            this.charactersCopperLabel.Text = "Copper";
            // 
            // charactersSilverLabel
            // 
            this.charactersSilverLabel.AutoSize = true;
            this.charactersSilverLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.charactersSilverLabel.Location = new System.Drawing.Point(507, 285);
            this.charactersSilverLabel.Name = "charactersSilverLabel";
            this.charactersSilverLabel.Size = new System.Drawing.Size(47, 20);
            this.charactersSilverLabel.TabIndex = 16;
            this.charactersSilverLabel.Text = "Silver";
            // 
            // charactersGoldLabel
            // 
            this.charactersGoldLabel.AutoSize = true;
            this.charactersGoldLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.charactersGoldLabel.Location = new System.Drawing.Point(408, 286);
            this.charactersGoldLabel.Name = "charactersGoldLabel";
            this.charactersGoldLabel.Size = new System.Drawing.Size(43, 20);
            this.charactersGoldLabel.TabIndex = 14;
            this.charactersGoldLabel.Text = "Gold";
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(478, 367);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(75, 23);
            this.button31.TabIndex = 13;
            this.button31.Text = "Remove";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(356, 367);
            this.button4.MinimumSize = new System.Drawing.Size(75, 23);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 12;
            this.button4.Text = "Revert";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(601, 367);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 11;
            this.button3.Text = "Save";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // charactersGoldTextBox
            // 
            this.charactersGoldTextBox.Location = new System.Drawing.Point(345, 285);
            this.charactersGoldTextBox.Name = "charactersGoldTextBox";
            this.charactersGoldTextBox.Size = new System.Drawing.Size(57, 20);
            this.charactersGoldTextBox.TabIndex = 10;
            // 
            // charactersMoneyLabel
            // 
            this.charactersMoneyLabel.AutoSize = true;
            this.charactersMoneyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.charactersMoneyLabel.Location = new System.Drawing.Point(269, 285);
            this.charactersMoneyLabel.Name = "charactersMoneyLabel";
            this.charactersMoneyLabel.Size = new System.Drawing.Size(56, 20);
            this.charactersMoneyLabel.TabIndex = 9;
            this.charactersMoneyLabel.Text = "Money";
            // 
            // comboBox5
            // 
            this.comboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.comboBox5.Location = new System.Drawing.Point(345, 225);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(77, 21);
            this.comboBox5.TabIndex = 8;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(258, 225);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(67, 20);
            this.label16.TabIndex = 7;
            this.label16.Text = "Gender:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(352, 19);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(107, 24);
            this.label14.TabIndex = 5;
            this.label14.Text = "Account ID:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(256, 158);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(69, 20);
            this.label13.TabIndex = 4;
            this.label13.Text = "Banned:";
            // 
            // comboBox4
            // 
            this.comboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "No",
            "Yes"});
            this.comboBox4.Location = new System.Drawing.Point(345, 157);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(68, 21);
            this.comboBox4.TabIndex = 3;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(331, 95);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 20);
            this.textBox7.TabIndex = 2;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(258, 93);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(55, 20);
            this.label12.TabIndex = 1;
            this.label12.Text = "Name:";
            // 
            // listBox1
            // 
            this.listBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(8, 6);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(232, 407);
            this.listBox1.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.textBox23);
            this.tabPage4.Controls.Add(this.label53);
            this.tabPage4.Controls.Add(this.button22);
            this.tabPage4.Controls.Add(this.button21);
            this.tabPage4.Controls.Add(this.button20);
            this.tabPage4.Controls.Add(this.label52);
            this.tabPage4.Controls.Add(this.textBox22);
            this.tabPage4.Controls.Add(this.listBox4);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(764, 424);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "IP Bans";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(413, 186);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(343, 20);
            this.textBox23.TabIndex = 2;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(306, 190);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(90, 18);
            this.label53.TabIndex = 6;
            this.label53.Text = "Ban Reason";
            // 
            // button22
            // 
            this.button22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.Location = new System.Drawing.Point(413, 355);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(175, 49);
            this.button22.TabIndex = 4;
            this.button22.Text = "Delete All";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button21
            // 
            this.button21.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.Location = new System.Drawing.Point(251, 174);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(37, 34);
            this.button21.TabIndex = 4;
            this.button21.Text = "-";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(474, 232);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(56, 36);
            this.button20.TabIndex = 3;
            this.button20.Text = "Add";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(317, 137);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(79, 18);
            this.label52.TabIndex = 2;
            this.label52.Text = "IP Address";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(413, 135);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(163, 20);
            this.textBox22.TabIndex = 1;
            // 
            // listBox4
            // 
            this.listBox4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.listBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBox4.FormattingEnabled = true;
            this.listBox4.ItemHeight = 16;
            this.listBox4.Location = new System.Drawing.Point(8, 23);
            this.listBox4.Name = "listBox4";
            this.listBox4.Size = new System.Drawing.Size(237, 372);
            this.listBox4.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.button23);
            this.tabPage5.Controls.Add(this.button24);
            this.tabPage5.Controls.Add(this.button25);
            this.tabPage5.Controls.Add(this.label55);
            this.tabPage5.Controls.Add(this.textBox25);
            this.tabPage5.Controls.Add(this.listBox5);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(764, 424);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Banned Names";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.Location = new System.Drawing.Point(413, 354);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(175, 49);
            this.button23.TabIndex = 13;
            this.button23.Text = "Delete All";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button24
            // 
            this.button24.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.Location = new System.Drawing.Point(251, 173);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(37, 34);
            this.button24.TabIndex = 12;
            this.button24.Text = "-";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(474, 219);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(56, 36);
            this.button25.TabIndex = 11;
            this.button25.Text = "Add";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(410, 160);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(48, 18);
            this.label55.TabIndex = 9;
            this.label55.Text = "Name";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(474, 161);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(163, 20);
            this.textBox25.TabIndex = 8;
            // 
            // listBox5
            // 
            this.listBox5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.listBox5.FormattingEnabled = true;
            this.listBox5.Location = new System.Drawing.Point(8, 22);
            this.listBox5.Name = "listBox5";
            this.listBox5.Size = new System.Drawing.Size(237, 381);
            this.listBox5.TabIndex = 7;
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.button19);
            this.tabPage13.Controls.Add(this.label51);
            this.tabPage13.Controls.Add(this.button17);
            this.tabPage13.Controls.Add(this.button18);
            this.tabPage13.Controls.Add(this.listBox3);
            this.tabPage13.Controls.Add(this.listBox2);
            this.tabPage13.Location = new System.Drawing.Point(4, 22);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Size = new System.Drawing.Size(764, 424);
            this.tabPage13.TabIndex = 6;
            this.tabPage13.Text = "Player Items";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(606, 20);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(110, 23);
            this.button19.TabIndex = 6;
            this.button19.Text = "Search For Items";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(497, 56);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(106, 18);
            this.label51.TabIndex = 5;
            this.label51.Text = "Account Name";
            // 
            // button17
            // 
            this.button17.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.Location = new System.Drawing.Point(500, 131);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(37, 34);
            this.button17.TabIndex = 4;
            this.button17.Text = "+";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button18
            // 
            this.button18.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.Location = new System.Drawing.Point(500, 208);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(37, 34);
            this.button18.TabIndex = 3;
            this.button18.Text = "-";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // listBox3
            // 
            this.listBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.listBox3.FormattingEnabled = true;
            this.listBox3.Location = new System.Drawing.Point(278, 20);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(204, 381);
            this.listBox3.TabIndex = 1;
            // 
            // listBox2
            // 
            this.listBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(43, 20);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(214, 381);
            this.listBox2.TabIndex = 0;
            // 
            // tabPage17
            // 
            this.tabPage17.Controls.Add(this.mailCopperNumericUpDown);
            this.tabPage17.Controls.Add(this.mailSilverNumericUpDown);
            this.tabPage17.Controls.Add(this.mailCopperLabel);
            this.tabPage17.Controls.Add(this.mailSilverLabel);
            this.tabPage17.Controls.Add(this.mailGoldLabel);
            this.tabPage17.Controls.Add(this.mailGoldTextBox);
            this.tabPage17.Controls.Add(this.mailMoneyLabel);
            this.tabPage17.Controls.Add(this.button34);
            this.tabPage17.Controls.Add(this.textBox27);
            this.tabPage17.Controls.Add(this.label59);
            this.tabPage17.Controls.Add(this.button33);
            this.tabPage17.Controls.Add(this.textBox26);
            this.tabPage17.Controls.Add(this.label57);
            this.tabPage17.Controls.Add(this.label54);
            this.tabPage17.Controls.Add(this.richTextBox1);
            this.tabPage17.Controls.Add(this.label10);
            this.tabPage17.Controls.Add(this.comboBox13);
            this.tabPage17.Controls.Add(this.button32);
            this.tabPage17.Location = new System.Drawing.Point(4, 22);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Size = new System.Drawing.Size(764, 424);
            this.tabPage17.TabIndex = 7;
            this.tabPage17.Text = "Send Mail";
            this.tabPage17.UseVisualStyleBackColor = true;
            // 
            // mailCopperNumericUpDown
            // 
            this.mailCopperNumericUpDown.Location = new System.Drawing.Point(473, 341);
            this.mailCopperNumericUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.mailCopperNumericUpDown.Name = "mailCopperNumericUpDown";
            this.mailCopperNumericUpDown.Size = new System.Drawing.Size(44, 20);
            this.mailCopperNumericUpDown.TabIndex = 6;
            // 
            // mailSilverNumericUpDown
            // 
            this.mailSilverNumericUpDown.Location = new System.Drawing.Point(370, 341);
            this.mailSilverNumericUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.mailSilverNumericUpDown.Name = "mailSilverNumericUpDown";
            this.mailSilverNumericUpDown.Size = new System.Drawing.Size(44, 20);
            this.mailSilverNumericUpDown.TabIndex = 5;
            // 
            // mailCopperLabel
            // 
            this.mailCopperLabel.AutoSize = true;
            this.mailCopperLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mailCopperLabel.Location = new System.Drawing.Point(523, 342);
            this.mailCopperLabel.Name = "mailCopperLabel";
            this.mailCopperLabel.Size = new System.Drawing.Size(61, 20);
            this.mailCopperLabel.TabIndex = 25;
            this.mailCopperLabel.Text = "Copper";
            // 
            // mailSilverLabel
            // 
            this.mailSilverLabel.AutoSize = true;
            this.mailSilverLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mailSilverLabel.Location = new System.Drawing.Point(420, 341);
            this.mailSilverLabel.Name = "mailSilverLabel";
            this.mailSilverLabel.Size = new System.Drawing.Size(47, 20);
            this.mailSilverLabel.TabIndex = 24;
            this.mailSilverLabel.Text = "Silver";
            // 
            // mailGoldLabel
            // 
            this.mailGoldLabel.AutoSize = true;
            this.mailGoldLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mailGoldLabel.Location = new System.Drawing.Point(321, 341);
            this.mailGoldLabel.Name = "mailGoldLabel";
            this.mailGoldLabel.Size = new System.Drawing.Size(43, 20);
            this.mailGoldLabel.TabIndex = 23;
            this.mailGoldLabel.Text = "Gold";
            // 
            // mailGoldTextBox
            // 
            this.mailGoldTextBox.Location = new System.Drawing.Point(263, 342);
            this.mailGoldTextBox.Name = "mailGoldTextBox";
            this.mailGoldTextBox.Size = new System.Drawing.Size(52, 20);
            this.mailGoldTextBox.TabIndex = 4;
            this.mailGoldTextBox.Text = "0";
            // 
            // mailMoneyLabel
            // 
            this.mailMoneyLabel.AutoSize = true;
            this.mailMoneyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mailMoneyLabel.Location = new System.Drawing.Point(176, 341);
            this.mailMoneyLabel.Name = "mailMoneyLabel";
            this.mailMoneyLabel.Size = new System.Drawing.Size(56, 20);
            this.mailMoneyLabel.TabIndex = 21;
            this.mailMoneyLabel.Text = "Money";
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(273, 390);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(75, 23);
            this.button34.TabIndex = 7;
            this.button34.Text = "Clear";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(180, 91);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(177, 20);
            this.textBox27.TabIndex = 1;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(113, 91);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(61, 18);
            this.label59.TabIndex = 16;
            this.label59.Text = "Subject:";
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(609, 36);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(110, 23);
            this.button33.TabIndex = 7;
            this.button33.Text = "Search For Items";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(546, 92);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(77, 20);
            this.textBox26.TabIndex = 2;
            this.textBox26.Text = "0";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(437, 92);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(92, 18);
            this.label57.TabIndex = 6;
            this.label57.Text = "Item Entry ID";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(331, 133);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(100, 25);
            this.label54.TabIndex = 4;
            this.label54.Text = "Message";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(91, 165);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(587, 153);
            this.richTextBox1.TabIndex = 3;
            this.richTextBox1.Text = "";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(284, 36);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 18);
            this.label10.TabIndex = 2;
            this.label10.Text = "Send To";
            // 
            // comboBox13
            // 
            this.comboBox13.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox13.FormattingEnabled = true;
            this.comboBox13.Location = new System.Drawing.Point(354, 36);
            this.comboBox13.Name = "comboBox13";
            this.comboBox13.Size = new System.Drawing.Size(121, 21);
            this.comboBox13.TabIndex = 0;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(431, 390);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(75, 23);
            this.button32.TabIndex = 6;
            this.button32.Text = "Send";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.tabControl2);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(764, 424);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Config Generator";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Controls.Add(this.tabPage9);
            this.tabControl2.Controls.Add(this.tabPage10);
            this.tabControl2.Location = new System.Drawing.Point(3, 3);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(765, 422);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.button8);
            this.tabPage7.Controls.Add(this.button6);
            this.tabPage7.Controls.Add(this.label19);
            this.tabPage7.Controls.Add(this.textBox10);
            this.tabPage7.Controls.Add(this.label18);
            this.tabPage7.Controls.Add(this.textBox9);
            this.tabPage7.Controls.Add(this.label15);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(757, 396);
            this.tabPage7.TabIndex = 0;
            this.tabPage7.Text = "Logon";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(202, 301);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(122, 49);
            this.button8.TabIndex = 8;
            this.button8.Text = "Save Default Config";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(409, 301);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(122, 49);
            this.button6.TabIndex = 7;
            this.button6.Text = "Save Config File";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(42, 147);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(451, 40);
            this.label19.TabIndex = 4;
            this.label19.Text = "Note: This must be the same between the Logon Configuration\r\nand the World Config" +
                "uration";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(327, 223);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(150, 20);
            this.textBox10.TabIndex = 3;
            this.textBox10.UseSystemPasswordChar = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(58, 223);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(225, 18);
            this.label18.TabIndex = 2;
            this.label18.Text = "Logon Server Remote Password";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(327, 79);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(90, 20);
            this.textBox9.TabIndex = 1;
            this.textBox9.Text = "600";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(58, 78);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(241, 18);
            this.label15.TabIndex = 0;
            this.label15.Text = "Account Refresh Time (in seconds)";
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.tabControl3);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(757, 396);
            this.tabPage8.TabIndex = 1;
            this.tabPage8.Text = "World";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage11);
            this.tabControl3.Controls.Add(this.tabPage12);
            this.tabControl3.Controls.Add(this.tabPage14);
            this.tabControl3.Controls.Add(this.tabPage16);
            this.tabControl3.Controls.Add(this.tabPage15);
            this.tabControl3.Location = new System.Drawing.Point(0, 0);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(761, 396);
            this.tabControl3.TabIndex = 2;
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.button9);
            this.tabPage11.Controls.Add(this.label21);
            this.tabPage11.Controls.Add(this.textBox11);
            this.tabPage11.Controls.Add(this.label20);
            this.tabPage11.Location = new System.Drawing.Point(4, 22);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(753, 370);
            this.tabPage11.TabIndex = 0;
            this.tabPage11.Text = "Main";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(601, 303);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(127, 42);
            this.button9.TabIndex = 6;
            this.button9.Text = "Next";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(146, 61);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(534, 48);
            this.label21.TabIndex = 5;
            this.label21.Text = "Note: This must be the same between the Logon Configuration\r\nand the World Config" +
                "uration";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(362, 154);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(171, 20);
            this.textBox11.TabIndex = 2;
            this.textBox11.UseSystemPasswordChar = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(212, 153);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(132, 18);
            this.label20.TabIndex = 1;
            this.label20.Text = "Remote Password";
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.textBox12);
            this.tabPage12.Controls.Add(this.label33);
            this.tabPage12.Controls.Add(this.button10);
            this.tabPage12.Controls.Add(this.numericUpDown9);
            this.tabPage12.Controls.Add(this.label32);
            this.tabPage12.Controls.Add(this.numericUpDown8);
            this.tabPage12.Controls.Add(this.label31);
            this.tabPage12.Controls.Add(this.numericUpDown7);
            this.tabPage12.Controls.Add(this.label30);
            this.tabPage12.Controls.Add(this.numericUpDown6);
            this.tabPage12.Controls.Add(this.label29);
            this.tabPage12.Controls.Add(this.numericUpDown5);
            this.tabPage12.Controls.Add(this.label28);
            this.tabPage12.Controls.Add(this.numericUpDown4);
            this.tabPage12.Controls.Add(this.label27);
            this.tabPage12.Controls.Add(this.numericUpDown3);
            this.tabPage12.Controls.Add(this.label26);
            this.tabPage12.Controls.Add(this.label25);
            this.tabPage12.Controls.Add(this.numericUpDown2);
            this.tabPage12.Controls.Add(this.label24);
            this.tabPage12.Controls.Add(this.numericUpDown1);
            this.tabPage12.Controls.Add(this.label23);
            this.tabPage12.Controls.Add(this.label22);
            this.tabPage12.Location = new System.Drawing.Point(4, 22);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage12.Size = new System.Drawing.Size(753, 370);
            this.tabPage12.TabIndex = 1;
            this.tabPage12.Text = "Rates";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(546, 50);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 20);
            this.textBox12.TabIndex = 22;
            this.textBox12.Text = "300000";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(352, 53);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(170, 18);
            this.label33.TabIndex = 21;
            this.label33.Text = "Player Auto Save (in ms)";
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(601, 303);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(127, 42);
            this.button10.TabIndex = 20;
            this.button10.Text = "Next";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // numericUpDown9
            // 
            this.numericUpDown9.Location = new System.Drawing.Point(381, 308);
            this.numericUpDown9.Name = "numericUpDown9";
            this.numericUpDown9.Size = new System.Drawing.Size(78, 20);
            this.numericUpDown9.TabIndex = 19;
            this.numericUpDown9.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(291, 308);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(53, 18);
            this.label32.TabIndex = 18;
            this.label32.Text = "Artifact";
            // 
            // numericUpDown8
            // 
            this.numericUpDown8.Location = new System.Drawing.Point(381, 257);
            this.numericUpDown8.Name = "numericUpDown8";
            this.numericUpDown8.Size = new System.Drawing.Size(78, 20);
            this.numericUpDown8.TabIndex = 17;
            this.numericUpDown8.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(291, 259);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(57, 18);
            this.label31.TabIndex = 16;
            this.label31.Text = "Orange";
            // 
            // numericUpDown7
            // 
            this.numericUpDown7.Location = new System.Drawing.Point(381, 207);
            this.numericUpDown7.Name = "numericUpDown7";
            this.numericUpDown7.Size = new System.Drawing.Size(78, 20);
            this.numericUpDown7.TabIndex = 15;
            this.numericUpDown7.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(291, 205);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(50, 18);
            this.label30.TabIndex = 14;
            this.label30.Text = "Purple";
            // 
            // numericUpDown6
            // 
            this.numericUpDown6.Location = new System.Drawing.Point(95, 326);
            this.numericUpDown6.Name = "numericUpDown6";
            this.numericUpDown6.Size = new System.Drawing.Size(78, 20);
            this.numericUpDown6.TabIndex = 13;
            this.numericUpDown6.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(38, 324);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(37, 18);
            this.label29.TabIndex = 12;
            this.label29.Text = "Blue";
            // 
            // numericUpDown5
            // 
            this.numericUpDown5.Location = new System.Drawing.Point(95, 286);
            this.numericUpDown5.Name = "numericUpDown5";
            this.numericUpDown5.Size = new System.Drawing.Size(78, 20);
            this.numericUpDown5.TabIndex = 11;
            this.numericUpDown5.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(30, 284);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(49, 18);
            this.label28.TabIndex = 10;
            this.label28.Text = "Green";
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.Location = new System.Drawing.Point(95, 239);
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(78, 20);
            this.numericUpDown4.TabIndex = 9;
            this.numericUpDown4.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(33, 239);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(46, 18);
            this.label27.TabIndex = 8;
            this.label27.Text = "White";
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Location = new System.Drawing.Point(95, 188);
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(78, 20);
            this.numericUpDown3.TabIndex = 7;
            this.numericUpDown3.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(35, 188);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(40, 18);
            this.label26.TabIndex = 6;
            this.label26.Text = "Gray";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(330, 138);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(100, 24);
            this.label25.TabIndex = 5;
            this.label25.Text = "Item Drops";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(102, 102);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(78, 20);
            this.numericUpDown2.TabIndex = 4;
            this.numericUpDown2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(26, 104);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(53, 18);
            this.label24.TabIndex = 3;
            this.label24.Text = "Money";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(102, 51);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(78, 20);
            this.numericUpDown1.TabIndex = 2;
            this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(51, 53);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(28, 18);
            this.label23.TabIndex = 1;
            this.label23.Text = "XP";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(4, 10);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(123, 24);
            this.label22.TabIndex = 0;
            this.label22.Text = "Multiples Of...";
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.button11);
            this.tabPage14.Controls.Add(this.textBox15);
            this.tabPage14.Controls.Add(this.textBox14);
            this.tabPage14.Controls.Add(this.textBox13);
            this.tabPage14.Controls.Add(this.label37);
            this.tabPage14.Controls.Add(this.label36);
            this.tabPage14.Controls.Add(this.label35);
            this.tabPage14.Controls.Add(this.label34);
            this.tabPage14.Controls.Add(this.comboBox6);
            this.tabPage14.Location = new System.Drawing.Point(4, 22);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Size = new System.Drawing.Size(753, 370);
            this.tabPage14.TabIndex = 3;
            this.tabPage14.Text = "Limits";
            this.tabPage14.UseVisualStyleBackColor = true;
            this.tabPage14.Click += new System.EventHandler(this.tabPage14_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(601, 303);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(127, 42);
            this.button11.TabIndex = 21;
            this.button11.Text = "Next";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(582, 214);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(74, 20);
            this.textBox15.TabIndex = 7;
            this.textBox15.Text = "80000";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(326, 214);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(79, 20);
            this.textBox14.TabIndex = 6;
            this.textBox14.Text = "100000";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(56, 214);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(80, 20);
            this.textBox13.TabIndex = 5;
            this.textBox13.Text = "30000";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(579, 166);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(77, 18);
            this.label37.TabIndex = 4;
            this.label37.Text = "Max Mana";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(323, 166);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(82, 18);
            this.label36.TabIndex = 3;
            this.label36.Text = "Max Health";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(32, 166);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(132, 18);
            this.label35.TabIndex = 2;
            this.label35.Text = "Max Spell Damage";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(272, 43);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(61, 18);
            this.label34.TabIndex = 1;
            this.label34.Text = "Enabled";
            // 
            // comboBox6
            // 
            this.comboBox6.DisplayMember = "1";
            this.comboBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            "No",
            "Yes"});
            this.comboBox6.Location = new System.Drawing.Point(360, 44);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(61, 21);
            this.comboBox6.TabIndex = 0;
            // 
            // tabPage16
            // 
            this.tabPage16.Controls.Add(this.comboBox12);
            this.tabPage16.Controls.Add(this.label50);
            this.tabPage16.Controls.Add(this.button12);
            this.tabPage16.Controls.Add(this.textBox16);
            this.tabPage16.Controls.Add(this.label39);
            this.tabPage16.Controls.Add(this.comboBox7);
            this.tabPage16.Controls.Add(this.label38);
            this.tabPage16.Location = new System.Drawing.Point(4, 22);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Size = new System.Drawing.Size(753, 370);
            this.tabPage16.TabIndex = 5;
            this.tabPage16.Text = "Other";
            this.tabPage16.UseVisualStyleBackColor = true;
            // 
            // comboBox12
            // 
            this.comboBox12.DisplayMember = "1";
            this.comboBox12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.Items.AddRange(new object[] {
            "On",
            "Off"});
            this.comboBox12.Location = new System.Drawing.Point(420, 193);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(61, 21);
            this.comboBox12.TabIndex = 24;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(313, 193);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(65, 18);
            this.label50.TabIndex = 23;
            this.label50.Text = "Collision";
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(601, 303);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(127, 42);
            this.button12.TabIndex = 22;
            this.button12.Text = "Finish";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(453, 104);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(125, 20);
            this.textBox16.TabIndex = 5;
            this.textBox16.Text = "gm_sync_channel";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(450, 64);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(91, 18);
            this.label39.TabIndex = 4;
            this.label39.Text = "GM Channel";
            // 
            // comboBox7
            // 
            this.comboBox7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            "No",
            "Yes"});
            this.comboBox7.Location = new System.Drawing.Point(245, 104);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(61, 21);
            this.comboBox7.TabIndex = 3;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(169, 64);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(229, 18);
            this.label38.TabIndex = 2;
            this.label38.Text = "Should GM\'s Start on GM Island?";
            // 
            // tabPage15
            // 
            this.tabPage15.Controls.Add(this.button14);
            this.tabPage15.Controls.Add(this.button13);
            this.tabPage15.Location = new System.Drawing.Point(4, 22);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Size = new System.Drawing.Size(753, 370);
            this.tabPage15.TabIndex = 4;
            this.tabPage15.Text = "Finish";
            this.tabPage15.UseVisualStyleBackColor = true;
            // 
            // button14
            // 
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.Location = new System.Drawing.Point(98, 136);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(208, 74);
            this.button14.TabIndex = 1;
            this.button14.Text = "Start Over";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.Location = new System.Drawing.Point(456, 136);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(208, 74);
            this.button13.TabIndex = 0;
            this.button13.Text = "Save Config File";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.button15);
            this.tabPage9.Controls.Add(this.textBox19);
            this.tabPage9.Controls.Add(this.textBox18);
            this.tabPage9.Controls.Add(this.label42);
            this.tabPage9.Controls.Add(this.label41);
            this.tabPage9.Controls.Add(this.textBox17);
            this.tabPage9.Controls.Add(this.label40);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(757, 396);
            this.tabPage9.TabIndex = 2;
            this.tabPage9.Text = "Realm";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(357, 277);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(115, 46);
            this.button15.TabIndex = 14;
            this.button15.Text = "Save Config File";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(402, 185);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(70, 20);
            this.textBox19.TabIndex = 13;
            this.textBox19.Text = "8129";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(402, 128);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(142, 20);
            this.textBox18.TabIndex = 12;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(271, 187);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(83, 18);
            this.label42.TabIndex = 11;
            this.label42.Text = "Realm Port";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(245, 130);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(109, 18);
            this.label41.TabIndex = 10;
            this.label41.Text = "Realm Address";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(402, 74);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(110, 20);
            this.textBox17.TabIndex = 9;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(259, 73);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(95, 18);
            this.label40.TabIndex = 8;
            this.label40.Text = "Realm Name";
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.button16);
            this.tabPage10.Controls.Add(this.comboBox11);
            this.tabPage10.Controls.Add(this.label49);
            this.tabPage10.Controls.Add(this.comboBox10);
            this.tabPage10.Controls.Add(this.label48);
            this.tabPage10.Controls.Add(this.textBox21);
            this.tabPage10.Controls.Add(this.textBox20);
            this.tabPage10.Controls.Add(this.label47);
            this.tabPage10.Controls.Add(this.label46);
            this.tabPage10.Controls.Add(this.comboBox9);
            this.tabPage10.Controls.Add(this.label45);
            this.tabPage10.Controls.Add(this.comboBox8);
            this.tabPage10.Controls.Add(this.label44);
            this.tabPage10.Controls.Add(this.numericUpDown10);
            this.tabPage10.Controls.Add(this.label43);
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Size = new System.Drawing.Size(757, 396);
            this.tabPage10.TabIndex = 3;
            this.tabPage10.Text = "Optional";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(563, 278);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(115, 46);
            this.button16.TabIndex = 18;
            this.button16.Text = "Save Config File";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // comboBox11
            // 
            this.comboBox11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Items.AddRange(new object[] {
            "No",
            "Yes"});
            this.comboBox11.Location = new System.Drawing.Point(616, 129);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(62, 21);
            this.comboBox11.TabIndex = 17;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(440, 129);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(127, 18);
            this.label49.TabIndex = 16;
            this.label49.Text = "Death Knight Limit";
            // 
            // comboBox10
            // 
            this.comboBox10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Items.AddRange(new object[] {
            "No",
            "Yes"});
            this.comboBox10.Location = new System.Drawing.Point(616, 62);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(62, 21);
            this.comboBox10.TabIndex = 15;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(387, 65);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(180, 18);
            this.label48.TabIndex = 14;
            this.label48.Text = "Death Knight Requirement";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(181, 304);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(100, 20);
            this.textBox21.TabIndex = 13;
            this.textBox21.Text = "214748";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(181, 247);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(100, 20);
            this.textBox20.TabIndex = 12;
            this.textBox20.Text = "0";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(78, 304);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(72, 18);
            this.label47.TabIndex = 11;
            this.label47.Text = "Max Gold";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(56, 247);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(94, 18);
            this.label46.TabIndex = 9;
            this.label46.Text = "Starting Gold";
            // 
            // comboBox9
            // 
            this.comboBox9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Items.AddRange(new object[] {
            "No",
            "Yes"});
            this.comboBox9.Location = new System.Drawing.Point(181, 189);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(62, 21);
            this.comboBox9.TabIndex = 8;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(30, 189);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(120, 18);
            this.label45.TabIndex = 7;
            this.label45.Text = "Enable Gold Cap";
            // 
            // comboBox8
            // 
            this.comboBox8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            "No",
            "Yes"});
            this.comboBox8.Location = new System.Drawing.Point(181, 130);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(62, 21);
            this.comboBox8.TabIndex = 6;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(41, 130);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(109, 18);
            this.label44.TabIndex = 5;
            this.label44.Text = "Instant Level 80";
            // 
            // numericUpDown10
            // 
            this.numericUpDown10.Location = new System.Drawing.Point(181, 63);
            this.numericUpDown10.Name = "numericUpDown10";
            this.numericUpDown10.Size = new System.Drawing.Size(78, 20);
            this.numericUpDown10.TabIndex = 4;
            this.numericUpDown10.Value = new decimal(new int[] {
            80,
            0,
            0,
            0});
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(76, 65);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(74, 18);
            this.label43.TabIndex = 3;
            this.label43.Text = "Max Level";
            // 
            // tabPage18
            // 
            this.tabPage18.Controls.Add(this.richTextBox2);
            this.tabPage18.Controls.Add(this.button35);
            this.tabPage18.Controls.Add(this.label58);
            this.tabPage18.Location = new System.Drawing.Point(4, 22);
            this.tabPage18.Name = "tabPage18";
            this.tabPage18.Size = new System.Drawing.Size(764, 424);
            this.tabPage18.TabIndex = 8;
            this.tabPage18.Text = "GM Log";
            this.tabPage18.UseVisualStyleBackColor = true;
            // 
            // richTextBox2
            // 
            this.richTextBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.richTextBox2.Location = new System.Drawing.Point(3, 102);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.ReadOnly = true;
            this.richTextBox2.Size = new System.Drawing.Size(753, 311);
            this.richTextBox2.TabIndex = 5;
            this.richTextBox2.Text = "";
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(314, 70);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(108, 26);
            this.button35.TabIndex = 4;
            this.button35.Text = "Select File";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(307, 21);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(131, 37);
            this.label58.TabIndex = 3;
            this.label58.Text = "GM Log";
            // 
            // creatorTabPage
            // 
            this.creatorTabPage.Controls.Add(this.creatorTabControl);
            this.creatorTabPage.Location = new System.Drawing.Point(4, 22);
            this.creatorTabPage.Name = "creatorTabPage";
            this.creatorTabPage.Size = new System.Drawing.Size(764, 424);
            this.creatorTabPage.TabIndex = 9;
            this.creatorTabPage.Text = "SQL Creator";
            this.creatorTabPage.UseVisualStyleBackColor = true;
            // 
            // creatorTabControl
            // 
            this.creatorTabControl.Controls.Add(this.itemsTabPage);
            this.creatorTabControl.Controls.Add(this.weaponsTabPage);
            this.creatorTabControl.Controls.Add(this.armorTabPage);
            this.creatorTabControl.Controls.Add(this.npcTabPage);
            this.creatorTabControl.Controls.Add(this.vendorsTabPage);
            this.creatorTabControl.Controls.Add(this.lootTabPage);
            this.creatorTabControl.Location = new System.Drawing.Point(0, 0);
            this.creatorTabControl.Name = "creatorTabControl";
            this.creatorTabControl.SelectedIndex = 0;
            this.creatorTabControl.Size = new System.Drawing.Size(768, 428);
            this.creatorTabControl.TabIndex = 0;
            // 
            // itemsTabPage
            // 
            this.itemsTabPage.Controls.Add(this.itemsTabControl);
            this.itemsTabPage.Location = new System.Drawing.Point(4, 22);
            this.itemsTabPage.Name = "itemsTabPage";
            this.itemsTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.itemsTabPage.Size = new System.Drawing.Size(760, 402);
            this.itemsTabPage.TabIndex = 1;
            this.itemsTabPage.Text = "Items";
            this.itemsTabPage.UseVisualStyleBackColor = true;
            // 
            // itemsTabControl
            // 
            this.itemsTabControl.Controls.Add(this.itemDetailsTabPage);
            this.itemsTabControl.Controls.Add(this.itemRequirementsTabPage);
            this.itemsTabControl.Controls.Add(this.itemPriceTabPage);
            this.itemsTabControl.Controls.Add(this.itemFinishTabPage);
            this.itemsTabControl.Location = new System.Drawing.Point(0, 0);
            this.itemsTabControl.Name = "itemsTabControl";
            this.itemsTabControl.SelectedIndex = 0;
            this.itemsTabControl.Size = new System.Drawing.Size(764, 406);
            this.itemsTabControl.TabIndex = 0;
            // 
            // itemDetailsTabPage
            // 
            this.itemDetailsTabPage.Controls.Add(this.label62);
            this.itemDetailsTabPage.Controls.Add(this.itemDisplayIDSearch);
            this.itemDetailsTabPage.Controls.Add(this.itemLevelTextBox);
            this.itemDetailsTabPage.Controls.Add(this.itemLevelLabel);
            this.itemDetailsTabPage.Controls.Add(this.itemBindsComboBox);
            this.itemDetailsTabPage.Controls.Add(this.itemBindsLabel);
            this.itemDetailsTabPage.Controls.Add(this.itemTypeComboBox);
            this.itemDetailsTabPage.Controls.Add(this.itemTypeLabel);
            this.itemDetailsTabPage.Controls.Add(this.itemDetailsNextButton);
            this.itemDetailsTabPage.Controls.Add(this.itemEntryTextBox);
            this.itemDetailsTabPage.Controls.Add(this.itemEntryidLabel);
            this.itemDetailsTabPage.Controls.Add(this.itemDisplayidTextBox);
            this.itemDetailsTabPage.Controls.Add(this.itemDisplayidLabel);
            this.itemDetailsTabPage.Controls.Add(this.itemQualityComboBox);
            this.itemDetailsTabPage.Controls.Add(this.itemQualityLabel);
            this.itemDetailsTabPage.Controls.Add(this.itemQuoteTextBox);
            this.itemDetailsTabPage.Controls.Add(this.itemQuoteLabel);
            this.itemDetailsTabPage.Controls.Add(this.itemNameTextBox);
            this.itemDetailsTabPage.Controls.Add(this.itemNameLabel);
            this.itemDetailsTabPage.Location = new System.Drawing.Point(4, 22);
            this.itemDetailsTabPage.Name = "itemDetailsTabPage";
            this.itemDetailsTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.itemDetailsTabPage.Size = new System.Drawing.Size(756, 380);
            this.itemDetailsTabPage.TabIndex = 0;
            this.itemDetailsTabPage.Text = "Details";
            this.itemDetailsTabPage.UseVisualStyleBackColor = true;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(39, 343);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(90, 18);
            this.label62.TabIndex = 65;
            this.label62.Text = "* = Required";
            // 
            // itemDisplayIDSearch
            // 
            this.itemDisplayIDSearch.Location = new System.Drawing.Point(309, 342);
            this.itemDisplayIDSearch.Name = "itemDisplayIDSearch";
            this.itemDisplayIDSearch.Size = new System.Drawing.Size(148, 23);
            this.itemDisplayIDSearch.TabIndex = 9;
            this.itemDisplayIDSearch.Text = "Search For Display IDs";
            this.itemDisplayIDSearch.UseVisualStyleBackColor = true;
            this.itemDisplayIDSearch.Click += new System.EventHandler(this.button39_Click);
            // 
            // itemLevelTextBox
            // 
            this.itemLevelTextBox.Location = new System.Drawing.Point(464, 148);
            this.itemLevelTextBox.Name = "itemLevelTextBox";
            this.itemLevelTextBox.Size = new System.Drawing.Size(49, 20);
            this.itemLevelTextBox.TabIndex = 8;
            this.itemLevelTextBox.Text = "0";
            // 
            // itemLevelLabel
            // 
            this.itemLevelLabel.AutoSize = true;
            this.itemLevelLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemLevelLabel.Location = new System.Drawing.Point(383, 148);
            this.itemLevelLabel.Name = "itemLevelLabel";
            this.itemLevelLabel.Size = new System.Drawing.Size(74, 18);
            this.itemLevelLabel.TabIndex = 32;
            this.itemLevelLabel.Text = "Item Level";
            // 
            // itemBindsComboBox
            // 
            this.itemBindsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.itemBindsComboBox.FormattingEnabled = true;
            this.itemBindsComboBox.Items.AddRange(new object[] {
            "None",
            "On Pickup",
            "On Use"});
            this.itemBindsComboBox.Location = new System.Drawing.Point(463, 98);
            this.itemBindsComboBox.Name = "itemBindsComboBox";
            this.itemBindsComboBox.Size = new System.Drawing.Size(85, 21);
            this.itemBindsComboBox.TabIndex = 7;
            // 
            // itemBindsLabel
            // 
            this.itemBindsLabel.AutoSize = true;
            this.itemBindsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemBindsLabel.Location = new System.Drawing.Point(412, 98);
            this.itemBindsLabel.Name = "itemBindsLabel";
            this.itemBindsLabel.Size = new System.Drawing.Size(45, 18);
            this.itemBindsLabel.TabIndex = 30;
            this.itemBindsLabel.Text = "Binds";
            // 
            // itemTypeComboBox
            // 
            this.itemTypeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.itemTypeComboBox.FormattingEnabled = true;
            this.itemTypeComboBox.Items.AddRange(new object[] {
            "Consumable",
            "Potion",
            "Elixir",
            "Flask",
            "Scroll",
            "Food & Drinks",
            "Item Enhancement",
            "Bandage",
            "Other"});
            this.itemTypeComboBox.Location = new System.Drawing.Point(464, 43);
            this.itemTypeComboBox.Name = "itemTypeComboBox";
            this.itemTypeComboBox.Size = new System.Drawing.Size(121, 21);
            this.itemTypeComboBox.TabIndex = 6;
            // 
            // itemTypeLabel
            // 
            this.itemTypeLabel.AutoSize = true;
            this.itemTypeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemTypeLabel.Location = new System.Drawing.Point(417, 44);
            this.itemTypeLabel.Name = "itemTypeLabel";
            this.itemTypeLabel.Size = new System.Drawing.Size(40, 18);
            this.itemTypeLabel.TabIndex = 28;
            this.itemTypeLabel.Text = "Type";
            // 
            // itemDetailsNextButton
            // 
            this.itemDetailsNextButton.Location = new System.Drawing.Point(647, 331);
            this.itemDetailsNextButton.Name = "itemDetailsNextButton";
            this.itemDetailsNextButton.Size = new System.Drawing.Size(101, 41);
            this.itemDetailsNextButton.TabIndex = 10;
            this.itemDetailsNextButton.Text = "Next";
            this.itemDetailsNextButton.UseVisualStyleBackColor = true;
            this.itemDetailsNextButton.Click += new System.EventHandler(this.itemDetailsNextButton_Click);
            // 
            // itemEntryTextBox
            // 
            this.itemEntryTextBox.Location = new System.Drawing.Point(131, 243);
            this.itemEntryTextBox.Name = "itemEntryTextBox";
            this.itemEntryTextBox.Size = new System.Drawing.Size(73, 20);
            this.itemEntryTextBox.TabIndex = 5;
            // 
            // itemEntryidLabel
            // 
            this.itemEntryidLabel.AutoSize = true;
            this.itemEntryidLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemEntryidLabel.Location = new System.Drawing.Point(53, 242);
            this.itemEntryidLabel.Name = "itemEntryidLabel";
            this.itemEntryidLabel.Size = new System.Drawing.Size(70, 18);
            this.itemEntryidLabel.TabIndex = 25;
            this.itemEntryidLabel.Text = "* Entry ID";
            // 
            // itemDisplayidTextBox
            // 
            this.itemDisplayidTextBox.Location = new System.Drawing.Point(131, 198);
            this.itemDisplayidTextBox.Name = "itemDisplayidTextBox";
            this.itemDisplayidTextBox.Size = new System.Drawing.Size(73, 20);
            this.itemDisplayidTextBox.TabIndex = 4;
            // 
            // itemDisplayidLabel
            // 
            this.itemDisplayidLabel.AutoSize = true;
            this.itemDisplayidLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemDisplayidLabel.Location = new System.Drawing.Point(39, 197);
            this.itemDisplayidLabel.Name = "itemDisplayidLabel";
            this.itemDisplayidLabel.Size = new System.Drawing.Size(84, 18);
            this.itemDisplayidLabel.TabIndex = 23;
            this.itemDisplayidLabel.Text = "* Display ID";
            // 
            // itemQualityComboBox
            // 
            this.itemQualityComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.itemQualityComboBox.FormattingEnabled = true;
            this.itemQualityComboBox.Items.AddRange(new object[] {
            "Poor",
            "Common",
            "Uncommon",
            "Rare",
            "Epic",
            "Legendary",
            "Artifact"});
            this.itemQualityComboBox.Location = new System.Drawing.Point(131, 149);
            this.itemQualityComboBox.Name = "itemQualityComboBox";
            this.itemQualityComboBox.Size = new System.Drawing.Size(98, 21);
            this.itemQualityComboBox.TabIndex = 3;
            // 
            // itemQualityLabel
            // 
            this.itemQualityLabel.AutoSize = true;
            this.itemQualityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemQualityLabel.Location = new System.Drawing.Point(72, 148);
            this.itemQualityLabel.Name = "itemQualityLabel";
            this.itemQualityLabel.Size = new System.Drawing.Size(53, 18);
            this.itemQualityLabel.TabIndex = 4;
            this.itemQualityLabel.Text = "Quality";
            // 
            // itemQuoteTextBox
            // 
            this.itemQuoteTextBox.Location = new System.Drawing.Point(131, 99);
            this.itemQuoteTextBox.Name = "itemQuoteTextBox";
            this.itemQuoteTextBox.Size = new System.Drawing.Size(149, 20);
            this.itemQuoteTextBox.TabIndex = 2;
            // 
            // itemQuoteLabel
            // 
            this.itemQuoteLabel.AutoSize = true;
            this.itemQuoteLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemQuoteLabel.Location = new System.Drawing.Point(76, 101);
            this.itemQuoteLabel.Name = "itemQuoteLabel";
            this.itemQuoteLabel.Size = new System.Drawing.Size(49, 18);
            this.itemQuoteLabel.TabIndex = 2;
            this.itemQuoteLabel.Text = "Quote";
            // 
            // itemNameTextBox
            // 
            this.itemNameTextBox.Location = new System.Drawing.Point(131, 45);
            this.itemNameTextBox.Name = "itemNameTextBox";
            this.itemNameTextBox.Size = new System.Drawing.Size(149, 20);
            this.itemNameTextBox.TabIndex = 1;
            // 
            // itemNameLabel
            // 
            this.itemNameLabel.AutoSize = true;
            this.itemNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemNameLabel.Location = new System.Drawing.Point(65, 47);
            this.itemNameLabel.Name = "itemNameLabel";
            this.itemNameLabel.Size = new System.Drawing.Size(58, 18);
            this.itemNameLabel.TabIndex = 0;
            this.itemNameLabel.Text = "* Name";
            // 
            // itemRequirementsTabPage
            // 
            this.itemRequirementsTabPage.Controls.Add(this.label60);
            this.itemRequirementsTabPage.Controls.Add(this.itemsDraeneiCheckBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemsBloodElfCheckBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemsTrollCheckBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemsTaurenCheckBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemsGnomeCheckBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemsUndeadCheckBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemsNightElfCheckBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemsDwarfCheckBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemsOrcCheckBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemsHumanCheckBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemsAllRaces);
            this.itemRequirementsTabPage.Controls.Add(this.itemsDeathKnightCheckBox);
            this.itemRequirementsTabPage.Controls.Add(this.label61);
            this.itemRequirementsTabPage.Controls.Add(this.itemsWarlockCheckBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemsMageCheckBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemsShamanCheckBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemsDruidCheckBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemsPriestCheckBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemsRogueCheckBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemsHunterCheckBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemsPaladinCheckBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemsWarriorCheckBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemsAllClasses);
            this.itemRequirementsTabPage.Controls.Add(this.itemsAllowableClassesLabel);
            this.itemRequirementsTabPage.Controls.Add(this.itemsMaxTextBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemsMaxLabel);
            this.itemRequirementsTabPage.Controls.Add(this.itemSkillLevelTextBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemSkillLevelLabel);
            this.itemRequirementsTabPage.Controls.Add(this.itemSkillProfessionComboBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemskillProfressionLabel);
            this.itemRequirementsTabPage.Controls.Add(this.itemRequiredLevelTextBox);
            this.itemRequirementsTabPage.Controls.Add(this.itemRequiredLevelLabel);
            this.itemRequirementsTabPage.Controls.Add(this.itemRequirementsNextButton);
            this.itemRequirementsTabPage.Location = new System.Drawing.Point(4, 22);
            this.itemRequirementsTabPage.Name = "itemRequirementsTabPage";
            this.itemRequirementsTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.itemRequirementsTabPage.Size = new System.Drawing.Size(756, 380);
            this.itemRequirementsTabPage.TabIndex = 1;
            this.itemRequirementsTabPage.Text = "Requirements";
            this.itemRequirementsTabPage.UseVisualStyleBackColor = true;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(39, 343);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(90, 18);
            this.label60.TabIndex = 64;
            this.label60.Text = "* = Required";
            // 
            // itemsDraeneiCheckBox
            // 
            this.itemsDraeneiCheckBox.AutoSize = true;
            this.itemsDraeneiCheckBox.Location = new System.Drawing.Point(514, 346);
            this.itemsDraeneiCheckBox.Name = "itemsDraeneiCheckBox";
            this.itemsDraeneiCheckBox.Size = new System.Drawing.Size(63, 17);
            this.itemsDraeneiCheckBox.TabIndex = 63;
            this.itemsDraeneiCheckBox.Text = "Draenei";
            this.itemsDraeneiCheckBox.UseVisualStyleBackColor = true;
            // 
            // itemsBloodElfCheckBox
            // 
            this.itemsBloodElfCheckBox.AutoSize = true;
            this.itemsBloodElfCheckBox.Location = new System.Drawing.Point(579, 317);
            this.itemsBloodElfCheckBox.Name = "itemsBloodElfCheckBox";
            this.itemsBloodElfCheckBox.Size = new System.Drawing.Size(68, 17);
            this.itemsBloodElfCheckBox.TabIndex = 62;
            this.itemsBloodElfCheckBox.Text = "Blood Elf";
            this.itemsBloodElfCheckBox.UseVisualStyleBackColor = true;
            // 
            // itemsTrollCheckBox
            // 
            this.itemsTrollCheckBox.AutoSize = true;
            this.itemsTrollCheckBox.Location = new System.Drawing.Point(514, 317);
            this.itemsTrollCheckBox.Name = "itemsTrollCheckBox";
            this.itemsTrollCheckBox.Size = new System.Drawing.Size(46, 17);
            this.itemsTrollCheckBox.TabIndex = 61;
            this.itemsTrollCheckBox.Text = "Troll";
            this.itemsTrollCheckBox.UseVisualStyleBackColor = true;
            // 
            // itemsTaurenCheckBox
            // 
            this.itemsTaurenCheckBox.AutoSize = true;
            this.itemsTaurenCheckBox.Location = new System.Drawing.Point(579, 286);
            this.itemsTaurenCheckBox.Name = "itemsTaurenCheckBox";
            this.itemsTaurenCheckBox.Size = new System.Drawing.Size(60, 17);
            this.itemsTaurenCheckBox.TabIndex = 60;
            this.itemsTaurenCheckBox.Text = "Tauren";
            this.itemsTaurenCheckBox.UseVisualStyleBackColor = true;
            // 
            // itemsGnomeCheckBox
            // 
            this.itemsGnomeCheckBox.AutoSize = true;
            this.itemsGnomeCheckBox.Location = new System.Drawing.Point(429, 317);
            this.itemsGnomeCheckBox.Name = "itemsGnomeCheckBox";
            this.itemsGnomeCheckBox.Size = new System.Drawing.Size(60, 17);
            this.itemsGnomeCheckBox.TabIndex = 59;
            this.itemsGnomeCheckBox.Text = "Gnome";
            this.itemsGnomeCheckBox.UseVisualStyleBackColor = true;
            // 
            // itemsUndeadCheckBox
            // 
            this.itemsUndeadCheckBox.AutoSize = true;
            this.itemsUndeadCheckBox.Location = new System.Drawing.Point(514, 286);
            this.itemsUndeadCheckBox.Name = "itemsUndeadCheckBox";
            this.itemsUndeadCheckBox.Size = new System.Drawing.Size(64, 17);
            this.itemsUndeadCheckBox.TabIndex = 57;
            this.itemsUndeadCheckBox.Text = "Undead";
            this.itemsUndeadCheckBox.UseVisualStyleBackColor = true;
            // 
            // itemsNightElfCheckBox
            // 
            this.itemsNightElfCheckBox.AutoSize = true;
            this.itemsNightElfCheckBox.Location = new System.Drawing.Point(429, 286);
            this.itemsNightElfCheckBox.Name = "itemsNightElfCheckBox";
            this.itemsNightElfCheckBox.Size = new System.Drawing.Size(66, 17);
            this.itemsNightElfCheckBox.TabIndex = 56;
            this.itemsNightElfCheckBox.Text = "Night Elf";
            this.itemsNightElfCheckBox.UseVisualStyleBackColor = true;
            // 
            // itemsDwarfCheckBox
            // 
            this.itemsDwarfCheckBox.AutoSize = true;
            this.itemsDwarfCheckBox.Location = new System.Drawing.Point(581, 254);
            this.itemsDwarfCheckBox.Name = "itemsDwarfCheckBox";
            this.itemsDwarfCheckBox.Size = new System.Drawing.Size(54, 17);
            this.itemsDwarfCheckBox.TabIndex = 55;
            this.itemsDwarfCheckBox.Text = "Dwarf";
            this.itemsDwarfCheckBox.UseVisualStyleBackColor = true;
            // 
            // itemsOrcCheckBox
            // 
            this.itemsOrcCheckBox.AutoSize = true;
            this.itemsOrcCheckBox.Location = new System.Drawing.Point(514, 254);
            this.itemsOrcCheckBox.Name = "itemsOrcCheckBox";
            this.itemsOrcCheckBox.Size = new System.Drawing.Size(43, 17);
            this.itemsOrcCheckBox.TabIndex = 54;
            this.itemsOrcCheckBox.Text = "Orc";
            this.itemsOrcCheckBox.UseVisualStyleBackColor = true;
            // 
            // itemsHumanCheckBox
            // 
            this.itemsHumanCheckBox.AutoSize = true;
            this.itemsHumanCheckBox.Location = new System.Drawing.Point(429, 254);
            this.itemsHumanCheckBox.Name = "itemsHumanCheckBox";
            this.itemsHumanCheckBox.Size = new System.Drawing.Size(60, 17);
            this.itemsHumanCheckBox.TabIndex = 53;
            this.itemsHumanCheckBox.Text = "Human";
            this.itemsHumanCheckBox.UseVisualStyleBackColor = true;
            // 
            // itemsAllRaces
            // 
            this.itemsAllRaces.AutoSize = true;
            this.itemsAllRaces.Location = new System.Drawing.Point(514, 228);
            this.itemsAllRaces.Name = "itemsAllRaces";
            this.itemsAllRaces.Size = new System.Drawing.Size(37, 17);
            this.itemsAllRaces.TabIndex = 52;
            this.itemsAllRaces.Text = "All";
            this.itemsAllRaces.UseVisualStyleBackColor = true;
            // 
            // itemsDeathKnightCheckBox
            // 
            this.itemsDeathKnightCheckBox.AutoSize = true;
            this.itemsDeathKnightCheckBox.Location = new System.Drawing.Point(495, 171);
            this.itemsDeathKnightCheckBox.Name = "itemsDeathKnightCheckBox";
            this.itemsDeathKnightCheckBox.Size = new System.Drawing.Size(88, 17);
            this.itemsDeathKnightCheckBox.TabIndex = 51;
            this.itemsDeathKnightCheckBox.Text = "Death Knight";
            this.itemsDeathKnightCheckBox.UseVisualStyleBackColor = true;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(477, 197);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(109, 18);
            this.label61.TabIndex = 50;
            this.label61.Text = "Allowable Race";
            // 
            // itemsWarlockCheckBox
            // 
            this.itemsWarlockCheckBox.AutoSize = true;
            this.itemsWarlockCheckBox.Location = new System.Drawing.Point(579, 137);
            this.itemsWarlockCheckBox.Name = "itemsWarlockCheckBox";
            this.itemsWarlockCheckBox.Size = new System.Drawing.Size(66, 17);
            this.itemsWarlockCheckBox.TabIndex = 49;
            this.itemsWarlockCheckBox.Text = "Warlock";
            this.itemsWarlockCheckBox.UseVisualStyleBackColor = true;
            // 
            // itemsMageCheckBox
            // 
            this.itemsMageCheckBox.AutoSize = true;
            this.itemsMageCheckBox.Location = new System.Drawing.Point(514, 137);
            this.itemsMageCheckBox.Name = "itemsMageCheckBox";
            this.itemsMageCheckBox.Size = new System.Drawing.Size(53, 17);
            this.itemsMageCheckBox.TabIndex = 48;
            this.itemsMageCheckBox.Text = "Mage";
            this.itemsMageCheckBox.UseVisualStyleBackColor = true;
            // 
            // itemsShamanCheckBox
            // 
            this.itemsShamanCheckBox.AutoSize = true;
            this.itemsShamanCheckBox.Location = new System.Drawing.Point(429, 137);
            this.itemsShamanCheckBox.Name = "itemsShamanCheckBox";
            this.itemsShamanCheckBox.Size = new System.Drawing.Size(65, 17);
            this.itemsShamanCheckBox.TabIndex = 47;
            this.itemsShamanCheckBox.Text = "Shaman";
            this.itemsShamanCheckBox.UseVisualStyleBackColor = true;
            // 
            // itemsDruidCheckBox
            // 
            this.itemsDruidCheckBox.AutoSize = true;
            this.itemsDruidCheckBox.Location = new System.Drawing.Point(581, 102);
            this.itemsDruidCheckBox.Name = "itemsDruidCheckBox";
            this.itemsDruidCheckBox.Size = new System.Drawing.Size(51, 17);
            this.itemsDruidCheckBox.TabIndex = 46;
            this.itemsDruidCheckBox.Text = "Druid";
            this.itemsDruidCheckBox.UseVisualStyleBackColor = true;
            // 
            // itemsPriestCheckBox
            // 
            this.itemsPriestCheckBox.AutoSize = true;
            this.itemsPriestCheckBox.Location = new System.Drawing.Point(514, 102);
            this.itemsPriestCheckBox.Name = "itemsPriestCheckBox";
            this.itemsPriestCheckBox.Size = new System.Drawing.Size(52, 17);
            this.itemsPriestCheckBox.TabIndex = 45;
            this.itemsPriestCheckBox.Text = "Priest";
            this.itemsPriestCheckBox.UseVisualStyleBackColor = true;
            // 
            // itemsRogueCheckBox
            // 
            this.itemsRogueCheckBox.AutoSize = true;
            this.itemsRogueCheckBox.Location = new System.Drawing.Point(429, 102);
            this.itemsRogueCheckBox.Name = "itemsRogueCheckBox";
            this.itemsRogueCheckBox.Size = new System.Drawing.Size(58, 17);
            this.itemsRogueCheckBox.TabIndex = 44;
            this.itemsRogueCheckBox.Text = "Rogue";
            this.itemsRogueCheckBox.UseVisualStyleBackColor = true;
            // 
            // itemsHunterCheckBox
            // 
            this.itemsHunterCheckBox.AutoSize = true;
            this.itemsHunterCheckBox.Location = new System.Drawing.Point(581, 67);
            this.itemsHunterCheckBox.Name = "itemsHunterCheckBox";
            this.itemsHunterCheckBox.Size = new System.Drawing.Size(58, 17);
            this.itemsHunterCheckBox.TabIndex = 43;
            this.itemsHunterCheckBox.Text = "Hunter";
            this.itemsHunterCheckBox.UseVisualStyleBackColor = true;
            // 
            // itemsPaladinCheckBox
            // 
            this.itemsPaladinCheckBox.AutoSize = true;
            this.itemsPaladinCheckBox.Location = new System.Drawing.Point(514, 67);
            this.itemsPaladinCheckBox.Name = "itemsPaladinCheckBox";
            this.itemsPaladinCheckBox.Size = new System.Drawing.Size(61, 17);
            this.itemsPaladinCheckBox.TabIndex = 42;
            this.itemsPaladinCheckBox.Text = "Paladin";
            this.itemsPaladinCheckBox.UseVisualStyleBackColor = true;
            // 
            // itemsWarriorCheckBox
            // 
            this.itemsWarriorCheckBox.AutoSize = true;
            this.itemsWarriorCheckBox.Location = new System.Drawing.Point(429, 67);
            this.itemsWarriorCheckBox.Name = "itemsWarriorCheckBox";
            this.itemsWarriorCheckBox.Size = new System.Drawing.Size(60, 17);
            this.itemsWarriorCheckBox.TabIndex = 41;
            this.itemsWarriorCheckBox.Text = "Warrior";
            this.itemsWarriorCheckBox.UseVisualStyleBackColor = true;
            // 
            // itemsAllClasses
            // 
            this.itemsAllClasses.AutoSize = true;
            this.itemsAllClasses.Location = new System.Drawing.Point(514, 38);
            this.itemsAllClasses.Name = "itemsAllClasses";
            this.itemsAllClasses.Size = new System.Drawing.Size(37, 17);
            this.itemsAllClasses.TabIndex = 40;
            this.itemsAllClasses.Text = "All";
            this.itemsAllClasses.UseVisualStyleBackColor = true;
            // 
            // itemsAllowableClassesLabel
            // 
            this.itemsAllowableClassesLabel.AutoSize = true;
            this.itemsAllowableClassesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemsAllowableClassesLabel.Location = new System.Drawing.Point(477, 7);
            this.itemsAllowableClassesLabel.Name = "itemsAllowableClassesLabel";
            this.itemsAllowableClassesLabel.Size = new System.Drawing.Size(112, 18);
            this.itemsAllowableClassesLabel.TabIndex = 39;
            this.itemsAllowableClassesLabel.Text = "Allowable Class";
            // 
            // itemsMaxTextBox
            // 
            this.itemsMaxTextBox.Location = new System.Drawing.Point(204, 239);
            this.itemsMaxTextBox.Name = "itemsMaxTextBox";
            this.itemsMaxTextBox.Size = new System.Drawing.Size(59, 20);
            this.itemsMaxTextBox.TabIndex = 38;
            this.itemsMaxTextBox.Text = "0";
            // 
            // itemsMaxLabel
            // 
            this.itemsMaxLabel.AutoSize = true;
            this.itemsMaxLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemsMaxLabel.Location = new System.Drawing.Point(39, 239);
            this.itemsMaxLabel.Name = "itemsMaxLabel";
            this.itemsMaxLabel.Size = new System.Drawing.Size(158, 18);
            this.itemsMaxLabel.TabIndex = 37;
            this.itemsMaxLabel.Text = "* Max Number Allowed";
            // 
            // itemSkillLevelTextBox
            // 
            this.itemSkillLevelTextBox.Location = new System.Drawing.Point(204, 197);
            this.itemSkillLevelTextBox.Name = "itemSkillLevelTextBox";
            this.itemSkillLevelTextBox.Size = new System.Drawing.Size(51, 20);
            this.itemSkillLevelTextBox.TabIndex = 36;
            this.itemSkillLevelTextBox.Text = "0";
            // 
            // itemSkillLevelLabel
            // 
            this.itemSkillLevelLabel.AutoSize = true;
            this.itemSkillLevelLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemSkillLevelLabel.Location = new System.Drawing.Point(114, 196);
            this.itemSkillLevelLabel.Name = "itemSkillLevelLabel";
            this.itemSkillLevelLabel.Size = new System.Drawing.Size(83, 18);
            this.itemSkillLevelLabel.TabIndex = 35;
            this.itemSkillLevelLabel.Text = "* Skill Level";
            // 
            // itemSkillProfessionComboBox
            // 
            this.itemSkillProfessionComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.itemSkillProfessionComboBox.FormattingEnabled = true;
            this.itemSkillProfessionComboBox.Items.AddRange(new object[] {
            "None",
            "First Aid",
            "Blacksmithing",
            "Leatherworking",
            "Alchemy",
            "Herbalism",
            "Cooking",
            "Mining",
            "Tailoring",
            "Engineering",
            "Enchanting",
            "Fishing",
            "Skinning",
            "Jewelcrafting",
            "Inscription",
            "Swords",
            "Axes",
            "Guns",
            "Maces",
            "Two Handed Swords",
            "Defense",
            "Staves",
            "Two Handed Maces",
            "Unarmed",
            "Two Handed Axes",
            "Daggers",
            "Thrown",
            "Crossbows",
            "Wands",
            "Polearms",
            "Fist",
            "Riding"});
            this.itemSkillProfessionComboBox.Location = new System.Drawing.Point(204, 148);
            this.itemSkillProfessionComboBox.Name = "itemSkillProfessionComboBox";
            this.itemSkillProfessionComboBox.Size = new System.Drawing.Size(136, 21);
            this.itemSkillProfessionComboBox.TabIndex = 34;
            // 
            // itemskillProfressionLabel
            // 
            this.itemskillProfressionLabel.AutoSize = true;
            this.itemskillProfressionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemskillProfressionLabel.Location = new System.Drawing.Point(86, 148);
            this.itemskillProfressionLabel.Name = "itemskillProfressionLabel";
            this.itemskillProfressionLabel.Size = new System.Drawing.Size(111, 18);
            this.itemskillProfressionLabel.TabIndex = 33;
            this.itemskillProfressionLabel.Text = "Skill/Profession";
            // 
            // itemRequiredLevelTextBox
            // 
            this.itemRequiredLevelTextBox.Location = new System.Drawing.Point(204, 102);
            this.itemRequiredLevelTextBox.Name = "itemRequiredLevelTextBox";
            this.itemRequiredLevelTextBox.Size = new System.Drawing.Size(43, 20);
            this.itemRequiredLevelTextBox.TabIndex = 32;
            this.itemRequiredLevelTextBox.Text = "0";
            // 
            // itemRequiredLevelLabel
            // 
            this.itemRequiredLevelLabel.AutoSize = true;
            this.itemRequiredLevelLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemRequiredLevelLabel.Location = new System.Drawing.Point(82, 99);
            this.itemRequiredLevelLabel.Name = "itemRequiredLevelLabel";
            this.itemRequiredLevelLabel.Size = new System.Drawing.Size(115, 18);
            this.itemRequiredLevelLabel.TabIndex = 29;
            this.itemRequiredLevelLabel.Text = "* Required Level";
            // 
            // itemRequirementsNextButton
            // 
            this.itemRequirementsNextButton.Location = new System.Drawing.Point(653, 334);
            this.itemRequirementsNextButton.Name = "itemRequirementsNextButton";
            this.itemRequirementsNextButton.Size = new System.Drawing.Size(95, 38);
            this.itemRequirementsNextButton.TabIndex = 28;
            this.itemRequirementsNextButton.Text = "Next";
            this.itemRequirementsNextButton.UseVisualStyleBackColor = true;
            this.itemRequirementsNextButton.Click += new System.EventHandler(this.itemRequirementsNextButton_Click);
            // 
            // itemPriceTabPage
            // 
            this.itemPriceTabPage.Controls.Add(this.itemsSellCopperNumericUpDown);
            this.itemPriceTabPage.Controls.Add(this.itemsSellSilverNumericUpDown);
            this.itemPriceTabPage.Controls.Add(this.itemsBuyCopperNumericUpDown);
            this.itemPriceTabPage.Controls.Add(this.itemsBuySilverNumericUpDown);
            this.itemPriceTabPage.Controls.Add(this.itemsPriceNextButton);
            this.itemPriceTabPage.Controls.Add(this.itemsSellCopperLabel);
            this.itemPriceTabPage.Controls.Add(this.itemsSellSilverLabel);
            this.itemPriceTabPage.Controls.Add(this.itemsSellGoldLabel);
            this.itemPriceTabPage.Controls.Add(this.itemsSellGoldTextBox);
            this.itemPriceTabPage.Controls.Add(this.itemsBuyCopperLabel);
            this.itemPriceTabPage.Controls.Add(this.itemsBuySilverLabel);
            this.itemPriceTabPage.Controls.Add(this.itemsBuyGoldLabel);
            this.itemPriceTabPage.Controls.Add(this.itemsSellPriceLabel);
            this.itemPriceTabPage.Controls.Add(this.itemsBuyGoldTextBox);
            this.itemPriceTabPage.Controls.Add(this.itemsBuyPriceLabel);
            this.itemPriceTabPage.Location = new System.Drawing.Point(4, 22);
            this.itemPriceTabPage.Name = "itemPriceTabPage";
            this.itemPriceTabPage.Size = new System.Drawing.Size(756, 380);
            this.itemPriceTabPage.TabIndex = 2;
            this.itemPriceTabPage.Text = "Price";
            this.itemPriceTabPage.UseVisualStyleBackColor = true;
            // 
            // itemsSellCopperNumericUpDown
            // 
            this.itemsSellCopperNumericUpDown.Location = new System.Drawing.Point(506, 196);
            this.itemsSellCopperNumericUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.itemsSellCopperNumericUpDown.Name = "itemsSellCopperNumericUpDown";
            this.itemsSellCopperNumericUpDown.Size = new System.Drawing.Size(45, 20);
            this.itemsSellCopperNumericUpDown.TabIndex = 49;
            // 
            // itemsSellSilverNumericUpDown
            // 
            this.itemsSellSilverNumericUpDown.Location = new System.Drawing.Point(370, 196);
            this.itemsSellSilverNumericUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.itemsSellSilverNumericUpDown.Name = "itemsSellSilverNumericUpDown";
            this.itemsSellSilverNumericUpDown.Size = new System.Drawing.Size(45, 20);
            this.itemsSellSilverNumericUpDown.TabIndex = 48;
            // 
            // itemsBuyCopperNumericUpDown
            // 
            this.itemsBuyCopperNumericUpDown.Location = new System.Drawing.Point(506, 132);
            this.itemsBuyCopperNumericUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.itemsBuyCopperNumericUpDown.Name = "itemsBuyCopperNumericUpDown";
            this.itemsBuyCopperNumericUpDown.Size = new System.Drawing.Size(45, 20);
            this.itemsBuyCopperNumericUpDown.TabIndex = 47;
            // 
            // itemsBuySilverNumericUpDown
            // 
            this.itemsBuySilverNumericUpDown.Location = new System.Drawing.Point(370, 133);
            this.itemsBuySilverNumericUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.itemsBuySilverNumericUpDown.Name = "itemsBuySilverNumericUpDown";
            this.itemsBuySilverNumericUpDown.Size = new System.Drawing.Size(45, 20);
            this.itemsBuySilverNumericUpDown.TabIndex = 46;
            // 
            // itemsPriceNextButton
            // 
            this.itemsPriceNextButton.Location = new System.Drawing.Point(653, 334);
            this.itemsPriceNextButton.Name = "itemsPriceNextButton";
            this.itemsPriceNextButton.Size = new System.Drawing.Size(95, 38);
            this.itemsPriceNextButton.TabIndex = 45;
            this.itemsPriceNextButton.Text = "Finish";
            this.itemsPriceNextButton.UseVisualStyleBackColor = true;
            this.itemsPriceNextButton.Click += new System.EventHandler(this.itemsPriceNextButton_Click);
            // 
            // itemsSellCopperLabel
            // 
            this.itemsSellCopperLabel.AutoSize = true;
            this.itemsSellCopperLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemsSellCopperLabel.Location = new System.Drawing.Point(557, 194);
            this.itemsSellCopperLabel.Name = "itemsSellCopperLabel";
            this.itemsSellCopperLabel.Size = new System.Drawing.Size(57, 18);
            this.itemsSellCopperLabel.TabIndex = 44;
            this.itemsSellCopperLabel.Text = "Copper";
            // 
            // itemsSellSilverLabel
            // 
            this.itemsSellSilverLabel.AutoSize = true;
            this.itemsSellSilverLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemsSellSilverLabel.Location = new System.Drawing.Point(421, 194);
            this.itemsSellSilverLabel.Name = "itemsSellSilverLabel";
            this.itemsSellSilverLabel.Size = new System.Drawing.Size(44, 18);
            this.itemsSellSilverLabel.TabIndex = 42;
            this.itemsSellSilverLabel.Text = "Silver";
            // 
            // itemsSellGoldLabel
            // 
            this.itemsSellGoldLabel.AutoSize = true;
            this.itemsSellGoldLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemsSellGoldLabel.Location = new System.Drawing.Point(298, 194);
            this.itemsSellGoldLabel.Name = "itemsSellGoldLabel";
            this.itemsSellGoldLabel.Size = new System.Drawing.Size(40, 18);
            this.itemsSellGoldLabel.TabIndex = 40;
            this.itemsSellGoldLabel.Text = "Gold";
            // 
            // itemsSellGoldTextBox
            // 
            this.itemsSellGoldTextBox.Location = new System.Drawing.Point(241, 192);
            this.itemsSellGoldTextBox.Name = "itemsSellGoldTextBox";
            this.itemsSellGoldTextBox.Size = new System.Drawing.Size(41, 20);
            this.itemsSellGoldTextBox.TabIndex = 39;
            this.itemsSellGoldTextBox.Text = "0";
            // 
            // itemsBuyCopperLabel
            // 
            this.itemsBuyCopperLabel.AutoSize = true;
            this.itemsBuyCopperLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemsBuyCopperLabel.Location = new System.Drawing.Point(557, 134);
            this.itemsBuyCopperLabel.Name = "itemsBuyCopperLabel";
            this.itemsBuyCopperLabel.Size = new System.Drawing.Size(57, 18);
            this.itemsBuyCopperLabel.TabIndex = 38;
            this.itemsBuyCopperLabel.Text = "Copper";
            // 
            // itemsBuySilverLabel
            // 
            this.itemsBuySilverLabel.AutoSize = true;
            this.itemsBuySilverLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemsBuySilverLabel.Location = new System.Drawing.Point(421, 134);
            this.itemsBuySilverLabel.Name = "itemsBuySilverLabel";
            this.itemsBuySilverLabel.Size = new System.Drawing.Size(44, 18);
            this.itemsBuySilverLabel.TabIndex = 36;
            this.itemsBuySilverLabel.Text = "Silver";
            // 
            // itemsBuyGoldLabel
            // 
            this.itemsBuyGoldLabel.AutoSize = true;
            this.itemsBuyGoldLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemsBuyGoldLabel.Location = new System.Drawing.Point(298, 134);
            this.itemsBuyGoldLabel.Name = "itemsBuyGoldLabel";
            this.itemsBuyGoldLabel.Size = new System.Drawing.Size(40, 18);
            this.itemsBuyGoldLabel.TabIndex = 34;
            this.itemsBuyGoldLabel.Text = "Gold";
            // 
            // itemsSellPriceLabel
            // 
            this.itemsSellPriceLabel.AutoSize = true;
            this.itemsSellPriceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemsSellPriceLabel.Location = new System.Drawing.Point(117, 194);
            this.itemsSellPriceLabel.Name = "itemsSellPriceLabel";
            this.itemsSellPriceLabel.Size = new System.Drawing.Size(70, 18);
            this.itemsSellPriceLabel.TabIndex = 32;
            this.itemsSellPriceLabel.Text = "Sell Price";
            // 
            // itemsBuyGoldTextBox
            // 
            this.itemsBuyGoldTextBox.Location = new System.Drawing.Point(241, 132);
            this.itemsBuyGoldTextBox.Name = "itemsBuyGoldTextBox";
            this.itemsBuyGoldTextBox.Size = new System.Drawing.Size(41, 20);
            this.itemsBuyGoldTextBox.TabIndex = 31;
            this.itemsBuyGoldTextBox.Text = "0";
            // 
            // itemsBuyPriceLabel
            // 
            this.itemsBuyPriceLabel.AutoSize = true;
            this.itemsBuyPriceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemsBuyPriceLabel.Location = new System.Drawing.Point(117, 132);
            this.itemsBuyPriceLabel.Name = "itemsBuyPriceLabel";
            this.itemsBuyPriceLabel.Size = new System.Drawing.Size(71, 18);
            this.itemsBuyPriceLabel.TabIndex = 30;
            this.itemsBuyPriceLabel.Text = "Buy Price";
            // 
            // itemFinishTabPage
            // 
            this.itemFinishTabPage.Controls.Add(this.itemsSaveToSQLButton);
            this.itemFinishTabPage.Controls.Add(this.itemsSaveToDBButton);
            this.itemFinishTabPage.Controls.Add(this.itemsStartOverButton);
            this.itemFinishTabPage.Location = new System.Drawing.Point(4, 22);
            this.itemFinishTabPage.Name = "itemFinishTabPage";
            this.itemFinishTabPage.Size = new System.Drawing.Size(756, 380);
            this.itemFinishTabPage.TabIndex = 3;
            this.itemFinishTabPage.Text = "Finish";
            this.itemFinishTabPage.UseVisualStyleBackColor = true;
            // 
            // itemsSaveToSQLButton
            // 
            this.itemsSaveToSQLButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemsSaveToSQLButton.Location = new System.Drawing.Point(285, 240);
            this.itemsSaveToSQLButton.Name = "itemsSaveToSQLButton";
            this.itemsSaveToSQLButton.Size = new System.Drawing.Size(208, 74);
            this.itemsSaveToSQLButton.TabIndex = 4;
            this.itemsSaveToSQLButton.Text = "Save To SQL File";
            this.itemsSaveToSQLButton.UseVisualStyleBackColor = true;
            this.itemsSaveToSQLButton.Click += new System.EventHandler(this.itemsSaveToSQLButton_Click);
            // 
            // itemsSaveToDBButton
            // 
            this.itemsSaveToDBButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemsSaveToDBButton.Location = new System.Drawing.Point(457, 104);
            this.itemsSaveToDBButton.Name = "itemsSaveToDBButton";
            this.itemsSaveToDBButton.Size = new System.Drawing.Size(208, 74);
            this.itemsSaveToDBButton.TabIndex = 3;
            this.itemsSaveToDBButton.Text = "Save To Database";
            this.itemsSaveToDBButton.UseVisualStyleBackColor = true;
            this.itemsSaveToDBButton.Click += new System.EventHandler(this.itemsSaveToDBButton_Click);
            // 
            // itemsStartOverButton
            // 
            this.itemsStartOverButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemsStartOverButton.Location = new System.Drawing.Point(99, 104);
            this.itemsStartOverButton.Name = "itemsStartOverButton";
            this.itemsStartOverButton.Size = new System.Drawing.Size(208, 74);
            this.itemsStartOverButton.TabIndex = 2;
            this.itemsStartOverButton.Text = "Start Over";
            this.itemsStartOverButton.UseVisualStyleBackColor = true;
            this.itemsStartOverButton.Click += new System.EventHandler(this.itemsStartOverButton_Click);
            // 
            // weaponsTabPage
            // 
            this.weaponsTabPage.Controls.Add(this.weaponsTabControl);
            this.weaponsTabPage.Location = new System.Drawing.Point(4, 22);
            this.weaponsTabPage.Name = "weaponsTabPage";
            this.weaponsTabPage.Size = new System.Drawing.Size(760, 402);
            this.weaponsTabPage.TabIndex = 2;
            this.weaponsTabPage.Text = "Weapons";
            this.weaponsTabPage.UseVisualStyleBackColor = true;
            // 
            // weaponsTabControl
            // 
            this.weaponsTabControl.Controls.Add(this.weaponDetailsTabPage);
            this.weaponsTabControl.Controls.Add(this.weaponStatsTabPage);
            this.weaponsTabControl.Controls.Add(this.weaponRequirementsTabPage);
            this.weaponsTabControl.Controls.Add(this.weaponDamageTabPage);
            this.weaponsTabControl.Controls.Add(this.weaponResistsTabPage);
            this.weaponsTabControl.Controls.Add(this.weaponSocketsTabPage);
            this.weaponsTabControl.Controls.Add(this.weaponPriceTabPage);
            this.weaponsTabControl.Controls.Add(this.weaponFinishTabPage);
            this.weaponsTabControl.Location = new System.Drawing.Point(0, 0);
            this.weaponsTabControl.Name = "weaponsTabControl";
            this.weaponsTabControl.SelectedIndex = 0;
            this.weaponsTabControl.Size = new System.Drawing.Size(764, 402);
            this.weaponsTabControl.TabIndex = 0;
            // 
            // weaponDetailsTabPage
            // 
            this.weaponDetailsTabPage.Controls.Add(this.weaponBindComboBox);
            this.weaponDetailsTabPage.Controls.Add(this.weaponBindLabel);
            this.weaponDetailsTabPage.Controls.Add(this.weaponDurabilityTextBox);
            this.weaponDetailsTabPage.Controls.Add(this.weaponDurabilityLabel);
            this.weaponDetailsTabPage.Controls.Add(this.weaponTypeComboBox);
            this.weaponDetailsTabPage.Controls.Add(this.weaponTypeLabel);
            this.weaponDetailsTabPage.Controls.Add(this.weaponEquipComboBox);
            this.weaponDetailsTabPage.Controls.Add(this.weaponEquipLabel);
            this.weaponDetailsTabPage.Controls.Add(this.weaponDetailsRequiredLabel);
            this.weaponDetailsTabPage.Controls.Add(this.weaponSearchDisplayIDButton);
            this.weaponDetailsTabPage.Controls.Add(this.weaponDetailsNextButton);
            this.weaponDetailsTabPage.Controls.Add(this.weaponEntryIDTextBox);
            this.weaponDetailsTabPage.Controls.Add(this.weaponEntryIDLabel);
            this.weaponDetailsTabPage.Controls.Add(this.weaponDisplayIDTextBox);
            this.weaponDetailsTabPage.Controls.Add(this.weaponDisplayIDLabel);
            this.weaponDetailsTabPage.Controls.Add(this.weaponQualityComboBox);
            this.weaponDetailsTabPage.Controls.Add(this.weaponQualityLabel);
            this.weaponDetailsTabPage.Controls.Add(this.weaponQuoteTextBox);
            this.weaponDetailsTabPage.Controls.Add(this.weaponQuoteLabel);
            this.weaponDetailsTabPage.Controls.Add(this.weaponNameTextBox);
            this.weaponDetailsTabPage.Controls.Add(this.weaponNameLabel);
            this.weaponDetailsTabPage.Location = new System.Drawing.Point(4, 22);
            this.weaponDetailsTabPage.Name = "weaponDetailsTabPage";
            this.weaponDetailsTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.weaponDetailsTabPage.Size = new System.Drawing.Size(756, 376);
            this.weaponDetailsTabPage.TabIndex = 0;
            this.weaponDetailsTabPage.Text = "Details";
            this.weaponDetailsTabPage.UseVisualStyleBackColor = true;
            // 
            // weaponBindComboBox
            // 
            this.weaponBindComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.weaponBindComboBox.FormattingEnabled = true;
            this.weaponBindComboBox.Items.AddRange(new object[] {
            "None",
            "On Pickup",
            "On Equip",
            "On Use"});
            this.weaponBindComboBox.Location = new System.Drawing.Point(538, 223);
            this.weaponBindComboBox.Name = "weaponBindComboBox";
            this.weaponBindComboBox.Size = new System.Drawing.Size(82, 21);
            this.weaponBindComboBox.TabIndex = 78;
            // 
            // weaponBindLabel
            // 
            this.weaponBindLabel.AutoSize = true;
            this.weaponBindLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponBindLabel.Location = new System.Drawing.Point(487, 222);
            this.weaponBindLabel.Name = "weaponBindLabel";
            this.weaponBindLabel.Size = new System.Drawing.Size(45, 18);
            this.weaponBindLabel.TabIndex = 77;
            this.weaponBindLabel.Text = "Binds";
            // 
            // weaponDurabilityTextBox
            // 
            this.weaponDurabilityTextBox.Location = new System.Drawing.Point(538, 175);
            this.weaponDurabilityTextBox.Name = "weaponDurabilityTextBox";
            this.weaponDurabilityTextBox.Size = new System.Drawing.Size(73, 20);
            this.weaponDurabilityTextBox.TabIndex = 76;
            this.weaponDurabilityTextBox.Text = "0";
            // 
            // weaponDurabilityLabel
            // 
            this.weaponDurabilityLabel.AutoSize = true;
            this.weaponDurabilityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponDurabilityLabel.Location = new System.Drawing.Point(464, 174);
            this.weaponDurabilityLabel.Name = "weaponDurabilityLabel";
            this.weaponDurabilityLabel.Size = new System.Drawing.Size(68, 18);
            this.weaponDurabilityLabel.TabIndex = 75;
            this.weaponDurabilityLabel.Text = "Durability";
            // 
            // weaponTypeComboBox
            // 
            this.weaponTypeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.weaponTypeComboBox.FormattingEnabled = true;
            this.weaponTypeComboBox.Items.AddRange(new object[] {
            "1H Axe",
            "2H Axe",
            "Bow",
            "Gun",
            "1H Mace",
            "2H Mace",
            "Polearm",
            "1H Sword",
            "2H Sword",
            "Staff",
            "Fist",
            "Dagger",
            "Throwing",
            "Spear",
            "Crossbow",
            "Wand"});
            this.weaponTypeComboBox.Location = new System.Drawing.Point(538, 120);
            this.weaponTypeComboBox.Name = "weaponTypeComboBox";
            this.weaponTypeComboBox.Size = new System.Drawing.Size(98, 21);
            this.weaponTypeComboBox.TabIndex = 72;
            // 
            // weaponTypeLabel
            // 
            this.weaponTypeLabel.AutoSize = true;
            this.weaponTypeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponTypeLabel.Location = new System.Drawing.Point(492, 123);
            this.weaponTypeLabel.Name = "weaponTypeLabel";
            this.weaponTypeLabel.Size = new System.Drawing.Size(40, 18);
            this.weaponTypeLabel.TabIndex = 71;
            this.weaponTypeLabel.Text = "Type";
            // 
            // weaponEquipComboBox
            // 
            this.weaponEquipComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.weaponEquipComboBox.FormattingEnabled = true;
            this.weaponEquipComboBox.Items.AddRange(new object[] {
            "One Hand",
            "Main Hand",
            "Off Hand",
            "Two Handed",
            "Bow",
            "Thrown",
            "Crossbow",
            "Gun/Wand"});
            this.weaponEquipComboBox.Location = new System.Drawing.Point(538, 73);
            this.weaponEquipComboBox.Name = "weaponEquipComboBox";
            this.weaponEquipComboBox.Size = new System.Drawing.Size(98, 21);
            this.weaponEquipComboBox.TabIndex = 70;
            // 
            // weaponEquipLabel
            // 
            this.weaponEquipLabel.AutoSize = true;
            this.weaponEquipLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponEquipLabel.Location = new System.Drawing.Point(487, 73);
            this.weaponEquipLabel.Name = "weaponEquipLabel";
            this.weaponEquipLabel.Size = new System.Drawing.Size(45, 18);
            this.weaponEquipLabel.TabIndex = 69;
            this.weaponEquipLabel.Text = "Equip";
            // 
            // weaponDetailsRequiredLabel
            // 
            this.weaponDetailsRequiredLabel.AutoSize = true;
            this.weaponDetailsRequiredLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponDetailsRequiredLabel.Location = new System.Drawing.Point(39, 343);
            this.weaponDetailsRequiredLabel.Name = "weaponDetailsRequiredLabel";
            this.weaponDetailsRequiredLabel.Size = new System.Drawing.Size(90, 18);
            this.weaponDetailsRequiredLabel.TabIndex = 68;
            this.weaponDetailsRequiredLabel.Text = "* = Required";
            // 
            // weaponSearchDisplayIDButton
            // 
            this.weaponSearchDisplayIDButton.Location = new System.Drawing.Point(309, 342);
            this.weaponSearchDisplayIDButton.Name = "weaponSearchDisplayIDButton";
            this.weaponSearchDisplayIDButton.Size = new System.Drawing.Size(148, 23);
            this.weaponSearchDisplayIDButton.TabIndex = 66;
            this.weaponSearchDisplayIDButton.Text = "Search For Display IDs";
            this.weaponSearchDisplayIDButton.UseVisualStyleBackColor = true;
            this.weaponSearchDisplayIDButton.Click += new System.EventHandler(this.weaponSearchDisplayIDButton_Click);
            // 
            // weaponDetailsNextButton
            // 
            this.weaponDetailsNextButton.Location = new System.Drawing.Point(647, 331);
            this.weaponDetailsNextButton.Name = "weaponDetailsNextButton";
            this.weaponDetailsNextButton.Size = new System.Drawing.Size(101, 41);
            this.weaponDetailsNextButton.TabIndex = 67;
            this.weaponDetailsNextButton.Text = "Next";
            this.weaponDetailsNextButton.UseVisualStyleBackColor = true;
            this.weaponDetailsNextButton.Click += new System.EventHandler(this.weaponDetailsNextButton_Click);
            // 
            // weaponEntryIDTextBox
            // 
            this.weaponEntryIDTextBox.Location = new System.Drawing.Point(128, 246);
            this.weaponEntryIDTextBox.Name = "weaponEntryIDTextBox";
            this.weaponEntryIDTextBox.Size = new System.Drawing.Size(73, 20);
            this.weaponEntryIDTextBox.TabIndex = 33;
            // 
            // weaponEntryIDLabel
            // 
            this.weaponEntryIDLabel.AutoSize = true;
            this.weaponEntryIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponEntryIDLabel.Location = new System.Drawing.Point(50, 245);
            this.weaponEntryIDLabel.Name = "weaponEntryIDLabel";
            this.weaponEntryIDLabel.Size = new System.Drawing.Size(70, 18);
            this.weaponEntryIDLabel.TabIndex = 35;
            this.weaponEntryIDLabel.Text = "* Entry ID";
            // 
            // weaponDisplayIDTextBox
            // 
            this.weaponDisplayIDTextBox.Location = new System.Drawing.Point(128, 201);
            this.weaponDisplayIDTextBox.Name = "weaponDisplayIDTextBox";
            this.weaponDisplayIDTextBox.Size = new System.Drawing.Size(73, 20);
            this.weaponDisplayIDTextBox.TabIndex = 31;
            // 
            // weaponDisplayIDLabel
            // 
            this.weaponDisplayIDLabel.AutoSize = true;
            this.weaponDisplayIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponDisplayIDLabel.Location = new System.Drawing.Point(36, 200);
            this.weaponDisplayIDLabel.Name = "weaponDisplayIDLabel";
            this.weaponDisplayIDLabel.Size = new System.Drawing.Size(84, 18);
            this.weaponDisplayIDLabel.TabIndex = 34;
            this.weaponDisplayIDLabel.Text = "* Display ID";
            // 
            // weaponQualityComboBox
            // 
            this.weaponQualityComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.weaponQualityComboBox.FormattingEnabled = true;
            this.weaponQualityComboBox.Items.AddRange(new object[] {
            "Poor",
            "Common",
            "Uncommon",
            "Rare",
            "Epic",
            "Legendary",
            "Artifact"});
            this.weaponQualityComboBox.Location = new System.Drawing.Point(128, 152);
            this.weaponQualityComboBox.Name = "weaponQualityComboBox";
            this.weaponQualityComboBox.Size = new System.Drawing.Size(98, 21);
            this.weaponQualityComboBox.TabIndex = 30;
            // 
            // weaponQualityLabel
            // 
            this.weaponQualityLabel.AutoSize = true;
            this.weaponQualityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponQualityLabel.Location = new System.Drawing.Point(69, 151);
            this.weaponQualityLabel.Name = "weaponQualityLabel";
            this.weaponQualityLabel.Size = new System.Drawing.Size(53, 18);
            this.weaponQualityLabel.TabIndex = 32;
            this.weaponQualityLabel.Text = "Quality";
            // 
            // weaponQuoteTextBox
            // 
            this.weaponQuoteTextBox.Location = new System.Drawing.Point(128, 102);
            this.weaponQuoteTextBox.Name = "weaponQuoteTextBox";
            this.weaponQuoteTextBox.Size = new System.Drawing.Size(149, 20);
            this.weaponQuoteTextBox.TabIndex = 28;
            // 
            // weaponQuoteLabel
            // 
            this.weaponQuoteLabel.AutoSize = true;
            this.weaponQuoteLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponQuoteLabel.Location = new System.Drawing.Point(73, 104);
            this.weaponQuoteLabel.Name = "weaponQuoteLabel";
            this.weaponQuoteLabel.Size = new System.Drawing.Size(49, 18);
            this.weaponQuoteLabel.TabIndex = 29;
            this.weaponQuoteLabel.Text = "Quote";
            // 
            // weaponNameTextBox
            // 
            this.weaponNameTextBox.Location = new System.Drawing.Point(128, 48);
            this.weaponNameTextBox.Name = "weaponNameTextBox";
            this.weaponNameTextBox.Size = new System.Drawing.Size(149, 20);
            this.weaponNameTextBox.TabIndex = 27;
            // 
            // weaponNameLabel
            // 
            this.weaponNameLabel.AutoSize = true;
            this.weaponNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponNameLabel.Location = new System.Drawing.Point(62, 50);
            this.weaponNameLabel.Name = "weaponNameLabel";
            this.weaponNameLabel.Size = new System.Drawing.Size(58, 18);
            this.weaponNameLabel.TabIndex = 26;
            this.weaponNameLabel.Text = "* Name";
            // 
            // weaponStatsTabPage
            // 
            this.weaponStatsTabPage.Controls.Add(this.weaponStatsNextButton);
            this.weaponStatsTabPage.Controls.Add(this.weaponArmorStatsGroupBox);
            this.weaponStatsTabPage.Controls.Add(this.weaponStatsGroupBox);
            this.weaponStatsTabPage.Location = new System.Drawing.Point(4, 22);
            this.weaponStatsTabPage.Name = "weaponStatsTabPage";
            this.weaponStatsTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.weaponStatsTabPage.Size = new System.Drawing.Size(756, 376);
            this.weaponStatsTabPage.TabIndex = 1;
            this.weaponStatsTabPage.Text = "Stats";
            this.weaponStatsTabPage.UseVisualStyleBackColor = true;
            // 
            // weaponStatsNextButton
            // 
            this.weaponStatsNextButton.Location = new System.Drawing.Point(647, 331);
            this.weaponStatsNextButton.Name = "weaponStatsNextButton";
            this.weaponStatsNextButton.Size = new System.Drawing.Size(101, 41);
            this.weaponStatsNextButton.TabIndex = 68;
            this.weaponStatsNextButton.Text = "Next";
            this.weaponStatsNextButton.UseVisualStyleBackColor = true;
            this.weaponStatsNextButton.Click += new System.EventHandler(this.weaponStatsNextButton_Click);
            // 
            // weaponArmorStatsGroupBox
            // 
            this.weaponArmorStatsGroupBox.Controls.Add(this.weaponBlockArmorTextBox);
            this.weaponArmorStatsGroupBox.Controls.Add(this.weaponBlockArmorLabel);
            this.weaponArmorStatsGroupBox.Controls.Add(this.weaponBlockTextBox);
            this.weaponArmorStatsGroupBox.Controls.Add(this.weaponBlockLabel);
            this.weaponArmorStatsGroupBox.Location = new System.Drawing.Point(391, 92);
            this.weaponArmorStatsGroupBox.Name = "weaponArmorStatsGroupBox";
            this.weaponArmorStatsGroupBox.Size = new System.Drawing.Size(275, 168);
            this.weaponArmorStatsGroupBox.TabIndex = 40;
            this.weaponArmorStatsGroupBox.TabStop = false;
            this.weaponArmorStatsGroupBox.Text = "Armor Stats";
            // 
            // weaponBlockArmorTextBox
            // 
            this.weaponBlockArmorTextBox.Location = new System.Drawing.Point(130, 99);
            this.weaponBlockArmorTextBox.Name = "weaponBlockArmorTextBox";
            this.weaponBlockArmorTextBox.Size = new System.Drawing.Size(54, 20);
            this.weaponBlockArmorTextBox.TabIndex = 42;
            this.weaponBlockArmorTextBox.Text = "0";
            // 
            // weaponBlockArmorLabel
            // 
            this.weaponBlockArmorLabel.AutoSize = true;
            this.weaponBlockArmorLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponBlockArmorLabel.Location = new System.Drawing.Point(74, 98);
            this.weaponBlockArmorLabel.Name = "weaponBlockArmorLabel";
            this.weaponBlockArmorLabel.Size = new System.Drawing.Size(49, 18);
            this.weaponBlockArmorLabel.TabIndex = 41;
            this.weaponBlockArmorLabel.Text = "Armor";
            // 
            // weaponBlockTextBox
            // 
            this.weaponBlockTextBox.Location = new System.Drawing.Point(129, 53);
            this.weaponBlockTextBox.Name = "weaponBlockTextBox";
            this.weaponBlockTextBox.Size = new System.Drawing.Size(54, 20);
            this.weaponBlockTextBox.TabIndex = 40;
            this.weaponBlockTextBox.Text = "0";
            // 
            // weaponBlockLabel
            // 
            this.weaponBlockLabel.AutoSize = true;
            this.weaponBlockLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponBlockLabel.Location = new System.Drawing.Point(77, 52);
            this.weaponBlockLabel.Name = "weaponBlockLabel";
            this.weaponBlockLabel.Size = new System.Drawing.Size(46, 18);
            this.weaponBlockLabel.TabIndex = 39;
            this.weaponBlockLabel.Text = "Block";
            // 
            // weaponStatsGroupBox
            // 
            this.weaponStatsGroupBox.Controls.Add(this.weaponSpeedNumericUpDown);
            this.weaponStatsGroupBox.Controls.Add(this.weaponSheathLabel);
            this.weaponStatsGroupBox.Controls.Add(this.weaponSpeedLabel);
            this.weaponStatsGroupBox.Controls.Add(this.weaponSheathComboBox);
            this.weaponStatsGroupBox.Controls.Add(this.weaponAmmoTypeComboBox);
            this.weaponStatsGroupBox.Controls.Add(this.weaponAmmoTypeLabel);
            this.weaponStatsGroupBox.Location = new System.Drawing.Point(80, 92);
            this.weaponStatsGroupBox.Name = "weaponStatsGroupBox";
            this.weaponStatsGroupBox.Size = new System.Drawing.Size(275, 168);
            this.weaponStatsGroupBox.TabIndex = 39;
            this.weaponStatsGroupBox.TabStop = false;
            this.weaponStatsGroupBox.Text = "Weapon Stats";
            // 
            // weaponSpeedNumericUpDown
            // 
            this.weaponSpeedNumericUpDown.DecimalPlaces = 1;
            this.weaponSpeedNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.weaponSpeedNumericUpDown.Location = new System.Drawing.Point(128, 124);
            this.weaponSpeedNumericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.weaponSpeedNumericUpDown.Name = "weaponSpeedNumericUpDown";
            this.weaponSpeedNumericUpDown.Size = new System.Drawing.Size(48, 20);
            this.weaponSpeedNumericUpDown.TabIndex = 38;
            this.weaponSpeedNumericUpDown.Value = new decimal(new int[] {
            20,
            0,
            0,
            65536});
            // 
            // weaponSheathLabel
            // 
            this.weaponSheathLabel.AutoSize = true;
            this.weaponSheathLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponSheathLabel.Location = new System.Drawing.Point(67, 30);
            this.weaponSheathLabel.Name = "weaponSheathLabel";
            this.weaponSheathLabel.Size = new System.Drawing.Size(54, 18);
            this.weaponSheathLabel.TabIndex = 33;
            this.weaponSheathLabel.Text = "Sheath";
            // 
            // weaponSpeedLabel
            // 
            this.weaponSpeedLabel.AutoSize = true;
            this.weaponSpeedLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponSpeedLabel.Location = new System.Drawing.Point(71, 127);
            this.weaponSpeedLabel.Name = "weaponSpeedLabel";
            this.weaponSpeedLabel.Size = new System.Drawing.Size(50, 18);
            this.weaponSpeedLabel.TabIndex = 37;
            this.weaponSpeedLabel.Text = "Speed";
            // 
            // weaponSheathComboBox
            // 
            this.weaponSheathComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.weaponSheathComboBox.FormattingEnabled = true;
            this.weaponSheathComboBox.Items.AddRange(new object[] {
            "One Handed",
            "Two Handed",
            "Staff",
            "Ranged",
            "Wand"});
            this.weaponSheathComboBox.Location = new System.Drawing.Point(127, 31);
            this.weaponSheathComboBox.Name = "weaponSheathComboBox";
            this.weaponSheathComboBox.Size = new System.Drawing.Size(87, 21);
            this.weaponSheathComboBox.TabIndex = 34;
            // 
            // weaponAmmoTypeComboBox
            // 
            this.weaponAmmoTypeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.weaponAmmoTypeComboBox.FormattingEnabled = true;
            this.weaponAmmoTypeComboBox.Items.AddRange(new object[] {
            "No ammo",
            "Wands",
            "Bows",
            "Guns"});
            this.weaponAmmoTypeComboBox.Location = new System.Drawing.Point(127, 79);
            this.weaponAmmoTypeComboBox.Name = "weaponAmmoTypeComboBox";
            this.weaponAmmoTypeComboBox.Size = new System.Drawing.Size(96, 21);
            this.weaponAmmoTypeComboBox.TabIndex = 36;
            // 
            // weaponAmmoTypeLabel
            // 
            this.weaponAmmoTypeLabel.AutoSize = true;
            this.weaponAmmoTypeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponAmmoTypeLabel.Location = new System.Drawing.Point(33, 78);
            this.weaponAmmoTypeLabel.Name = "weaponAmmoTypeLabel";
            this.weaponAmmoTypeLabel.Size = new System.Drawing.Size(88, 18);
            this.weaponAmmoTypeLabel.TabIndex = 35;
            this.weaponAmmoTypeLabel.Text = "Ammo Type";
            // 
            // weaponRequirementsTabPage
            // 
            this.weaponRequirementsTabPage.Controls.Add(this.weaponStackableLabel);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponStackableTextBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponRequirementsNextButton);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponDraeneiCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponBloodElfCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponTrollCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponTaurenCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponGnomeCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponUndeadCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponNightElfCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponDwarfCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponOrcCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponHumanCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponRaceAllCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponDeathKnightCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponAllowableRaceLabel);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponWarlockCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponMageCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponShamanCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponDruidCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponPriestCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponRogueCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponHunterCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponPaladinCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponWarriorCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponClassAllCheckBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponAllowableClassLabel);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponMaxTextBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponMaxLabel);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponItemLevelTextBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponItemLevelLabel);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponRequiredLevelTextBox);
            this.weaponRequirementsTabPage.Controls.Add(this.weaponRequiredLevelLabel);
            this.weaponRequirementsTabPage.Location = new System.Drawing.Point(4, 22);
            this.weaponRequirementsTabPage.Name = "weaponRequirementsTabPage";
            this.weaponRequirementsTabPage.Size = new System.Drawing.Size(756, 376);
            this.weaponRequirementsTabPage.TabIndex = 2;
            this.weaponRequirementsTabPage.Text = "Requirements";
            this.weaponRequirementsTabPage.UseVisualStyleBackColor = true;
            // 
            // weaponStackableLabel
            // 
            this.weaponStackableLabel.AutoSize = true;
            this.weaponStackableLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponStackableLabel.Location = new System.Drawing.Point(92, 243);
            this.weaponStackableLabel.Name = "weaponStackableLabel";
            this.weaponStackableLabel.Size = new System.Drawing.Size(73, 18);
            this.weaponStackableLabel.TabIndex = 90;
            this.weaponStackableLabel.Text = "Stackable";
            // 
            // weaponStackableTextBox
            // 
            this.weaponStackableTextBox.Location = new System.Drawing.Point(172, 241);
            this.weaponStackableTextBox.Name = "weaponStackableTextBox";
            this.weaponStackableTextBox.Size = new System.Drawing.Size(45, 20);
            this.weaponStackableTextBox.TabIndex = 89;
            this.weaponStackableTextBox.Text = "0";
            // 
            // weaponRequirementsNextButton
            // 
            this.weaponRequirementsNextButton.Location = new System.Drawing.Point(647, 331);
            this.weaponRequirementsNextButton.Name = "weaponRequirementsNextButton";
            this.weaponRequirementsNextButton.Size = new System.Drawing.Size(101, 41);
            this.weaponRequirementsNextButton.TabIndex = 88;
            this.weaponRequirementsNextButton.Text = "Next";
            this.weaponRequirementsNextButton.UseVisualStyleBackColor = true;
            this.weaponRequirementsNextButton.Click += new System.EventHandler(this.weaponRequirementsNextButton_Click);
            // 
            // weaponDraeneiCheckBox
            // 
            this.weaponDraeneiCheckBox.AutoSize = true;
            this.weaponDraeneiCheckBox.Location = new System.Drawing.Point(480, 350);
            this.weaponDraeneiCheckBox.Name = "weaponDraeneiCheckBox";
            this.weaponDraeneiCheckBox.Size = new System.Drawing.Size(63, 17);
            this.weaponDraeneiCheckBox.TabIndex = 87;
            this.weaponDraeneiCheckBox.Text = "Draenei";
            this.weaponDraeneiCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponBloodElfCheckBox
            // 
            this.weaponBloodElfCheckBox.AutoSize = true;
            this.weaponBloodElfCheckBox.Location = new System.Drawing.Point(545, 321);
            this.weaponBloodElfCheckBox.Name = "weaponBloodElfCheckBox";
            this.weaponBloodElfCheckBox.Size = new System.Drawing.Size(68, 17);
            this.weaponBloodElfCheckBox.TabIndex = 86;
            this.weaponBloodElfCheckBox.Text = "Blood Elf";
            this.weaponBloodElfCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponTrollCheckBox
            // 
            this.weaponTrollCheckBox.AutoSize = true;
            this.weaponTrollCheckBox.Location = new System.Drawing.Point(480, 321);
            this.weaponTrollCheckBox.Name = "weaponTrollCheckBox";
            this.weaponTrollCheckBox.Size = new System.Drawing.Size(46, 17);
            this.weaponTrollCheckBox.TabIndex = 85;
            this.weaponTrollCheckBox.Text = "Troll";
            this.weaponTrollCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponTaurenCheckBox
            // 
            this.weaponTaurenCheckBox.AutoSize = true;
            this.weaponTaurenCheckBox.Location = new System.Drawing.Point(545, 290);
            this.weaponTaurenCheckBox.Name = "weaponTaurenCheckBox";
            this.weaponTaurenCheckBox.Size = new System.Drawing.Size(60, 17);
            this.weaponTaurenCheckBox.TabIndex = 84;
            this.weaponTaurenCheckBox.Text = "Tauren";
            this.weaponTaurenCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponGnomeCheckBox
            // 
            this.weaponGnomeCheckBox.AutoSize = true;
            this.weaponGnomeCheckBox.Location = new System.Drawing.Point(395, 321);
            this.weaponGnomeCheckBox.Name = "weaponGnomeCheckBox";
            this.weaponGnomeCheckBox.Size = new System.Drawing.Size(60, 17);
            this.weaponGnomeCheckBox.TabIndex = 83;
            this.weaponGnomeCheckBox.Text = "Gnome";
            this.weaponGnomeCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponUndeadCheckBox
            // 
            this.weaponUndeadCheckBox.AutoSize = true;
            this.weaponUndeadCheckBox.Location = new System.Drawing.Point(480, 290);
            this.weaponUndeadCheckBox.Name = "weaponUndeadCheckBox";
            this.weaponUndeadCheckBox.Size = new System.Drawing.Size(64, 17);
            this.weaponUndeadCheckBox.TabIndex = 82;
            this.weaponUndeadCheckBox.Text = "Undead";
            this.weaponUndeadCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponNightElfCheckBox
            // 
            this.weaponNightElfCheckBox.AutoSize = true;
            this.weaponNightElfCheckBox.Location = new System.Drawing.Point(395, 290);
            this.weaponNightElfCheckBox.Name = "weaponNightElfCheckBox";
            this.weaponNightElfCheckBox.Size = new System.Drawing.Size(66, 17);
            this.weaponNightElfCheckBox.TabIndex = 81;
            this.weaponNightElfCheckBox.Text = "Night Elf";
            this.weaponNightElfCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponDwarfCheckBox
            // 
            this.weaponDwarfCheckBox.AutoSize = true;
            this.weaponDwarfCheckBox.Location = new System.Drawing.Point(547, 258);
            this.weaponDwarfCheckBox.Name = "weaponDwarfCheckBox";
            this.weaponDwarfCheckBox.Size = new System.Drawing.Size(54, 17);
            this.weaponDwarfCheckBox.TabIndex = 80;
            this.weaponDwarfCheckBox.Text = "Dwarf";
            this.weaponDwarfCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponOrcCheckBox
            // 
            this.weaponOrcCheckBox.AutoSize = true;
            this.weaponOrcCheckBox.Location = new System.Drawing.Point(480, 258);
            this.weaponOrcCheckBox.Name = "weaponOrcCheckBox";
            this.weaponOrcCheckBox.Size = new System.Drawing.Size(43, 17);
            this.weaponOrcCheckBox.TabIndex = 79;
            this.weaponOrcCheckBox.Text = "Orc";
            this.weaponOrcCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponHumanCheckBox
            // 
            this.weaponHumanCheckBox.AutoSize = true;
            this.weaponHumanCheckBox.Location = new System.Drawing.Point(395, 258);
            this.weaponHumanCheckBox.Name = "weaponHumanCheckBox";
            this.weaponHumanCheckBox.Size = new System.Drawing.Size(60, 17);
            this.weaponHumanCheckBox.TabIndex = 78;
            this.weaponHumanCheckBox.Text = "Human";
            this.weaponHumanCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponRaceAllCheckBox
            // 
            this.weaponRaceAllCheckBox.AutoSize = true;
            this.weaponRaceAllCheckBox.Location = new System.Drawing.Point(480, 232);
            this.weaponRaceAllCheckBox.Name = "weaponRaceAllCheckBox";
            this.weaponRaceAllCheckBox.Size = new System.Drawing.Size(37, 17);
            this.weaponRaceAllCheckBox.TabIndex = 77;
            this.weaponRaceAllCheckBox.Text = "All";
            this.weaponRaceAllCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponDeathKnightCheckBox
            // 
            this.weaponDeathKnightCheckBox.AutoSize = true;
            this.weaponDeathKnightCheckBox.Location = new System.Drawing.Point(461, 175);
            this.weaponDeathKnightCheckBox.Name = "weaponDeathKnightCheckBox";
            this.weaponDeathKnightCheckBox.Size = new System.Drawing.Size(88, 17);
            this.weaponDeathKnightCheckBox.TabIndex = 76;
            this.weaponDeathKnightCheckBox.Text = "Death Knight";
            this.weaponDeathKnightCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponAllowableRaceLabel
            // 
            this.weaponAllowableRaceLabel.AutoSize = true;
            this.weaponAllowableRaceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponAllowableRaceLabel.Location = new System.Drawing.Point(443, 201);
            this.weaponAllowableRaceLabel.Name = "weaponAllowableRaceLabel";
            this.weaponAllowableRaceLabel.Size = new System.Drawing.Size(109, 18);
            this.weaponAllowableRaceLabel.TabIndex = 75;
            this.weaponAllowableRaceLabel.Text = "Allowable Race";
            // 
            // weaponWarlockCheckBox
            // 
            this.weaponWarlockCheckBox.AutoSize = true;
            this.weaponWarlockCheckBox.Location = new System.Drawing.Point(545, 141);
            this.weaponWarlockCheckBox.Name = "weaponWarlockCheckBox";
            this.weaponWarlockCheckBox.Size = new System.Drawing.Size(66, 17);
            this.weaponWarlockCheckBox.TabIndex = 74;
            this.weaponWarlockCheckBox.Text = "Warlock";
            this.weaponWarlockCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponMageCheckBox
            // 
            this.weaponMageCheckBox.AutoSize = true;
            this.weaponMageCheckBox.Location = new System.Drawing.Point(480, 141);
            this.weaponMageCheckBox.Name = "weaponMageCheckBox";
            this.weaponMageCheckBox.Size = new System.Drawing.Size(53, 17);
            this.weaponMageCheckBox.TabIndex = 73;
            this.weaponMageCheckBox.Text = "Mage";
            this.weaponMageCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponShamanCheckBox
            // 
            this.weaponShamanCheckBox.AutoSize = true;
            this.weaponShamanCheckBox.Location = new System.Drawing.Point(395, 141);
            this.weaponShamanCheckBox.Name = "weaponShamanCheckBox";
            this.weaponShamanCheckBox.Size = new System.Drawing.Size(65, 17);
            this.weaponShamanCheckBox.TabIndex = 72;
            this.weaponShamanCheckBox.Text = "Shaman";
            this.weaponShamanCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponDruidCheckBox
            // 
            this.weaponDruidCheckBox.AutoSize = true;
            this.weaponDruidCheckBox.Location = new System.Drawing.Point(547, 106);
            this.weaponDruidCheckBox.Name = "weaponDruidCheckBox";
            this.weaponDruidCheckBox.Size = new System.Drawing.Size(51, 17);
            this.weaponDruidCheckBox.TabIndex = 71;
            this.weaponDruidCheckBox.Text = "Druid";
            this.weaponDruidCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponPriestCheckBox
            // 
            this.weaponPriestCheckBox.AutoSize = true;
            this.weaponPriestCheckBox.Location = new System.Drawing.Point(480, 106);
            this.weaponPriestCheckBox.Name = "weaponPriestCheckBox";
            this.weaponPriestCheckBox.Size = new System.Drawing.Size(52, 17);
            this.weaponPriestCheckBox.TabIndex = 70;
            this.weaponPriestCheckBox.Text = "Priest";
            this.weaponPriestCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponRogueCheckBox
            // 
            this.weaponRogueCheckBox.AutoSize = true;
            this.weaponRogueCheckBox.Location = new System.Drawing.Point(395, 106);
            this.weaponRogueCheckBox.Name = "weaponRogueCheckBox";
            this.weaponRogueCheckBox.Size = new System.Drawing.Size(58, 17);
            this.weaponRogueCheckBox.TabIndex = 69;
            this.weaponRogueCheckBox.Text = "Rogue";
            this.weaponRogueCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponHunterCheckBox
            // 
            this.weaponHunterCheckBox.AutoSize = true;
            this.weaponHunterCheckBox.Location = new System.Drawing.Point(547, 71);
            this.weaponHunterCheckBox.Name = "weaponHunterCheckBox";
            this.weaponHunterCheckBox.Size = new System.Drawing.Size(58, 17);
            this.weaponHunterCheckBox.TabIndex = 68;
            this.weaponHunterCheckBox.Text = "Hunter";
            this.weaponHunterCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponPaladinCheckBox
            // 
            this.weaponPaladinCheckBox.AutoSize = true;
            this.weaponPaladinCheckBox.Location = new System.Drawing.Point(480, 71);
            this.weaponPaladinCheckBox.Name = "weaponPaladinCheckBox";
            this.weaponPaladinCheckBox.Size = new System.Drawing.Size(61, 17);
            this.weaponPaladinCheckBox.TabIndex = 67;
            this.weaponPaladinCheckBox.Text = "Paladin";
            this.weaponPaladinCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponWarriorCheckBox
            // 
            this.weaponWarriorCheckBox.AutoSize = true;
            this.weaponWarriorCheckBox.Location = new System.Drawing.Point(395, 71);
            this.weaponWarriorCheckBox.Name = "weaponWarriorCheckBox";
            this.weaponWarriorCheckBox.Size = new System.Drawing.Size(60, 17);
            this.weaponWarriorCheckBox.TabIndex = 66;
            this.weaponWarriorCheckBox.Text = "Warrior";
            this.weaponWarriorCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponClassAllCheckBox
            // 
            this.weaponClassAllCheckBox.AutoSize = true;
            this.weaponClassAllCheckBox.Location = new System.Drawing.Point(480, 42);
            this.weaponClassAllCheckBox.Name = "weaponClassAllCheckBox";
            this.weaponClassAllCheckBox.Size = new System.Drawing.Size(37, 17);
            this.weaponClassAllCheckBox.TabIndex = 65;
            this.weaponClassAllCheckBox.Text = "All";
            this.weaponClassAllCheckBox.UseVisualStyleBackColor = true;
            // 
            // weaponAllowableClassLabel
            // 
            this.weaponAllowableClassLabel.AutoSize = true;
            this.weaponAllowableClassLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponAllowableClassLabel.Location = new System.Drawing.Point(443, 11);
            this.weaponAllowableClassLabel.Name = "weaponAllowableClassLabel";
            this.weaponAllowableClassLabel.Size = new System.Drawing.Size(112, 18);
            this.weaponAllowableClassLabel.TabIndex = 64;
            this.weaponAllowableClassLabel.Text = "Allowable Class";
            // 
            // weaponMaxTextBox
            // 
            this.weaponMaxTextBox.Location = new System.Drawing.Point(172, 200);
            this.weaponMaxTextBox.Name = "weaponMaxTextBox";
            this.weaponMaxTextBox.Size = new System.Drawing.Size(45, 20);
            this.weaponMaxTextBox.TabIndex = 39;
            this.weaponMaxTextBox.Text = "1";
            // 
            // weaponMaxLabel
            // 
            this.weaponMaxLabel.AutoSize = true;
            this.weaponMaxLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponMaxLabel.Location = new System.Drawing.Point(75, 202);
            this.weaponMaxLabel.Name = "weaponMaxLabel";
            this.weaponMaxLabel.Size = new System.Drawing.Size(91, 18);
            this.weaponMaxLabel.TabIndex = 38;
            this.weaponMaxLabel.Text = "Max Allowed";
            // 
            // weaponItemLevelTextBox
            // 
            this.weaponItemLevelTextBox.Location = new System.Drawing.Point(172, 153);
            this.weaponItemLevelTextBox.Name = "weaponItemLevelTextBox";
            this.weaponItemLevelTextBox.Size = new System.Drawing.Size(45, 20);
            this.weaponItemLevelTextBox.TabIndex = 37;
            this.weaponItemLevelTextBox.Text = "0";
            // 
            // weaponItemLevelLabel
            // 
            this.weaponItemLevelLabel.AutoSize = true;
            this.weaponItemLevelLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponItemLevelLabel.Location = new System.Drawing.Point(92, 155);
            this.weaponItemLevelLabel.Name = "weaponItemLevelLabel";
            this.weaponItemLevelLabel.Size = new System.Drawing.Size(74, 18);
            this.weaponItemLevelLabel.TabIndex = 36;
            this.weaponItemLevelLabel.Text = "Item Level";
            // 
            // weaponRequiredLevelTextBox
            // 
            this.weaponRequiredLevelTextBox.Location = new System.Drawing.Point(172, 108);
            this.weaponRequiredLevelTextBox.Name = "weaponRequiredLevelTextBox";
            this.weaponRequiredLevelTextBox.Size = new System.Drawing.Size(45, 20);
            this.weaponRequiredLevelTextBox.TabIndex = 35;
            this.weaponRequiredLevelTextBox.Text = "0";
            // 
            // weaponRequiredLevelLabel
            // 
            this.weaponRequiredLevelLabel.AutoSize = true;
            this.weaponRequiredLevelLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponRequiredLevelLabel.Location = new System.Drawing.Point(61, 108);
            this.weaponRequiredLevelLabel.Name = "weaponRequiredLevelLabel";
            this.weaponRequiredLevelLabel.Size = new System.Drawing.Size(105, 18);
            this.weaponRequiredLevelLabel.TabIndex = 34;
            this.weaponRequiredLevelLabel.Text = "Required Level";
            // 
            // weaponDamageTabPage
            // 
            this.weaponDamageTabPage.Controls.Add(this.weaponDamageNextButton);
            this.weaponDamageTabPage.Controls.Add(this.weaponDamageType2ComboBox);
            this.weaponDamageTabPage.Controls.Add(this.weaponDamageType2Label);
            this.weaponDamageTabPage.Controls.Add(this.weaponDamageMax2TextBox);
            this.weaponDamageTabPage.Controls.Add(this.weaponDamageMax2Label);
            this.weaponDamageTabPage.Controls.Add(this.weaponDamageMin2TextBox);
            this.weaponDamageTabPage.Controls.Add(this.weaponDamageMin2Label);
            this.weaponDamageTabPage.Controls.Add(this.weaponDamageType1ComboBox);
            this.weaponDamageTabPage.Controls.Add(this.weaponDamageType1Label);
            this.weaponDamageTabPage.Controls.Add(this.weaponDamageMax1TextBox);
            this.weaponDamageTabPage.Controls.Add(this.weaponDamageMax1Label);
            this.weaponDamageTabPage.Controls.Add(this.weaponDamageMin1TextBox);
            this.weaponDamageTabPage.Controls.Add(this.weaponDamageMin1Label);
            this.weaponDamageTabPage.Location = new System.Drawing.Point(4, 22);
            this.weaponDamageTabPage.Name = "weaponDamageTabPage";
            this.weaponDamageTabPage.Size = new System.Drawing.Size(756, 376);
            this.weaponDamageTabPage.TabIndex = 8;
            this.weaponDamageTabPage.Text = "Damage";
            this.weaponDamageTabPage.UseVisualStyleBackColor = true;
            // 
            // weaponDamageNextButton
            // 
            this.weaponDamageNextButton.Location = new System.Drawing.Point(647, 331);
            this.weaponDamageNextButton.Name = "weaponDamageNextButton";
            this.weaponDamageNextButton.Size = new System.Drawing.Size(101, 41);
            this.weaponDamageNextButton.TabIndex = 89;
            this.weaponDamageNextButton.Text = "Next";
            this.weaponDamageNextButton.UseVisualStyleBackColor = true;
            this.weaponDamageNextButton.Click += new System.EventHandler(this.weaponDamageNextButton_Click);
            // 
            // weaponDamageType2ComboBox
            // 
            this.weaponDamageType2ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.weaponDamageType2ComboBox.FormattingEnabled = true;
            this.weaponDamageType2ComboBox.Items.AddRange(new object[] {
            "Physical",
            "Holy",
            "Fire",
            "Nature",
            "Frost",
            "Shadow",
            "Arcane"});
            this.weaponDamageType2ComboBox.Location = new System.Drawing.Point(489, 200);
            this.weaponDamageType2ComboBox.Name = "weaponDamageType2ComboBox";
            this.weaponDamageType2ComboBox.Size = new System.Drawing.Size(121, 21);
            this.weaponDamageType2ComboBox.TabIndex = 46;
            // 
            // weaponDamageType2Label
            // 
            this.weaponDamageType2Label.AutoSize = true;
            this.weaponDamageType2Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponDamageType2Label.Location = new System.Drawing.Point(443, 202);
            this.weaponDamageType2Label.Name = "weaponDamageType2Label";
            this.weaponDamageType2Label.Size = new System.Drawing.Size(40, 18);
            this.weaponDamageType2Label.TabIndex = 45;
            this.weaponDamageType2Label.Text = "Type";
            // 
            // weaponDamageMax2TextBox
            // 
            this.weaponDamageMax2TextBox.Location = new System.Drawing.Point(357, 202);
            this.weaponDamageMax2TextBox.Name = "weaponDamageMax2TextBox";
            this.weaponDamageMax2TextBox.Size = new System.Drawing.Size(66, 20);
            this.weaponDamageMax2TextBox.TabIndex = 44;
            this.weaponDamageMax2TextBox.Text = "0";
            // 
            // weaponDamageMax2Label
            // 
            this.weaponDamageMax2Label.AutoSize = true;
            this.weaponDamageMax2Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponDamageMax2Label.Location = new System.Drawing.Point(315, 203);
            this.weaponDamageMax2Label.Name = "weaponDamageMax2Label";
            this.weaponDamageMax2Label.Size = new System.Drawing.Size(36, 18);
            this.weaponDamageMax2Label.TabIndex = 43;
            this.weaponDamageMax2Label.Text = "Max";
            // 
            // weaponDamageMin2TextBox
            // 
            this.weaponDamageMin2TextBox.Location = new System.Drawing.Point(231, 201);
            this.weaponDamageMin2TextBox.Name = "weaponDamageMin2TextBox";
            this.weaponDamageMin2TextBox.Size = new System.Drawing.Size(66, 20);
            this.weaponDamageMin2TextBox.TabIndex = 42;
            this.weaponDamageMin2TextBox.Text = "0";
            // 
            // weaponDamageMin2Label
            // 
            this.weaponDamageMin2Label.AutoSize = true;
            this.weaponDamageMin2Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponDamageMin2Label.Location = new System.Drawing.Point(132, 204);
            this.weaponDamageMin2Label.Name = "weaponDamageMin2Label";
            this.weaponDamageMin2Label.Size = new System.Drawing.Size(92, 18);
            this.weaponDamageMin2Label.TabIndex = 41;
            this.weaponDamageMin2Label.Text = "Damage Min";
            // 
            // weaponDamageType1ComboBox
            // 
            this.weaponDamageType1ComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.weaponDamageType1ComboBox.FormattingEnabled = true;
            this.weaponDamageType1ComboBox.Items.AddRange(new object[] {
            "Physical",
            "Holy",
            "Fire",
            "Nature",
            "Frost",
            "Shadow",
            "Arcane"});
            this.weaponDamageType1ComboBox.Location = new System.Drawing.Point(489, 144);
            this.weaponDamageType1ComboBox.Name = "weaponDamageType1ComboBox";
            this.weaponDamageType1ComboBox.Size = new System.Drawing.Size(121, 21);
            this.weaponDamageType1ComboBox.TabIndex = 40;
            // 
            // weaponDamageType1Label
            // 
            this.weaponDamageType1Label.AutoSize = true;
            this.weaponDamageType1Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponDamageType1Label.Location = new System.Drawing.Point(443, 146);
            this.weaponDamageType1Label.Name = "weaponDamageType1Label";
            this.weaponDamageType1Label.Size = new System.Drawing.Size(40, 18);
            this.weaponDamageType1Label.TabIndex = 39;
            this.weaponDamageType1Label.Text = "Type";
            // 
            // weaponDamageMax1TextBox
            // 
            this.weaponDamageMax1TextBox.Location = new System.Drawing.Point(357, 146);
            this.weaponDamageMax1TextBox.Name = "weaponDamageMax1TextBox";
            this.weaponDamageMax1TextBox.Size = new System.Drawing.Size(66, 20);
            this.weaponDamageMax1TextBox.TabIndex = 38;
            this.weaponDamageMax1TextBox.Text = "0";
            // 
            // weaponDamageMax1Label
            // 
            this.weaponDamageMax1Label.AutoSize = true;
            this.weaponDamageMax1Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponDamageMax1Label.Location = new System.Drawing.Point(315, 147);
            this.weaponDamageMax1Label.Name = "weaponDamageMax1Label";
            this.weaponDamageMax1Label.Size = new System.Drawing.Size(36, 18);
            this.weaponDamageMax1Label.TabIndex = 37;
            this.weaponDamageMax1Label.Text = "Max";
            // 
            // weaponDamageMin1TextBox
            // 
            this.weaponDamageMin1TextBox.Location = new System.Drawing.Point(231, 145);
            this.weaponDamageMin1TextBox.Name = "weaponDamageMin1TextBox";
            this.weaponDamageMin1TextBox.Size = new System.Drawing.Size(66, 20);
            this.weaponDamageMin1TextBox.TabIndex = 36;
            this.weaponDamageMin1TextBox.Text = "0";
            // 
            // weaponDamageMin1Label
            // 
            this.weaponDamageMin1Label.AutoSize = true;
            this.weaponDamageMin1Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponDamageMin1Label.Location = new System.Drawing.Point(132, 148);
            this.weaponDamageMin1Label.Name = "weaponDamageMin1Label";
            this.weaponDamageMin1Label.Size = new System.Drawing.Size(92, 18);
            this.weaponDamageMin1Label.TabIndex = 35;
            this.weaponDamageMin1Label.Text = "Damage Min";
            // 
            // weaponResistsTabPage
            // 
            this.weaponResistsTabPage.Controls.Add(this.weaponResistsNextButton);
            this.weaponResistsTabPage.Controls.Add(this.weaponArcaneTextBox);
            this.weaponResistsTabPage.Controls.Add(this.weaponArcaneLabel);
            this.weaponResistsTabPage.Controls.Add(this.weaponFrostTextBox);
            this.weaponResistsTabPage.Controls.Add(this.weaponFrostLabel);
            this.weaponResistsTabPage.Controls.Add(this.weaponFireTextBox);
            this.weaponResistsTabPage.Controls.Add(this.weaponFireLabel);
            this.weaponResistsTabPage.Controls.Add(this.weaponShadowTextBox);
            this.weaponResistsTabPage.Controls.Add(this.weaponShadowLabel);
            this.weaponResistsTabPage.Controls.Add(this.weaponNatureTextBox);
            this.weaponResistsTabPage.Controls.Add(this.weaponNatureLabel);
            this.weaponResistsTabPage.Controls.Add(this.weaponHolyTextBox);
            this.weaponResistsTabPage.Controls.Add(this.weaponHolyLabel);
            this.weaponResistsTabPage.Location = new System.Drawing.Point(4, 22);
            this.weaponResistsTabPage.Name = "weaponResistsTabPage";
            this.weaponResistsTabPage.Size = new System.Drawing.Size(756, 376);
            this.weaponResistsTabPage.TabIndex = 3;
            this.weaponResistsTabPage.Text = "Resists";
            this.weaponResistsTabPage.UseVisualStyleBackColor = true;
            // 
            // weaponResistsNextButton
            // 
            this.weaponResistsNextButton.Location = new System.Drawing.Point(647, 331);
            this.weaponResistsNextButton.Name = "weaponResistsNextButton";
            this.weaponResistsNextButton.Size = new System.Drawing.Size(101, 41);
            this.weaponResistsNextButton.TabIndex = 90;
            this.weaponResistsNextButton.Text = "Next";
            this.weaponResistsNextButton.UseVisualStyleBackColor = true;
            this.weaponResistsNextButton.Click += new System.EventHandler(this.weaponResistsNextButton_Click);
            // 
            // weaponArcaneTextBox
            // 
            this.weaponArcaneTextBox.Location = new System.Drawing.Point(522, 221);
            this.weaponArcaneTextBox.Name = "weaponArcaneTextBox";
            this.weaponArcaneTextBox.Size = new System.Drawing.Size(64, 20);
            this.weaponArcaneTextBox.TabIndex = 37;
            this.weaponArcaneTextBox.Text = "0";
            // 
            // weaponArcaneLabel
            // 
            this.weaponArcaneLabel.AutoSize = true;
            this.weaponArcaneLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponArcaneLabel.Location = new System.Drawing.Point(440, 223);
            this.weaponArcaneLabel.Name = "weaponArcaneLabel";
            this.weaponArcaneLabel.Size = new System.Drawing.Size(54, 18);
            this.weaponArcaneLabel.TabIndex = 36;
            this.weaponArcaneLabel.Text = "Arcane";
            // 
            // weaponFrostTextBox
            // 
            this.weaponFrostTextBox.Location = new System.Drawing.Point(522, 177);
            this.weaponFrostTextBox.Name = "weaponFrostTextBox";
            this.weaponFrostTextBox.Size = new System.Drawing.Size(64, 20);
            this.weaponFrostTextBox.TabIndex = 35;
            this.weaponFrostTextBox.Text = "0";
            // 
            // weaponFrostLabel
            // 
            this.weaponFrostLabel.AutoSize = true;
            this.weaponFrostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponFrostLabel.Location = new System.Drawing.Point(451, 176);
            this.weaponFrostLabel.Name = "weaponFrostLabel";
            this.weaponFrostLabel.Size = new System.Drawing.Size(43, 18);
            this.weaponFrostLabel.TabIndex = 34;
            this.weaponFrostLabel.Text = "Frost";
            // 
            // weaponFireTextBox
            // 
            this.weaponFireTextBox.Location = new System.Drawing.Point(522, 135);
            this.weaponFireTextBox.Name = "weaponFireTextBox";
            this.weaponFireTextBox.Size = new System.Drawing.Size(64, 20);
            this.weaponFireTextBox.TabIndex = 33;
            this.weaponFireTextBox.Text = "0";
            // 
            // weaponFireLabel
            // 
            this.weaponFireLabel.AutoSize = true;
            this.weaponFireLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponFireLabel.Location = new System.Drawing.Point(461, 134);
            this.weaponFireLabel.Name = "weaponFireLabel";
            this.weaponFireLabel.Size = new System.Drawing.Size(33, 18);
            this.weaponFireLabel.TabIndex = 32;
            this.weaponFireLabel.Text = "Fire";
            // 
            // weaponShadowTextBox
            // 
            this.weaponShadowTextBox.Location = new System.Drawing.Point(261, 222);
            this.weaponShadowTextBox.Name = "weaponShadowTextBox";
            this.weaponShadowTextBox.Size = new System.Drawing.Size(64, 20);
            this.weaponShadowTextBox.TabIndex = 31;
            this.weaponShadowTextBox.Text = "0";
            // 
            // weaponShadowLabel
            // 
            this.weaponShadowLabel.AutoSize = true;
            this.weaponShadowLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponShadowLabel.Location = new System.Drawing.Point(171, 222);
            this.weaponShadowLabel.Name = "weaponShadowLabel";
            this.weaponShadowLabel.Size = new System.Drawing.Size(62, 18);
            this.weaponShadowLabel.TabIndex = 30;
            this.weaponShadowLabel.Text = "Shadow";
            // 
            // weaponNatureTextBox
            // 
            this.weaponNatureTextBox.Location = new System.Drawing.Point(261, 179);
            this.weaponNatureTextBox.Name = "weaponNatureTextBox";
            this.weaponNatureTextBox.Size = new System.Drawing.Size(64, 20);
            this.weaponNatureTextBox.TabIndex = 29;
            this.weaponNatureTextBox.Text = "0";
            // 
            // weaponNatureLabel
            // 
            this.weaponNatureLabel.AutoSize = true;
            this.weaponNatureLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponNatureLabel.Location = new System.Drawing.Point(181, 178);
            this.weaponNatureLabel.Name = "weaponNatureLabel";
            this.weaponNatureLabel.Size = new System.Drawing.Size(52, 18);
            this.weaponNatureLabel.TabIndex = 28;
            this.weaponNatureLabel.Text = "Nature";
            // 
            // weaponHolyTextBox
            // 
            this.weaponHolyTextBox.Location = new System.Drawing.Point(261, 134);
            this.weaponHolyTextBox.Name = "weaponHolyTextBox";
            this.weaponHolyTextBox.Size = new System.Drawing.Size(64, 20);
            this.weaponHolyTextBox.TabIndex = 27;
            this.weaponHolyTextBox.Text = "0";
            // 
            // weaponHolyLabel
            // 
            this.weaponHolyLabel.AutoSize = true;
            this.weaponHolyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponHolyLabel.Location = new System.Drawing.Point(195, 137);
            this.weaponHolyLabel.Name = "weaponHolyLabel";
            this.weaponHolyLabel.Size = new System.Drawing.Size(38, 18);
            this.weaponHolyLabel.TabIndex = 26;
            this.weaponHolyLabel.Text = "Holy";
            // 
            // weaponSocketsTabPage
            // 
            this.weaponSocketsTabPage.Controls.Add(this.weaponSocketBonusLabel);
            this.weaponSocketsTabPage.Controls.Add(this.weaponSocketBonusComboBox);
            this.weaponSocketsTabPage.Controls.Add(this.weaponSocket3NoneButton);
            this.weaponSocketsTabPage.Controls.Add(this.weaponSocket2NoneButton);
            this.weaponSocketsTabPage.Controls.Add(this.weaponSocket1NoneButton);
            this.weaponSocketsTabPage.Controls.Add(this.weaponSocketsNextButton);
            this.weaponSocketsTabPage.Controls.Add(this.weaponSocket3YellowButton);
            this.weaponSocketsTabPage.Controls.Add(this.weaponSocket3RedButton);
            this.weaponSocketsTabPage.Controls.Add(this.weaponSocket3BlueButton);
            this.weaponSocketsTabPage.Controls.Add(this.weaponSocket3Label);
            this.weaponSocketsTabPage.Controls.Add(this.weaponSocket2YellowButton);
            this.weaponSocketsTabPage.Controls.Add(this.weaponSocket2RedButton);
            this.weaponSocketsTabPage.Controls.Add(this.weaponSocket2BlueButton);
            this.weaponSocketsTabPage.Controls.Add(this.label17);
            this.weaponSocketsTabPage.Controls.Add(this.weaponSocket1YellowButton);
            this.weaponSocketsTabPage.Controls.Add(this.weaponSocket1RedButton);
            this.weaponSocketsTabPage.Controls.Add(this.weaponSocket1BlueButton);
            this.weaponSocketsTabPage.Controls.Add(this.weaponSocket1Label);
            this.weaponSocketsTabPage.Location = new System.Drawing.Point(4, 22);
            this.weaponSocketsTabPage.Name = "weaponSocketsTabPage";
            this.weaponSocketsTabPage.Size = new System.Drawing.Size(756, 376);
            this.weaponSocketsTabPage.TabIndex = 5;
            this.weaponSocketsTabPage.Text = "Sockets";
            this.weaponSocketsTabPage.UseVisualStyleBackColor = true;
            // 
            // weaponSocketBonusLabel
            // 
            this.weaponSocketBonusLabel.AutoSize = true;
            this.weaponSocketBonusLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponSocketBonusLabel.Location = new System.Drawing.Point(282, 270);
            this.weaponSocketBonusLabel.Name = "weaponSocketBonusLabel";
            this.weaponSocketBonusLabel.Size = new System.Drawing.Size(51, 18);
            this.weaponSocketBonusLabel.TabIndex = 96;
            this.weaponSocketBonusLabel.Text = "Bonus";
            // 
            // weaponSocketBonusComboBox
            // 
            this.weaponSocketBonusComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.weaponSocketBonusComboBox.FormattingEnabled = true;
            this.weaponSocketBonusComboBox.Items.AddRange(new object[] {
            "None",
            "+4 Agility",
            "+4 Strength",
            "+4 Stamina",
            "+4 Intellect",
            "+4 Spirit",
            "+4 Spell Power",
            "+4 Attack Power",
            "+4 Hit Rating",
            "+4 Critical Strike Rating"});
            this.weaponSocketBonusComboBox.Location = new System.Drawing.Point(348, 267);
            this.weaponSocketBonusComboBox.Name = "weaponSocketBonusComboBox";
            this.weaponSocketBonusComboBox.Size = new System.Drawing.Size(121, 21);
            this.weaponSocketBonusComboBox.TabIndex = 95;
            // 
            // weaponSocket3NoneButton
            // 
            this.weaponSocket3NoneButton.Enabled = false;
            this.weaponSocket3NoneButton.Location = new System.Drawing.Point(285, 216);
            this.weaponSocket3NoneButton.Name = "weaponSocket3NoneButton";
            this.weaponSocket3NoneButton.Size = new System.Drawing.Size(66, 23);
            this.weaponSocket3NoneButton.TabIndex = 94;
            this.weaponSocket3NoneButton.Text = "None";
            this.weaponSocket3NoneButton.UseVisualStyleBackColor = true;
            this.weaponSocket3NoneButton.Click += new System.EventHandler(this.weaponSocket3NoneButton_Click);
            // 
            // weaponSocket2NoneButton
            // 
            this.weaponSocket2NoneButton.Enabled = false;
            this.weaponSocket2NoneButton.Location = new System.Drawing.Point(285, 161);
            this.weaponSocket2NoneButton.Name = "weaponSocket2NoneButton";
            this.weaponSocket2NoneButton.Size = new System.Drawing.Size(66, 23);
            this.weaponSocket2NoneButton.TabIndex = 93;
            this.weaponSocket2NoneButton.Text = "None";
            this.weaponSocket2NoneButton.UseVisualStyleBackColor = true;
            this.weaponSocket2NoneButton.Click += new System.EventHandler(this.weaponSocket2NoneButton_Click);
            // 
            // weaponSocket1NoneButton
            // 
            this.weaponSocket1NoneButton.Enabled = false;
            this.weaponSocket1NoneButton.Location = new System.Drawing.Point(285, 114);
            this.weaponSocket1NoneButton.Name = "weaponSocket1NoneButton";
            this.weaponSocket1NoneButton.Size = new System.Drawing.Size(66, 23);
            this.weaponSocket1NoneButton.TabIndex = 92;
            this.weaponSocket1NoneButton.Text = "None";
            this.weaponSocket1NoneButton.UseVisualStyleBackColor = true;
            this.weaponSocket1NoneButton.Click += new System.EventHandler(this.weaponSocket1NoneButton_Click);
            // 
            // weaponSocketsNextButton
            // 
            this.weaponSocketsNextButton.Location = new System.Drawing.Point(647, 331);
            this.weaponSocketsNextButton.Name = "weaponSocketsNextButton";
            this.weaponSocketsNextButton.Size = new System.Drawing.Size(101, 41);
            this.weaponSocketsNextButton.TabIndex = 91;
            this.weaponSocketsNextButton.Text = "Next";
            this.weaponSocketsNextButton.UseVisualStyleBackColor = true;
            this.weaponSocketsNextButton.Click += new System.EventHandler(this.weaponSocketsNextButton_Click);
            // 
            // weaponSocket3YellowButton
            // 
            this.weaponSocket3YellowButton.Location = new System.Drawing.Point(478, 215);
            this.weaponSocket3YellowButton.Name = "weaponSocket3YellowButton";
            this.weaponSocket3YellowButton.Size = new System.Drawing.Size(51, 23);
            this.weaponSocket3YellowButton.TabIndex = 38;
            this.weaponSocket3YellowButton.Text = "Yellow";
            this.weaponSocket3YellowButton.UseVisualStyleBackColor = true;
            this.weaponSocket3YellowButton.Click += new System.EventHandler(this.weaponSocket3YellowButton_Click);
            // 
            // weaponSocket3RedButton
            // 
            this.weaponSocket3RedButton.Location = new System.Drawing.Point(421, 215);
            this.weaponSocket3RedButton.Name = "weaponSocket3RedButton";
            this.weaponSocket3RedButton.Size = new System.Drawing.Size(51, 23);
            this.weaponSocket3RedButton.TabIndex = 37;
            this.weaponSocket3RedButton.Text = "Red";
            this.weaponSocket3RedButton.UseVisualStyleBackColor = true;
            this.weaponSocket3RedButton.Click += new System.EventHandler(this.weaponSocket3RedButton_Click);
            // 
            // weaponSocket3BlueButton
            // 
            this.weaponSocket3BlueButton.Location = new System.Drawing.Point(364, 215);
            this.weaponSocket3BlueButton.Name = "weaponSocket3BlueButton";
            this.weaponSocket3BlueButton.Size = new System.Drawing.Size(51, 23);
            this.weaponSocket3BlueButton.TabIndex = 36;
            this.weaponSocket3BlueButton.Text = "Blue";
            this.weaponSocket3BlueButton.UseVisualStyleBackColor = true;
            this.weaponSocket3BlueButton.Click += new System.EventHandler(this.weaponSocket3BlueButton_Click);
            // 
            // weaponSocket3Label
            // 
            this.weaponSocket3Label.AutoSize = true;
            this.weaponSocket3Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponSocket3Label.Location = new System.Drawing.Point(203, 216);
            this.weaponSocket3Label.Name = "weaponSocket3Label";
            this.weaponSocket3Label.Size = new System.Drawing.Size(67, 18);
            this.weaponSocket3Label.TabIndex = 35;
            this.weaponSocket3Label.Text = "Socket 3";
            // 
            // weaponSocket2YellowButton
            // 
            this.weaponSocket2YellowButton.Location = new System.Drawing.Point(478, 165);
            this.weaponSocket2YellowButton.Name = "weaponSocket2YellowButton";
            this.weaponSocket2YellowButton.Size = new System.Drawing.Size(51, 23);
            this.weaponSocket2YellowButton.TabIndex = 34;
            this.weaponSocket2YellowButton.Text = "Yellow";
            this.weaponSocket2YellowButton.UseVisualStyleBackColor = true;
            this.weaponSocket2YellowButton.Click += new System.EventHandler(this.weaponSocket2YellowButton_Click);
            // 
            // weaponSocket2RedButton
            // 
            this.weaponSocket2RedButton.Location = new System.Drawing.Point(421, 165);
            this.weaponSocket2RedButton.Name = "weaponSocket2RedButton";
            this.weaponSocket2RedButton.Size = new System.Drawing.Size(51, 23);
            this.weaponSocket2RedButton.TabIndex = 33;
            this.weaponSocket2RedButton.Text = "Red";
            this.weaponSocket2RedButton.UseVisualStyleBackColor = true;
            this.weaponSocket2RedButton.Click += new System.EventHandler(this.weaponSocket2RedButton_Click);
            // 
            // weaponSocket2BlueButton
            // 
            this.weaponSocket2BlueButton.Location = new System.Drawing.Point(364, 165);
            this.weaponSocket2BlueButton.Name = "weaponSocket2BlueButton";
            this.weaponSocket2BlueButton.Size = new System.Drawing.Size(51, 23);
            this.weaponSocket2BlueButton.TabIndex = 32;
            this.weaponSocket2BlueButton.Text = "Blue";
            this.weaponSocket2BlueButton.UseVisualStyleBackColor = true;
            this.weaponSocket2BlueButton.Click += new System.EventHandler(this.weaponSocket2BlueButton_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(203, 166);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(67, 18);
            this.label17.TabIndex = 31;
            this.label17.Text = "Socket 2";
            // 
            // weaponSocket1YellowButton
            // 
            this.weaponSocket1YellowButton.Location = new System.Drawing.Point(478, 114);
            this.weaponSocket1YellowButton.Name = "weaponSocket1YellowButton";
            this.weaponSocket1YellowButton.Size = new System.Drawing.Size(51, 23);
            this.weaponSocket1YellowButton.TabIndex = 30;
            this.weaponSocket1YellowButton.Text = "Yellow";
            this.weaponSocket1YellowButton.UseVisualStyleBackColor = true;
            this.weaponSocket1YellowButton.Click += new System.EventHandler(this.weaponSocket1YellowButton_Click);
            // 
            // weaponSocket1RedButton
            // 
            this.weaponSocket1RedButton.Location = new System.Drawing.Point(421, 114);
            this.weaponSocket1RedButton.Name = "weaponSocket1RedButton";
            this.weaponSocket1RedButton.Size = new System.Drawing.Size(51, 23);
            this.weaponSocket1RedButton.TabIndex = 29;
            this.weaponSocket1RedButton.Text = "Red";
            this.weaponSocket1RedButton.UseVisualStyleBackColor = true;
            this.weaponSocket1RedButton.Click += new System.EventHandler(this.weaponSocket1RedButton_Click);
            // 
            // weaponSocket1BlueButton
            // 
            this.weaponSocket1BlueButton.Location = new System.Drawing.Point(364, 114);
            this.weaponSocket1BlueButton.Name = "weaponSocket1BlueButton";
            this.weaponSocket1BlueButton.Size = new System.Drawing.Size(51, 23);
            this.weaponSocket1BlueButton.TabIndex = 28;
            this.weaponSocket1BlueButton.Text = "Blue";
            this.weaponSocket1BlueButton.UseVisualStyleBackColor = true;
            this.weaponSocket1BlueButton.Click += new System.EventHandler(this.weaponSocket1BlueButton_Click);
            // 
            // weaponSocket1Label
            // 
            this.weaponSocket1Label.AutoSize = true;
            this.weaponSocket1Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponSocket1Label.Location = new System.Drawing.Point(203, 115);
            this.weaponSocket1Label.Name = "weaponSocket1Label";
            this.weaponSocket1Label.Size = new System.Drawing.Size(67, 18);
            this.weaponSocket1Label.TabIndex = 27;
            this.weaponSocket1Label.Text = "Socket 1";
            // 
            // weaponPriceTabPage
            // 
            this.weaponPriceTabPage.Controls.Add(this.weaponPriceNextButton);
            this.weaponPriceTabPage.Controls.Add(this.weaponSellCopperNumericUpDown);
            this.weaponPriceTabPage.Controls.Add(this.weaponSellSilverNumericUpDown);
            this.weaponPriceTabPage.Controls.Add(this.weaponBuyCopperNumericUpDown);
            this.weaponPriceTabPage.Controls.Add(this.weaponBuySilverNumericUpDown);
            this.weaponPriceTabPage.Controls.Add(this.weaponSellCopperLabel);
            this.weaponPriceTabPage.Controls.Add(this.weaponSellSilverLabel);
            this.weaponPriceTabPage.Controls.Add(this.weaponSellGoldLabel);
            this.weaponPriceTabPage.Controls.Add(this.weaponSellGoldTextBox);
            this.weaponPriceTabPage.Controls.Add(this.weaponBuyCopperLabel);
            this.weaponPriceTabPage.Controls.Add(this.weaponBuySilverLabel);
            this.weaponPriceTabPage.Controls.Add(this.weaponBuyGoldLabel);
            this.weaponPriceTabPage.Controls.Add(this.weaponSellPriceLabel);
            this.weaponPriceTabPage.Controls.Add(this.weaponBuyGoldTextBox);
            this.weaponPriceTabPage.Controls.Add(this.weaponBuyPriceLabel);
            this.weaponPriceTabPage.Location = new System.Drawing.Point(4, 22);
            this.weaponPriceTabPage.Name = "weaponPriceTabPage";
            this.weaponPriceTabPage.Size = new System.Drawing.Size(756, 376);
            this.weaponPriceTabPage.TabIndex = 6;
            this.weaponPriceTabPage.Text = "Price";
            this.weaponPriceTabPage.UseVisualStyleBackColor = true;
            // 
            // weaponPriceNextButton
            // 
            this.weaponPriceNextButton.Location = new System.Drawing.Point(647, 331);
            this.weaponPriceNextButton.Name = "weaponPriceNextButton";
            this.weaponPriceNextButton.Size = new System.Drawing.Size(101, 41);
            this.weaponPriceNextButton.TabIndex = 92;
            this.weaponPriceNextButton.Text = "Next";
            this.weaponPriceNextButton.UseVisualStyleBackColor = true;
            this.weaponPriceNextButton.Click += new System.EventHandler(this.weaponPriceNextButton_Click);
            // 
            // weaponSellCopperNumericUpDown
            // 
            this.weaponSellCopperNumericUpDown.Location = new System.Drawing.Point(519, 210);
            this.weaponSellCopperNumericUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.weaponSellCopperNumericUpDown.Name = "weaponSellCopperNumericUpDown";
            this.weaponSellCopperNumericUpDown.Size = new System.Drawing.Size(45, 20);
            this.weaponSellCopperNumericUpDown.TabIndex = 5;
            // 
            // weaponSellSilverNumericUpDown
            // 
            this.weaponSellSilverNumericUpDown.Location = new System.Drawing.Point(383, 210);
            this.weaponSellSilverNumericUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.weaponSellSilverNumericUpDown.Name = "weaponSellSilverNumericUpDown";
            this.weaponSellSilverNumericUpDown.Size = new System.Drawing.Size(45, 20);
            this.weaponSellSilverNumericUpDown.TabIndex = 4;
            // 
            // weaponBuyCopperNumericUpDown
            // 
            this.weaponBuyCopperNumericUpDown.Location = new System.Drawing.Point(519, 146);
            this.weaponBuyCopperNumericUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.weaponBuyCopperNumericUpDown.Name = "weaponBuyCopperNumericUpDown";
            this.weaponBuyCopperNumericUpDown.Size = new System.Drawing.Size(45, 20);
            this.weaponBuyCopperNumericUpDown.TabIndex = 2;
            // 
            // weaponBuySilverNumericUpDown
            // 
            this.weaponBuySilverNumericUpDown.Location = new System.Drawing.Point(383, 147);
            this.weaponBuySilverNumericUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.weaponBuySilverNumericUpDown.Name = "weaponBuySilverNumericUpDown";
            this.weaponBuySilverNumericUpDown.Size = new System.Drawing.Size(45, 20);
            this.weaponBuySilverNumericUpDown.TabIndex = 1;
            // 
            // weaponSellCopperLabel
            // 
            this.weaponSellCopperLabel.AutoSize = true;
            this.weaponSellCopperLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponSellCopperLabel.Location = new System.Drawing.Point(570, 208);
            this.weaponSellCopperLabel.Name = "weaponSellCopperLabel";
            this.weaponSellCopperLabel.Size = new System.Drawing.Size(57, 18);
            this.weaponSellCopperLabel.TabIndex = 59;
            this.weaponSellCopperLabel.Text = "Copper";
            // 
            // weaponSellSilverLabel
            // 
            this.weaponSellSilverLabel.AutoSize = true;
            this.weaponSellSilverLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponSellSilverLabel.Location = new System.Drawing.Point(434, 208);
            this.weaponSellSilverLabel.Name = "weaponSellSilverLabel";
            this.weaponSellSilverLabel.Size = new System.Drawing.Size(44, 18);
            this.weaponSellSilverLabel.TabIndex = 58;
            this.weaponSellSilverLabel.Text = "Silver";
            // 
            // weaponSellGoldLabel
            // 
            this.weaponSellGoldLabel.AutoSize = true;
            this.weaponSellGoldLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponSellGoldLabel.Location = new System.Drawing.Point(311, 208);
            this.weaponSellGoldLabel.Name = "weaponSellGoldLabel";
            this.weaponSellGoldLabel.Size = new System.Drawing.Size(40, 18);
            this.weaponSellGoldLabel.TabIndex = 57;
            this.weaponSellGoldLabel.Text = "Gold";
            // 
            // weaponSellGoldTextBox
            // 
            this.weaponSellGoldTextBox.Location = new System.Drawing.Point(254, 206);
            this.weaponSellGoldTextBox.Name = "weaponSellGoldTextBox";
            this.weaponSellGoldTextBox.Size = new System.Drawing.Size(41, 20);
            this.weaponSellGoldTextBox.TabIndex = 3;
            this.weaponSellGoldTextBox.Text = "0";
            // 
            // weaponBuyCopperLabel
            // 
            this.weaponBuyCopperLabel.AutoSize = true;
            this.weaponBuyCopperLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponBuyCopperLabel.Location = new System.Drawing.Point(570, 148);
            this.weaponBuyCopperLabel.Name = "weaponBuyCopperLabel";
            this.weaponBuyCopperLabel.Size = new System.Drawing.Size(57, 18);
            this.weaponBuyCopperLabel.TabIndex = 55;
            this.weaponBuyCopperLabel.Text = "Copper";
            // 
            // weaponBuySilverLabel
            // 
            this.weaponBuySilverLabel.AutoSize = true;
            this.weaponBuySilverLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponBuySilverLabel.Location = new System.Drawing.Point(434, 148);
            this.weaponBuySilverLabel.Name = "weaponBuySilverLabel";
            this.weaponBuySilverLabel.Size = new System.Drawing.Size(44, 18);
            this.weaponBuySilverLabel.TabIndex = 54;
            this.weaponBuySilverLabel.Text = "Silver";
            // 
            // weaponBuyGoldLabel
            // 
            this.weaponBuyGoldLabel.AutoSize = true;
            this.weaponBuyGoldLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponBuyGoldLabel.Location = new System.Drawing.Point(311, 148);
            this.weaponBuyGoldLabel.Name = "weaponBuyGoldLabel";
            this.weaponBuyGoldLabel.Size = new System.Drawing.Size(40, 18);
            this.weaponBuyGoldLabel.TabIndex = 53;
            this.weaponBuyGoldLabel.Text = "Gold";
            // 
            // weaponSellPriceLabel
            // 
            this.weaponSellPriceLabel.AutoSize = true;
            this.weaponSellPriceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponSellPriceLabel.Location = new System.Drawing.Point(130, 208);
            this.weaponSellPriceLabel.Name = "weaponSellPriceLabel";
            this.weaponSellPriceLabel.Size = new System.Drawing.Size(70, 18);
            this.weaponSellPriceLabel.TabIndex = 52;
            this.weaponSellPriceLabel.Text = "Sell Price";
            // 
            // weaponBuyGoldTextBox
            // 
            this.weaponBuyGoldTextBox.Location = new System.Drawing.Point(254, 146);
            this.weaponBuyGoldTextBox.Name = "weaponBuyGoldTextBox";
            this.weaponBuyGoldTextBox.Size = new System.Drawing.Size(41, 20);
            this.weaponBuyGoldTextBox.TabIndex = 0;
            this.weaponBuyGoldTextBox.Text = "0";
            // 
            // weaponBuyPriceLabel
            // 
            this.weaponBuyPriceLabel.AutoSize = true;
            this.weaponBuyPriceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponBuyPriceLabel.Location = new System.Drawing.Point(130, 146);
            this.weaponBuyPriceLabel.Name = "weaponBuyPriceLabel";
            this.weaponBuyPriceLabel.Size = new System.Drawing.Size(71, 18);
            this.weaponBuyPriceLabel.TabIndex = 50;
            this.weaponBuyPriceLabel.Text = "Buy Price";
            // 
            // weaponFinishTabPage
            // 
            this.weaponFinishTabPage.Controls.Add(this.weaponSaveToSQLFileButton);
            this.weaponFinishTabPage.Controls.Add(this.weaponSaveToDBButton);
            this.weaponFinishTabPage.Controls.Add(this.weaponStartOverButton);
            this.weaponFinishTabPage.Location = new System.Drawing.Point(4, 22);
            this.weaponFinishTabPage.Name = "weaponFinishTabPage";
            this.weaponFinishTabPage.Size = new System.Drawing.Size(756, 376);
            this.weaponFinishTabPage.TabIndex = 7;
            this.weaponFinishTabPage.Text = "Finish";
            this.weaponFinishTabPage.UseVisualStyleBackColor = true;
            // 
            // weaponSaveToSQLFileButton
            // 
            this.weaponSaveToSQLFileButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponSaveToSQLFileButton.Location = new System.Drawing.Point(281, 219);
            this.weaponSaveToSQLFileButton.Name = "weaponSaveToSQLFileButton";
            this.weaponSaveToSQLFileButton.Size = new System.Drawing.Size(208, 74);
            this.weaponSaveToSQLFileButton.TabIndex = 10;
            this.weaponSaveToSQLFileButton.Text = "Save To SQL File";
            this.weaponSaveToSQLFileButton.UseVisualStyleBackColor = true;
            this.weaponSaveToSQLFileButton.Click += new System.EventHandler(this.weaponSaveToSQLFileButton_Click);
            // 
            // weaponSaveToDBButton
            // 
            this.weaponSaveToDBButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponSaveToDBButton.Location = new System.Drawing.Point(453, 83);
            this.weaponSaveToDBButton.Name = "weaponSaveToDBButton";
            this.weaponSaveToDBButton.Size = new System.Drawing.Size(208, 74);
            this.weaponSaveToDBButton.TabIndex = 9;
            this.weaponSaveToDBButton.Text = "Save To Database";
            this.weaponSaveToDBButton.UseVisualStyleBackColor = true;
            this.weaponSaveToDBButton.Click += new System.EventHandler(this.weaponSaveToDBButton_Click);
            // 
            // weaponStartOverButton
            // 
            this.weaponStartOverButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weaponStartOverButton.Location = new System.Drawing.Point(95, 83);
            this.weaponStartOverButton.Name = "weaponStartOverButton";
            this.weaponStartOverButton.Size = new System.Drawing.Size(208, 74);
            this.weaponStartOverButton.TabIndex = 8;
            this.weaponStartOverButton.Text = "Start Over";
            this.weaponStartOverButton.UseVisualStyleBackColor = true;
            this.weaponStartOverButton.Click += new System.EventHandler(this.weaponStartOverButton_Click);
            // 
            // armorTabPage
            // 
            this.armorTabPage.Controls.Add(this.armorTabControl);
            this.armorTabPage.Location = new System.Drawing.Point(4, 22);
            this.armorTabPage.Name = "armorTabPage";
            this.armorTabPage.Size = new System.Drawing.Size(760, 402);
            this.armorTabPage.TabIndex = 5;
            this.armorTabPage.Text = "Armor";
            this.armorTabPage.UseVisualStyleBackColor = true;
            // 
            // armorTabControl
            // 
            this.armorTabControl.Controls.Add(this.armorDetailsTabPage);
            this.armorTabControl.Controls.Add(this.armorStatsTabPage);
            this.armorTabControl.Controls.Add(this.armorRequirementsTabPage);
            this.armorTabControl.Controls.Add(this.armorSocketsTabPage);
            this.armorTabControl.Controls.Add(this.armorPriceTabPage);
            this.armorTabControl.Controls.Add(this.armorFinishTabPage);
            this.armorTabControl.Location = new System.Drawing.Point(-1, 0);
            this.armorTabControl.Name = "armorTabControl";
            this.armorTabControl.SelectedIndex = 0;
            this.armorTabControl.Size = new System.Drawing.Size(765, 406);
            this.armorTabControl.TabIndex = 0;
            // 
            // armorDetailsTabPage
            // 
            this.armorDetailsTabPage.Controls.Add(this.armorMaterialComboBox);
            this.armorDetailsTabPage.Controls.Add(this.armorMaterialLabel);
            this.armorDetailsTabPage.Controls.Add(this.armorRequiredLabel);
            this.armorDetailsTabPage.Controls.Add(this.armorSearchDisplayIDs);
            this.armorDetailsTabPage.Controls.Add(this.armorDetailsNextButton);
            this.armorDetailsTabPage.Controls.Add(this.armorBindsComboBox);
            this.armorDetailsTabPage.Controls.Add(this.armorBindsLabel);
            this.armorDetailsTabPage.Controls.Add(this.armorDurabilityTextBox);
            this.armorDetailsTabPage.Controls.Add(this.armorDurabilityLabel);
            this.armorDetailsTabPage.Controls.Add(this.armorEquipComboBox);
            this.armorDetailsTabPage.Controls.Add(this.armorEquipLabel);
            this.armorDetailsTabPage.Controls.Add(this.armorEntryIDTextBox);
            this.armorDetailsTabPage.Controls.Add(this.armorEntryIDLabel);
            this.armorDetailsTabPage.Controls.Add(this.armorDisplayIDTextBox);
            this.armorDetailsTabPage.Controls.Add(this.armorDisplayIDLabel);
            this.armorDetailsTabPage.Controls.Add(this.armorQualityComboBox);
            this.armorDetailsTabPage.Controls.Add(this.armorQualityLabel);
            this.armorDetailsTabPage.Controls.Add(this.armorQuoteTextBox);
            this.armorDetailsTabPage.Controls.Add(this.armorQuoteLabel);
            this.armorDetailsTabPage.Controls.Add(this.armorNameTextBox);
            this.armorDetailsTabPage.Controls.Add(this.armorNameLabel);
            this.armorDetailsTabPage.Location = new System.Drawing.Point(4, 22);
            this.armorDetailsTabPage.Name = "armorDetailsTabPage";
            this.armorDetailsTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.armorDetailsTabPage.Size = new System.Drawing.Size(757, 380);
            this.armorDetailsTabPage.TabIndex = 0;
            this.armorDetailsTabPage.Text = "Details";
            this.armorDetailsTabPage.UseVisualStyleBackColor = true;
            // 
            // armorMaterialComboBox
            // 
            this.armorMaterialComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.armorMaterialComboBox.FormattingEnabled = true;
            this.armorMaterialComboBox.Items.AddRange(new object[] {
            "Cloth",
            "Leather",
            "Mail",
            "Plate",
            "Buckler",
            "Shield"});
            this.armorMaterialComboBox.Location = new System.Drawing.Point(533, 115);
            this.armorMaterialComboBox.Name = "armorMaterialComboBox";
            this.armorMaterialComboBox.Size = new System.Drawing.Size(82, 21);
            this.armorMaterialComboBox.TabIndex = 103;
            // 
            // armorMaterialLabel
            // 
            this.armorMaterialLabel.AutoSize = true;
            this.armorMaterialLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorMaterialLabel.Location = new System.Drawing.Point(467, 118);
            this.armorMaterialLabel.Name = "armorMaterialLabel";
            this.armorMaterialLabel.Size = new System.Drawing.Size(60, 18);
            this.armorMaterialLabel.TabIndex = 102;
            this.armorMaterialLabel.Text = "Material";
            // 
            // armorRequiredLabel
            // 
            this.armorRequiredLabel.AutoSize = true;
            this.armorRequiredLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorRequiredLabel.Location = new System.Drawing.Point(39, 343);
            this.armorRequiredLabel.Name = "armorRequiredLabel";
            this.armorRequiredLabel.Size = new System.Drawing.Size(90, 18);
            this.armorRequiredLabel.TabIndex = 101;
            this.armorRequiredLabel.Text = "* = Required";
            // 
            // armorSearchDisplayIDs
            // 
            this.armorSearchDisplayIDs.Location = new System.Drawing.Point(309, 342);
            this.armorSearchDisplayIDs.Name = "armorSearchDisplayIDs";
            this.armorSearchDisplayIDs.Size = new System.Drawing.Size(148, 23);
            this.armorSearchDisplayIDs.TabIndex = 99;
            this.armorSearchDisplayIDs.Text = "Search For Display IDs";
            this.armorSearchDisplayIDs.UseVisualStyleBackColor = true;
            this.armorSearchDisplayIDs.Click += new System.EventHandler(this.armorSearchDisplayIDs_Click);
            // 
            // armorDetailsNextButton
            // 
            this.armorDetailsNextButton.Location = new System.Drawing.Point(647, 331);
            this.armorDetailsNextButton.Name = "armorDetailsNextButton";
            this.armorDetailsNextButton.Size = new System.Drawing.Size(101, 41);
            this.armorDetailsNextButton.TabIndex = 100;
            this.armorDetailsNextButton.Text = "Next";
            this.armorDetailsNextButton.UseVisualStyleBackColor = true;
            this.armorDetailsNextButton.Click += new System.EventHandler(this.armorDetailsNextButton_Click);
            // 
            // armorBindsComboBox
            // 
            this.armorBindsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.armorBindsComboBox.FormattingEnabled = true;
            this.armorBindsComboBox.Items.AddRange(new object[] {
            "None",
            "On Pickup",
            "On Equip",
            "On Use"});
            this.armorBindsComboBox.Location = new System.Drawing.Point(533, 218);
            this.armorBindsComboBox.Name = "armorBindsComboBox";
            this.armorBindsComboBox.Size = new System.Drawing.Size(82, 21);
            this.armorBindsComboBox.TabIndex = 98;
            // 
            // armorBindsLabel
            // 
            this.armorBindsLabel.AutoSize = true;
            this.armorBindsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorBindsLabel.Location = new System.Drawing.Point(482, 217);
            this.armorBindsLabel.Name = "armorBindsLabel";
            this.armorBindsLabel.Size = new System.Drawing.Size(45, 18);
            this.armorBindsLabel.TabIndex = 97;
            this.armorBindsLabel.Text = "Binds";
            // 
            // armorDurabilityTextBox
            // 
            this.armorDurabilityTextBox.Location = new System.Drawing.Point(533, 170);
            this.armorDurabilityTextBox.Name = "armorDurabilityTextBox";
            this.armorDurabilityTextBox.Size = new System.Drawing.Size(73, 20);
            this.armorDurabilityTextBox.TabIndex = 96;
            this.armorDurabilityTextBox.Text = "0";
            // 
            // armorDurabilityLabel
            // 
            this.armorDurabilityLabel.AutoSize = true;
            this.armorDurabilityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorDurabilityLabel.Location = new System.Drawing.Point(459, 169);
            this.armorDurabilityLabel.Name = "armorDurabilityLabel";
            this.armorDurabilityLabel.Size = new System.Drawing.Size(68, 18);
            this.armorDurabilityLabel.TabIndex = 95;
            this.armorDurabilityLabel.Text = "Durability";
            // 
            // armorEquipComboBox
            // 
            this.armorEquipComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.armorEquipComboBox.FormattingEnabled = true;
            this.armorEquipComboBox.Items.AddRange(new object[] {
            "Head",
            "Shoulders",
            "Shirt",
            "Chest",
            "Waist",
            "Legs",
            "Feet",
            "Wrist",
            "Hands",
            "Back",
            "Tabard",
            "Robe",
            "Shield",
            "Offhand"});
            this.armorEquipComboBox.Location = new System.Drawing.Point(533, 65);
            this.armorEquipComboBox.Name = "armorEquipComboBox";
            this.armorEquipComboBox.Size = new System.Drawing.Size(98, 21);
            this.armorEquipComboBox.TabIndex = 90;
            // 
            // armorEquipLabel
            // 
            this.armorEquipLabel.AutoSize = true;
            this.armorEquipLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorEquipLabel.Location = new System.Drawing.Point(482, 65);
            this.armorEquipLabel.Name = "armorEquipLabel";
            this.armorEquipLabel.Size = new System.Drawing.Size(45, 18);
            this.armorEquipLabel.TabIndex = 89;
            this.armorEquipLabel.Text = "Equip";
            // 
            // armorEntryIDTextBox
            // 
            this.armorEntryIDTextBox.Location = new System.Drawing.Point(126, 244);
            this.armorEntryIDTextBox.Name = "armorEntryIDTextBox";
            this.armorEntryIDTextBox.Size = new System.Drawing.Size(73, 20);
            this.armorEntryIDTextBox.TabIndex = 86;
            // 
            // armorEntryIDLabel
            // 
            this.armorEntryIDLabel.AutoSize = true;
            this.armorEntryIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorEntryIDLabel.Location = new System.Drawing.Point(48, 243);
            this.armorEntryIDLabel.Name = "armorEntryIDLabel";
            this.armorEntryIDLabel.Size = new System.Drawing.Size(70, 18);
            this.armorEntryIDLabel.TabIndex = 88;
            this.armorEntryIDLabel.Text = "* Entry ID";
            // 
            // armorDisplayIDTextBox
            // 
            this.armorDisplayIDTextBox.Location = new System.Drawing.Point(126, 199);
            this.armorDisplayIDTextBox.Name = "armorDisplayIDTextBox";
            this.armorDisplayIDTextBox.Size = new System.Drawing.Size(73, 20);
            this.armorDisplayIDTextBox.TabIndex = 84;
            // 
            // armorDisplayIDLabel
            // 
            this.armorDisplayIDLabel.AutoSize = true;
            this.armorDisplayIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorDisplayIDLabel.Location = new System.Drawing.Point(34, 198);
            this.armorDisplayIDLabel.Name = "armorDisplayIDLabel";
            this.armorDisplayIDLabel.Size = new System.Drawing.Size(84, 18);
            this.armorDisplayIDLabel.TabIndex = 87;
            this.armorDisplayIDLabel.Text = "* Display ID";
            // 
            // armorQualityComboBox
            // 
            this.armorQualityComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.armorQualityComboBox.FormattingEnabled = true;
            this.armorQualityComboBox.Items.AddRange(new object[] {
            "Poor",
            "Common",
            "Uncommon",
            "Rare",
            "Epic",
            "Legendary",
            "Artifact"});
            this.armorQualityComboBox.Location = new System.Drawing.Point(126, 150);
            this.armorQualityComboBox.Name = "armorQualityComboBox";
            this.armorQualityComboBox.Size = new System.Drawing.Size(98, 21);
            this.armorQualityComboBox.TabIndex = 83;
            // 
            // armorQualityLabel
            // 
            this.armorQualityLabel.AutoSize = true;
            this.armorQualityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorQualityLabel.Location = new System.Drawing.Point(67, 149);
            this.armorQualityLabel.Name = "armorQualityLabel";
            this.armorQualityLabel.Size = new System.Drawing.Size(53, 18);
            this.armorQualityLabel.TabIndex = 85;
            this.armorQualityLabel.Text = "Quality";
            // 
            // armorQuoteTextBox
            // 
            this.armorQuoteTextBox.Location = new System.Drawing.Point(126, 100);
            this.armorQuoteTextBox.Name = "armorQuoteTextBox";
            this.armorQuoteTextBox.Size = new System.Drawing.Size(149, 20);
            this.armorQuoteTextBox.TabIndex = 81;
            // 
            // armorQuoteLabel
            // 
            this.armorQuoteLabel.AutoSize = true;
            this.armorQuoteLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorQuoteLabel.Location = new System.Drawing.Point(71, 102);
            this.armorQuoteLabel.Name = "armorQuoteLabel";
            this.armorQuoteLabel.Size = new System.Drawing.Size(49, 18);
            this.armorQuoteLabel.TabIndex = 82;
            this.armorQuoteLabel.Text = "Quote";
            // 
            // armorNameTextBox
            // 
            this.armorNameTextBox.Location = new System.Drawing.Point(126, 46);
            this.armorNameTextBox.Name = "armorNameTextBox";
            this.armorNameTextBox.Size = new System.Drawing.Size(149, 20);
            this.armorNameTextBox.TabIndex = 80;
            // 
            // armorNameLabel
            // 
            this.armorNameLabel.AutoSize = true;
            this.armorNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorNameLabel.Location = new System.Drawing.Point(60, 48);
            this.armorNameLabel.Name = "armorNameLabel";
            this.armorNameLabel.Size = new System.Drawing.Size(58, 18);
            this.armorNameLabel.TabIndex = 79;
            this.armorNameLabel.Text = "* Name";
            // 
            // armorStatsTabPage
            // 
            this.armorStatsTabPage.Controls.Add(this.armorStatsNextButton);
            this.armorStatsTabPage.Controls.Add(this.armorStatsGroupBox);
            this.armorStatsTabPage.Location = new System.Drawing.Point(4, 22);
            this.armorStatsTabPage.Name = "armorStatsTabPage";
            this.armorStatsTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.armorStatsTabPage.Size = new System.Drawing.Size(757, 380);
            this.armorStatsTabPage.TabIndex = 1;
            this.armorStatsTabPage.Text = "Stats";
            this.armorStatsTabPage.UseVisualStyleBackColor = true;
            // 
            // armorStatsNextButton
            // 
            this.armorStatsNextButton.Location = new System.Drawing.Point(647, 331);
            this.armorStatsNextButton.Name = "armorStatsNextButton";
            this.armorStatsNextButton.Size = new System.Drawing.Size(101, 41);
            this.armorStatsNextButton.TabIndex = 101;
            this.armorStatsNextButton.Text = "Next";
            this.armorStatsNextButton.UseVisualStyleBackColor = true;
            this.armorStatsNextButton.Click += new System.EventHandler(this.armorStatsNextButton_Click);
            // 
            // armorStatsGroupBox
            // 
            this.armorStatsGroupBox.Controls.Add(this.armorStatsArmorTextBox);
            this.armorStatsGroupBox.Controls.Add(this.armorStatsArmorLabel);
            this.armorStatsGroupBox.Controls.Add(this.armorStatsBlockTextBox);
            this.armorStatsGroupBox.Controls.Add(this.armorStatsBlockLabel);
            this.armorStatsGroupBox.Location = new System.Drawing.Point(230, 87);
            this.armorStatsGroupBox.Name = "armorStatsGroupBox";
            this.armorStatsGroupBox.Size = new System.Drawing.Size(275, 168);
            this.armorStatsGroupBox.TabIndex = 41;
            this.armorStatsGroupBox.TabStop = false;
            this.armorStatsGroupBox.Text = "Armor Stats";
            // 
            // armorStatsArmorTextBox
            // 
            this.armorStatsArmorTextBox.Location = new System.Drawing.Point(130, 99);
            this.armorStatsArmorTextBox.Name = "armorStatsArmorTextBox";
            this.armorStatsArmorTextBox.Size = new System.Drawing.Size(54, 20);
            this.armorStatsArmorTextBox.TabIndex = 42;
            this.armorStatsArmorTextBox.Text = "0";
            // 
            // armorStatsArmorLabel
            // 
            this.armorStatsArmorLabel.AutoSize = true;
            this.armorStatsArmorLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorStatsArmorLabel.Location = new System.Drawing.Point(74, 98);
            this.armorStatsArmorLabel.Name = "armorStatsArmorLabel";
            this.armorStatsArmorLabel.Size = new System.Drawing.Size(49, 18);
            this.armorStatsArmorLabel.TabIndex = 41;
            this.armorStatsArmorLabel.Text = "Armor";
            // 
            // armorStatsBlockTextBox
            // 
            this.armorStatsBlockTextBox.Location = new System.Drawing.Point(129, 53);
            this.armorStatsBlockTextBox.Name = "armorStatsBlockTextBox";
            this.armorStatsBlockTextBox.Size = new System.Drawing.Size(54, 20);
            this.armorStatsBlockTextBox.TabIndex = 40;
            this.armorStatsBlockTextBox.Text = "0";
            // 
            // armorStatsBlockLabel
            // 
            this.armorStatsBlockLabel.AutoSize = true;
            this.armorStatsBlockLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorStatsBlockLabel.Location = new System.Drawing.Point(77, 52);
            this.armorStatsBlockLabel.Name = "armorStatsBlockLabel";
            this.armorStatsBlockLabel.Size = new System.Drawing.Size(46, 18);
            this.armorStatsBlockLabel.TabIndex = 39;
            this.armorStatsBlockLabel.Text = "Block";
            // 
            // armorRequirementsTabPage
            // 
            this.armorRequirementsTabPage.Controls.Add(this.armorStackableLabel);
            this.armorRequirementsTabPage.Controls.Add(this.armorStackableTextBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorRequirementsNextButton);
            this.armorRequirementsTabPage.Controls.Add(this.armorDraeneiCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorBloodElfCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorTrollCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorTaurenCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorGnomeCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorUndeadCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorNightElfCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorDwarfCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorOrcCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorHumanCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorRaceAllCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorDeathKnightCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorAllowableRaceLabel);
            this.armorRequirementsTabPage.Controls.Add(this.armorWarlockCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorMageCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorShamanCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorDruidCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorPriestCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorRogueCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorHunterCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorPaladinCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorWarriorCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorClassAllCheckBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorAllowableClassLabel);
            this.armorRequirementsTabPage.Controls.Add(this.armorMaxTextBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorMaxLabel);
            this.armorRequirementsTabPage.Controls.Add(this.armorItemLevelTextBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorItemLevelLabel);
            this.armorRequirementsTabPage.Controls.Add(this.armorRequiredLevelTextBox);
            this.armorRequirementsTabPage.Controls.Add(this.armorRequiredLevelLabel);
            this.armorRequirementsTabPage.Location = new System.Drawing.Point(4, 22);
            this.armorRequirementsTabPage.Name = "armorRequirementsTabPage";
            this.armorRequirementsTabPage.Size = new System.Drawing.Size(757, 380);
            this.armorRequirementsTabPage.TabIndex = 2;
            this.armorRequirementsTabPage.Text = "Requirements";
            this.armorRequirementsTabPage.UseVisualStyleBackColor = true;
            // 
            // armorStackableLabel
            // 
            this.armorStackableLabel.AutoSize = true;
            this.armorStackableLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorStackableLabel.Location = new System.Drawing.Point(93, 243);
            this.armorStackableLabel.Name = "armorStackableLabel";
            this.armorStackableLabel.Size = new System.Drawing.Size(73, 18);
            this.armorStackableLabel.TabIndex = 123;
            this.armorStackableLabel.Text = "Stackable";
            // 
            // armorStackableTextBox
            // 
            this.armorStackableTextBox.Location = new System.Drawing.Point(173, 241);
            this.armorStackableTextBox.Name = "armorStackableTextBox";
            this.armorStackableTextBox.Size = new System.Drawing.Size(45, 20);
            this.armorStackableTextBox.TabIndex = 122;
            this.armorStackableTextBox.Text = "0";
            // 
            // armorRequirementsNextButton
            // 
            this.armorRequirementsNextButton.Location = new System.Drawing.Point(648, 331);
            this.armorRequirementsNextButton.Name = "armorRequirementsNextButton";
            this.armorRequirementsNextButton.Size = new System.Drawing.Size(101, 41);
            this.armorRequirementsNextButton.TabIndex = 121;
            this.armorRequirementsNextButton.Text = "Next";
            this.armorRequirementsNextButton.UseVisualStyleBackColor = true;
            this.armorRequirementsNextButton.Click += new System.EventHandler(this.armorRequirementsNextButton_Click);
            // 
            // armorDraeneiCheckBox
            // 
            this.armorDraeneiCheckBox.AutoSize = true;
            this.armorDraeneiCheckBox.Location = new System.Drawing.Point(481, 350);
            this.armorDraeneiCheckBox.Name = "armorDraeneiCheckBox";
            this.armorDraeneiCheckBox.Size = new System.Drawing.Size(63, 17);
            this.armorDraeneiCheckBox.TabIndex = 120;
            this.armorDraeneiCheckBox.Text = "Draenei";
            this.armorDraeneiCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorBloodElfCheckBox
            // 
            this.armorBloodElfCheckBox.AutoSize = true;
            this.armorBloodElfCheckBox.Location = new System.Drawing.Point(546, 321);
            this.armorBloodElfCheckBox.Name = "armorBloodElfCheckBox";
            this.armorBloodElfCheckBox.Size = new System.Drawing.Size(68, 17);
            this.armorBloodElfCheckBox.TabIndex = 119;
            this.armorBloodElfCheckBox.Text = "Blood Elf";
            this.armorBloodElfCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorTrollCheckBox
            // 
            this.armorTrollCheckBox.AutoSize = true;
            this.armorTrollCheckBox.Location = new System.Drawing.Point(481, 321);
            this.armorTrollCheckBox.Name = "armorTrollCheckBox";
            this.armorTrollCheckBox.Size = new System.Drawing.Size(46, 17);
            this.armorTrollCheckBox.TabIndex = 118;
            this.armorTrollCheckBox.Text = "Troll";
            this.armorTrollCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorTaurenCheckBox
            // 
            this.armorTaurenCheckBox.AutoSize = true;
            this.armorTaurenCheckBox.Location = new System.Drawing.Point(546, 290);
            this.armorTaurenCheckBox.Name = "armorTaurenCheckBox";
            this.armorTaurenCheckBox.Size = new System.Drawing.Size(60, 17);
            this.armorTaurenCheckBox.TabIndex = 117;
            this.armorTaurenCheckBox.Text = "Tauren";
            this.armorTaurenCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorGnomeCheckBox
            // 
            this.armorGnomeCheckBox.AutoSize = true;
            this.armorGnomeCheckBox.Location = new System.Drawing.Point(396, 321);
            this.armorGnomeCheckBox.Name = "armorGnomeCheckBox";
            this.armorGnomeCheckBox.Size = new System.Drawing.Size(60, 17);
            this.armorGnomeCheckBox.TabIndex = 116;
            this.armorGnomeCheckBox.Text = "Gnome";
            this.armorGnomeCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorUndeadCheckBox
            // 
            this.armorUndeadCheckBox.AutoSize = true;
            this.armorUndeadCheckBox.Location = new System.Drawing.Point(481, 290);
            this.armorUndeadCheckBox.Name = "armorUndeadCheckBox";
            this.armorUndeadCheckBox.Size = new System.Drawing.Size(64, 17);
            this.armorUndeadCheckBox.TabIndex = 115;
            this.armorUndeadCheckBox.Text = "Undead";
            this.armorUndeadCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorNightElfCheckBox
            // 
            this.armorNightElfCheckBox.AutoSize = true;
            this.armorNightElfCheckBox.Location = new System.Drawing.Point(396, 290);
            this.armorNightElfCheckBox.Name = "armorNightElfCheckBox";
            this.armorNightElfCheckBox.Size = new System.Drawing.Size(66, 17);
            this.armorNightElfCheckBox.TabIndex = 114;
            this.armorNightElfCheckBox.Text = "Night Elf";
            this.armorNightElfCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorDwarfCheckBox
            // 
            this.armorDwarfCheckBox.AutoSize = true;
            this.armorDwarfCheckBox.Location = new System.Drawing.Point(548, 258);
            this.armorDwarfCheckBox.Name = "armorDwarfCheckBox";
            this.armorDwarfCheckBox.Size = new System.Drawing.Size(54, 17);
            this.armorDwarfCheckBox.TabIndex = 113;
            this.armorDwarfCheckBox.Text = "Dwarf";
            this.armorDwarfCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorOrcCheckBox
            // 
            this.armorOrcCheckBox.AutoSize = true;
            this.armorOrcCheckBox.Location = new System.Drawing.Point(481, 258);
            this.armorOrcCheckBox.Name = "armorOrcCheckBox";
            this.armorOrcCheckBox.Size = new System.Drawing.Size(43, 17);
            this.armorOrcCheckBox.TabIndex = 112;
            this.armorOrcCheckBox.Text = "Orc";
            this.armorOrcCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorHumanCheckBox
            // 
            this.armorHumanCheckBox.AutoSize = true;
            this.armorHumanCheckBox.Location = new System.Drawing.Point(396, 258);
            this.armorHumanCheckBox.Name = "armorHumanCheckBox";
            this.armorHumanCheckBox.Size = new System.Drawing.Size(60, 17);
            this.armorHumanCheckBox.TabIndex = 111;
            this.armorHumanCheckBox.Text = "Human";
            this.armorHumanCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorRaceAllCheckBox
            // 
            this.armorRaceAllCheckBox.AutoSize = true;
            this.armorRaceAllCheckBox.Location = new System.Drawing.Point(481, 232);
            this.armorRaceAllCheckBox.Name = "armorRaceAllCheckBox";
            this.armorRaceAllCheckBox.Size = new System.Drawing.Size(37, 17);
            this.armorRaceAllCheckBox.TabIndex = 110;
            this.armorRaceAllCheckBox.Text = "All";
            this.armorRaceAllCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorDeathKnightCheckBox
            // 
            this.armorDeathKnightCheckBox.AutoSize = true;
            this.armorDeathKnightCheckBox.Location = new System.Drawing.Point(462, 175);
            this.armorDeathKnightCheckBox.Name = "armorDeathKnightCheckBox";
            this.armorDeathKnightCheckBox.Size = new System.Drawing.Size(88, 17);
            this.armorDeathKnightCheckBox.TabIndex = 109;
            this.armorDeathKnightCheckBox.Text = "Death Knight";
            this.armorDeathKnightCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorAllowableRaceLabel
            // 
            this.armorAllowableRaceLabel.AutoSize = true;
            this.armorAllowableRaceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorAllowableRaceLabel.Location = new System.Drawing.Point(444, 201);
            this.armorAllowableRaceLabel.Name = "armorAllowableRaceLabel";
            this.armorAllowableRaceLabel.Size = new System.Drawing.Size(109, 18);
            this.armorAllowableRaceLabel.TabIndex = 108;
            this.armorAllowableRaceLabel.Text = "Allowable Race";
            // 
            // armorWarlockCheckBox
            // 
            this.armorWarlockCheckBox.AutoSize = true;
            this.armorWarlockCheckBox.Location = new System.Drawing.Point(546, 141);
            this.armorWarlockCheckBox.Name = "armorWarlockCheckBox";
            this.armorWarlockCheckBox.Size = new System.Drawing.Size(66, 17);
            this.armorWarlockCheckBox.TabIndex = 107;
            this.armorWarlockCheckBox.Text = "Warlock";
            this.armorWarlockCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorMageCheckBox
            // 
            this.armorMageCheckBox.AutoSize = true;
            this.armorMageCheckBox.Location = new System.Drawing.Point(481, 141);
            this.armorMageCheckBox.Name = "armorMageCheckBox";
            this.armorMageCheckBox.Size = new System.Drawing.Size(53, 17);
            this.armorMageCheckBox.TabIndex = 106;
            this.armorMageCheckBox.Text = "Mage";
            this.armorMageCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorShamanCheckBox
            // 
            this.armorShamanCheckBox.AutoSize = true;
            this.armorShamanCheckBox.Location = new System.Drawing.Point(396, 141);
            this.armorShamanCheckBox.Name = "armorShamanCheckBox";
            this.armorShamanCheckBox.Size = new System.Drawing.Size(65, 17);
            this.armorShamanCheckBox.TabIndex = 105;
            this.armorShamanCheckBox.Text = "Shaman";
            this.armorShamanCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorDruidCheckBox
            // 
            this.armorDruidCheckBox.AutoSize = true;
            this.armorDruidCheckBox.Location = new System.Drawing.Point(548, 106);
            this.armorDruidCheckBox.Name = "armorDruidCheckBox";
            this.armorDruidCheckBox.Size = new System.Drawing.Size(51, 17);
            this.armorDruidCheckBox.TabIndex = 104;
            this.armorDruidCheckBox.Text = "Druid";
            this.armorDruidCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorPriestCheckBox
            // 
            this.armorPriestCheckBox.AutoSize = true;
            this.armorPriestCheckBox.Location = new System.Drawing.Point(481, 106);
            this.armorPriestCheckBox.Name = "armorPriestCheckBox";
            this.armorPriestCheckBox.Size = new System.Drawing.Size(52, 17);
            this.armorPriestCheckBox.TabIndex = 103;
            this.armorPriestCheckBox.Text = "Priest";
            this.armorPriestCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorRogueCheckBox
            // 
            this.armorRogueCheckBox.AutoSize = true;
            this.armorRogueCheckBox.Location = new System.Drawing.Point(396, 106);
            this.armorRogueCheckBox.Name = "armorRogueCheckBox";
            this.armorRogueCheckBox.Size = new System.Drawing.Size(58, 17);
            this.armorRogueCheckBox.TabIndex = 102;
            this.armorRogueCheckBox.Text = "Rogue";
            this.armorRogueCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorHunterCheckBox
            // 
            this.armorHunterCheckBox.AutoSize = true;
            this.armorHunterCheckBox.Location = new System.Drawing.Point(548, 71);
            this.armorHunterCheckBox.Name = "armorHunterCheckBox";
            this.armorHunterCheckBox.Size = new System.Drawing.Size(58, 17);
            this.armorHunterCheckBox.TabIndex = 101;
            this.armorHunterCheckBox.Text = "Hunter";
            this.armorHunterCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorPaladinCheckBox
            // 
            this.armorPaladinCheckBox.AutoSize = true;
            this.armorPaladinCheckBox.Location = new System.Drawing.Point(481, 71);
            this.armorPaladinCheckBox.Name = "armorPaladinCheckBox";
            this.armorPaladinCheckBox.Size = new System.Drawing.Size(61, 17);
            this.armorPaladinCheckBox.TabIndex = 100;
            this.armorPaladinCheckBox.Text = "Paladin";
            this.armorPaladinCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorWarriorCheckBox
            // 
            this.armorWarriorCheckBox.AutoSize = true;
            this.armorWarriorCheckBox.Location = new System.Drawing.Point(396, 71);
            this.armorWarriorCheckBox.Name = "armorWarriorCheckBox";
            this.armorWarriorCheckBox.Size = new System.Drawing.Size(60, 17);
            this.armorWarriorCheckBox.TabIndex = 99;
            this.armorWarriorCheckBox.Text = "Warrior";
            this.armorWarriorCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorClassAllCheckBox
            // 
            this.armorClassAllCheckBox.AutoSize = true;
            this.armorClassAllCheckBox.Location = new System.Drawing.Point(481, 42);
            this.armorClassAllCheckBox.Name = "armorClassAllCheckBox";
            this.armorClassAllCheckBox.Size = new System.Drawing.Size(37, 17);
            this.armorClassAllCheckBox.TabIndex = 98;
            this.armorClassAllCheckBox.Text = "All";
            this.armorClassAllCheckBox.UseVisualStyleBackColor = true;
            // 
            // armorAllowableClassLabel
            // 
            this.armorAllowableClassLabel.AutoSize = true;
            this.armorAllowableClassLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorAllowableClassLabel.Location = new System.Drawing.Point(444, 11);
            this.armorAllowableClassLabel.Name = "armorAllowableClassLabel";
            this.armorAllowableClassLabel.Size = new System.Drawing.Size(112, 18);
            this.armorAllowableClassLabel.TabIndex = 97;
            this.armorAllowableClassLabel.Text = "Allowable Class";
            // 
            // armorMaxTextBox
            // 
            this.armorMaxTextBox.Location = new System.Drawing.Point(173, 200);
            this.armorMaxTextBox.Name = "armorMaxTextBox";
            this.armorMaxTextBox.Size = new System.Drawing.Size(45, 20);
            this.armorMaxTextBox.TabIndex = 96;
            this.armorMaxTextBox.Text = "1";
            // 
            // armorMaxLabel
            // 
            this.armorMaxLabel.AutoSize = true;
            this.armorMaxLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorMaxLabel.Location = new System.Drawing.Point(76, 202);
            this.armorMaxLabel.Name = "armorMaxLabel";
            this.armorMaxLabel.Size = new System.Drawing.Size(91, 18);
            this.armorMaxLabel.TabIndex = 95;
            this.armorMaxLabel.Text = "Max Allowed";
            // 
            // armorItemLevelTextBox
            // 
            this.armorItemLevelTextBox.Location = new System.Drawing.Point(173, 153);
            this.armorItemLevelTextBox.Name = "armorItemLevelTextBox";
            this.armorItemLevelTextBox.Size = new System.Drawing.Size(45, 20);
            this.armorItemLevelTextBox.TabIndex = 94;
            this.armorItemLevelTextBox.Text = "0";
            // 
            // armorItemLevelLabel
            // 
            this.armorItemLevelLabel.AutoSize = true;
            this.armorItemLevelLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorItemLevelLabel.Location = new System.Drawing.Point(93, 155);
            this.armorItemLevelLabel.Name = "armorItemLevelLabel";
            this.armorItemLevelLabel.Size = new System.Drawing.Size(74, 18);
            this.armorItemLevelLabel.TabIndex = 93;
            this.armorItemLevelLabel.Text = "Item Level";
            // 
            // armorRequiredLevelTextBox
            // 
            this.armorRequiredLevelTextBox.Location = new System.Drawing.Point(173, 108);
            this.armorRequiredLevelTextBox.Name = "armorRequiredLevelTextBox";
            this.armorRequiredLevelTextBox.Size = new System.Drawing.Size(45, 20);
            this.armorRequiredLevelTextBox.TabIndex = 92;
            this.armorRequiredLevelTextBox.Text = "0";
            // 
            // armorRequiredLevelLabel
            // 
            this.armorRequiredLevelLabel.AutoSize = true;
            this.armorRequiredLevelLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorRequiredLevelLabel.Location = new System.Drawing.Point(62, 108);
            this.armorRequiredLevelLabel.Name = "armorRequiredLevelLabel";
            this.armorRequiredLevelLabel.Size = new System.Drawing.Size(105, 18);
            this.armorRequiredLevelLabel.TabIndex = 91;
            this.armorRequiredLevelLabel.Text = "Required Level";
            // 
            // armorSocketsTabPage
            // 
            this.armorSocketsTabPage.Controls.Add(this.armorBonusLabel);
            this.armorSocketsTabPage.Controls.Add(this.armorBonusComboBox);
            this.armorSocketsTabPage.Controls.Add(this.armorSocket3NoneButton);
            this.armorSocketsTabPage.Controls.Add(this.armorSocket2NoneButton);
            this.armorSocketsTabPage.Controls.Add(this.armorSocket1NoneButton);
            this.armorSocketsTabPage.Controls.Add(this.armorSocketsNextButton);
            this.armorSocketsTabPage.Controls.Add(this.armorSocket3YellowButton);
            this.armorSocketsTabPage.Controls.Add(this.armorSocket3RedButtton);
            this.armorSocketsTabPage.Controls.Add(this.armorSocket3BlueButton);
            this.armorSocketsTabPage.Controls.Add(this.armorSocket3Label);
            this.armorSocketsTabPage.Controls.Add(this.armorSocket2YellowButton);
            this.armorSocketsTabPage.Controls.Add(this.armorSocket2RedButton);
            this.armorSocketsTabPage.Controls.Add(this.armorSocket2BlueButton);
            this.armorSocketsTabPage.Controls.Add(this.armorSocket2Label);
            this.armorSocketsTabPage.Controls.Add(this.armorSocket1YellowButton);
            this.armorSocketsTabPage.Controls.Add(this.armorSocket1RedButton);
            this.armorSocketsTabPage.Controls.Add(this.armorSocket1BlueButton);
            this.armorSocketsTabPage.Controls.Add(this.armorSocket1Label);
            this.armorSocketsTabPage.Location = new System.Drawing.Point(4, 22);
            this.armorSocketsTabPage.Name = "armorSocketsTabPage";
            this.armorSocketsTabPage.Size = new System.Drawing.Size(757, 380);
            this.armorSocketsTabPage.TabIndex = 3;
            this.armorSocketsTabPage.Text = "Sockets";
            this.armorSocketsTabPage.UseVisualStyleBackColor = true;
            // 
            // armorBonusLabel
            // 
            this.armorBonusLabel.AutoSize = true;
            this.armorBonusLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorBonusLabel.Location = new System.Drawing.Point(283, 270);
            this.armorBonusLabel.Name = "armorBonusLabel";
            this.armorBonusLabel.Size = new System.Drawing.Size(51, 18);
            this.armorBonusLabel.TabIndex = 114;
            this.armorBonusLabel.Text = "Bonus";
            // 
            // armorBonusComboBox
            // 
            this.armorBonusComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.armorBonusComboBox.FormattingEnabled = true;
            this.armorBonusComboBox.Items.AddRange(new object[] {
            "None",
            "+4 Agility",
            "+4 Strength",
            "+4 Stamina",
            "+4 Intellect",
            "+4 Spirit",
            "+4 Spell Power",
            "+4 Attack Power",
            "+4 Hit Rating",
            "+4 Critical Strike Rating"});
            this.armorBonusComboBox.Location = new System.Drawing.Point(349, 267);
            this.armorBonusComboBox.Name = "armorBonusComboBox";
            this.armorBonusComboBox.Size = new System.Drawing.Size(121, 21);
            this.armorBonusComboBox.TabIndex = 113;
            // 
            // armorSocket3NoneButton
            // 
            this.armorSocket3NoneButton.Enabled = false;
            this.armorSocket3NoneButton.Location = new System.Drawing.Point(286, 216);
            this.armorSocket3NoneButton.Name = "armorSocket3NoneButton";
            this.armorSocket3NoneButton.Size = new System.Drawing.Size(66, 23);
            this.armorSocket3NoneButton.TabIndex = 112;
            this.armorSocket3NoneButton.Text = "None";
            this.armorSocket3NoneButton.UseVisualStyleBackColor = true;
            this.armorSocket3NoneButton.Click += new System.EventHandler(this.armorSocket3NoneButton_Click);
            // 
            // armorSocket2NoneButton
            // 
            this.armorSocket2NoneButton.Enabled = false;
            this.armorSocket2NoneButton.Location = new System.Drawing.Point(286, 161);
            this.armorSocket2NoneButton.Name = "armorSocket2NoneButton";
            this.armorSocket2NoneButton.Size = new System.Drawing.Size(66, 23);
            this.armorSocket2NoneButton.TabIndex = 111;
            this.armorSocket2NoneButton.Text = "None";
            this.armorSocket2NoneButton.UseVisualStyleBackColor = true;
            this.armorSocket2NoneButton.Click += new System.EventHandler(this.armorSocket2NoneButton_Click);
            // 
            // armorSocket1NoneButton
            // 
            this.armorSocket1NoneButton.Enabled = false;
            this.armorSocket1NoneButton.Location = new System.Drawing.Point(286, 114);
            this.armorSocket1NoneButton.Name = "armorSocket1NoneButton";
            this.armorSocket1NoneButton.Size = new System.Drawing.Size(66, 23);
            this.armorSocket1NoneButton.TabIndex = 110;
            this.armorSocket1NoneButton.Text = "None";
            this.armorSocket1NoneButton.UseVisualStyleBackColor = true;
            this.armorSocket1NoneButton.Click += new System.EventHandler(this.armorSocket1NoneButton_Click);
            // 
            // armorSocketsNextButton
            // 
            this.armorSocketsNextButton.Location = new System.Drawing.Point(648, 331);
            this.armorSocketsNextButton.Name = "armorSocketsNextButton";
            this.armorSocketsNextButton.Size = new System.Drawing.Size(101, 41);
            this.armorSocketsNextButton.TabIndex = 109;
            this.armorSocketsNextButton.Text = "Next";
            this.armorSocketsNextButton.UseVisualStyleBackColor = true;
            this.armorSocketsNextButton.Click += new System.EventHandler(this.armorSocketsNextButton_Click);
            // 
            // armorSocket3YellowButton
            // 
            this.armorSocket3YellowButton.Location = new System.Drawing.Point(479, 215);
            this.armorSocket3YellowButton.Name = "armorSocket3YellowButton";
            this.armorSocket3YellowButton.Size = new System.Drawing.Size(51, 23);
            this.armorSocket3YellowButton.TabIndex = 108;
            this.armorSocket3YellowButton.Text = "Yellow";
            this.armorSocket3YellowButton.UseVisualStyleBackColor = true;
            this.armorSocket3YellowButton.Click += new System.EventHandler(this.armorSocket3YellowButton_Click);
            // 
            // armorSocket3RedButtton
            // 
            this.armorSocket3RedButtton.Location = new System.Drawing.Point(422, 215);
            this.armorSocket3RedButtton.Name = "armorSocket3RedButtton";
            this.armorSocket3RedButtton.Size = new System.Drawing.Size(51, 23);
            this.armorSocket3RedButtton.TabIndex = 107;
            this.armorSocket3RedButtton.Text = "Red";
            this.armorSocket3RedButtton.UseVisualStyleBackColor = true;
            this.armorSocket3RedButtton.Click += new System.EventHandler(this.armorSocket3RedButtton_Click);
            // 
            // armorSocket3BlueButton
            // 
            this.armorSocket3BlueButton.Location = new System.Drawing.Point(365, 215);
            this.armorSocket3BlueButton.Name = "armorSocket3BlueButton";
            this.armorSocket3BlueButton.Size = new System.Drawing.Size(51, 23);
            this.armorSocket3BlueButton.TabIndex = 106;
            this.armorSocket3BlueButton.Text = "Blue";
            this.armorSocket3BlueButton.UseVisualStyleBackColor = true;
            this.armorSocket3BlueButton.Click += new System.EventHandler(this.armorSocket3BlueButton_Click);
            // 
            // armorSocket3Label
            // 
            this.armorSocket3Label.AutoSize = true;
            this.armorSocket3Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorSocket3Label.Location = new System.Drawing.Point(204, 216);
            this.armorSocket3Label.Name = "armorSocket3Label";
            this.armorSocket3Label.Size = new System.Drawing.Size(67, 18);
            this.armorSocket3Label.TabIndex = 105;
            this.armorSocket3Label.Text = "Socket 3";
            // 
            // armorSocket2YellowButton
            // 
            this.armorSocket2YellowButton.Location = new System.Drawing.Point(479, 165);
            this.armorSocket2YellowButton.Name = "armorSocket2YellowButton";
            this.armorSocket2YellowButton.Size = new System.Drawing.Size(51, 23);
            this.armorSocket2YellowButton.TabIndex = 104;
            this.armorSocket2YellowButton.Text = "Yellow";
            this.armorSocket2YellowButton.UseVisualStyleBackColor = true;
            this.armorSocket2YellowButton.Click += new System.EventHandler(this.armorSocket2YellowButton_Click);
            // 
            // armorSocket2RedButton
            // 
            this.armorSocket2RedButton.Location = new System.Drawing.Point(422, 165);
            this.armorSocket2RedButton.Name = "armorSocket2RedButton";
            this.armorSocket2RedButton.Size = new System.Drawing.Size(51, 23);
            this.armorSocket2RedButton.TabIndex = 103;
            this.armorSocket2RedButton.Text = "Red";
            this.armorSocket2RedButton.UseVisualStyleBackColor = true;
            this.armorSocket2RedButton.Click += new System.EventHandler(this.armorSocket2RedButton_Click);
            // 
            // armorSocket2BlueButton
            // 
            this.armorSocket2BlueButton.Location = new System.Drawing.Point(365, 165);
            this.armorSocket2BlueButton.Name = "armorSocket2BlueButton";
            this.armorSocket2BlueButton.Size = new System.Drawing.Size(51, 23);
            this.armorSocket2BlueButton.TabIndex = 102;
            this.armorSocket2BlueButton.Text = "Blue";
            this.armorSocket2BlueButton.UseVisualStyleBackColor = true;
            this.armorSocket2BlueButton.Click += new System.EventHandler(this.armorSocket2BlueButton_Click);
            // 
            // armorSocket2Label
            // 
            this.armorSocket2Label.AutoSize = true;
            this.armorSocket2Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorSocket2Label.Location = new System.Drawing.Point(204, 166);
            this.armorSocket2Label.Name = "armorSocket2Label";
            this.armorSocket2Label.Size = new System.Drawing.Size(67, 18);
            this.armorSocket2Label.TabIndex = 101;
            this.armorSocket2Label.Text = "Socket 2";
            // 
            // armorSocket1YellowButton
            // 
            this.armorSocket1YellowButton.Location = new System.Drawing.Point(479, 114);
            this.armorSocket1YellowButton.Name = "armorSocket1YellowButton";
            this.armorSocket1YellowButton.Size = new System.Drawing.Size(51, 23);
            this.armorSocket1YellowButton.TabIndex = 100;
            this.armorSocket1YellowButton.Text = "Yellow";
            this.armorSocket1YellowButton.UseVisualStyleBackColor = true;
            this.armorSocket1YellowButton.Click += new System.EventHandler(this.armorSocket1YellowButton_Click);
            // 
            // armorSocket1RedButton
            // 
            this.armorSocket1RedButton.Location = new System.Drawing.Point(422, 114);
            this.armorSocket1RedButton.Name = "armorSocket1RedButton";
            this.armorSocket1RedButton.Size = new System.Drawing.Size(51, 23);
            this.armorSocket1RedButton.TabIndex = 99;
            this.armorSocket1RedButton.Text = "Red";
            this.armorSocket1RedButton.UseVisualStyleBackColor = true;
            this.armorSocket1RedButton.Click += new System.EventHandler(this.armorSocket1RedButton_Click);
            // 
            // armorSocket1BlueButton
            // 
            this.armorSocket1BlueButton.Location = new System.Drawing.Point(365, 114);
            this.armorSocket1BlueButton.Name = "armorSocket1BlueButton";
            this.armorSocket1BlueButton.Size = new System.Drawing.Size(51, 23);
            this.armorSocket1BlueButton.TabIndex = 98;
            this.armorSocket1BlueButton.Text = "Blue";
            this.armorSocket1BlueButton.UseVisualStyleBackColor = true;
            this.armorSocket1BlueButton.Click += new System.EventHandler(this.armorSocket1BlueButton_Click);
            // 
            // armorSocket1Label
            // 
            this.armorSocket1Label.AutoSize = true;
            this.armorSocket1Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorSocket1Label.Location = new System.Drawing.Point(204, 115);
            this.armorSocket1Label.Name = "armorSocket1Label";
            this.armorSocket1Label.Size = new System.Drawing.Size(67, 18);
            this.armorSocket1Label.TabIndex = 97;
            this.armorSocket1Label.Text = "Socket 1";
            // 
            // armorPriceTabPage
            // 
            this.armorPriceTabPage.Controls.Add(this.armorSellPriceNextButton);
            this.armorPriceTabPage.Controls.Add(this.armorSellCopperNumericUpDown);
            this.armorPriceTabPage.Controls.Add(this.armorSellSilverNumericUpDown);
            this.armorPriceTabPage.Controls.Add(this.armorBuyCopperNumericUpDown);
            this.armorPriceTabPage.Controls.Add(this.armorBuySilverNumericUpDown);
            this.armorPriceTabPage.Controls.Add(this.armorSellCopperLabel);
            this.armorPriceTabPage.Controls.Add(this.armorSellSilverLabel);
            this.armorPriceTabPage.Controls.Add(this.armorSellGoldLabel);
            this.armorPriceTabPage.Controls.Add(this.armorSellGoldTextBox);
            this.armorPriceTabPage.Controls.Add(this.armorBuyCopperLabel);
            this.armorPriceTabPage.Controls.Add(this.armorBuySilverLabel);
            this.armorPriceTabPage.Controls.Add(this.armorBuyGoldLabel);
            this.armorPriceTabPage.Controls.Add(this.armorSellLabel);
            this.armorPriceTabPage.Controls.Add(this.armorBuyGoldTextBox);
            this.armorPriceTabPage.Controls.Add(this.armorBuyPriceLabel);
            this.armorPriceTabPage.Location = new System.Drawing.Point(4, 22);
            this.armorPriceTabPage.Name = "armorPriceTabPage";
            this.armorPriceTabPage.Size = new System.Drawing.Size(757, 380);
            this.armorPriceTabPage.TabIndex = 4;
            this.armorPriceTabPage.Text = "Price";
            this.armorPriceTabPage.UseVisualStyleBackColor = true;
            // 
            // armorSellPriceNextButton
            // 
            this.armorSellPriceNextButton.Location = new System.Drawing.Point(648, 331);
            this.armorSellPriceNextButton.Name = "armorSellPriceNextButton";
            this.armorSellPriceNextButton.Size = new System.Drawing.Size(101, 41);
            this.armorSellPriceNextButton.TabIndex = 107;
            this.armorSellPriceNextButton.Text = "Next";
            this.armorSellPriceNextButton.UseVisualStyleBackColor = true;
            this.armorSellPriceNextButton.Click += new System.EventHandler(this.armorSellPriceNextButton_Click);
            // 
            // armorSellCopperNumericUpDown
            // 
            this.armorSellCopperNumericUpDown.Location = new System.Drawing.Point(520, 210);
            this.armorSellCopperNumericUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.armorSellCopperNumericUpDown.Name = "armorSellCopperNumericUpDown";
            this.armorSellCopperNumericUpDown.Size = new System.Drawing.Size(45, 20);
            this.armorSellCopperNumericUpDown.TabIndex = 98;
            // 
            // armorSellSilverNumericUpDown
            // 
            this.armorSellSilverNumericUpDown.Location = new System.Drawing.Point(384, 210);
            this.armorSellSilverNumericUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.armorSellSilverNumericUpDown.Name = "armorSellSilverNumericUpDown";
            this.armorSellSilverNumericUpDown.Size = new System.Drawing.Size(45, 20);
            this.armorSellSilverNumericUpDown.TabIndex = 97;
            // 
            // armorBuyCopperNumericUpDown
            // 
            this.armorBuyCopperNumericUpDown.Location = new System.Drawing.Point(520, 146);
            this.armorBuyCopperNumericUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.armorBuyCopperNumericUpDown.Name = "armorBuyCopperNumericUpDown";
            this.armorBuyCopperNumericUpDown.Size = new System.Drawing.Size(45, 20);
            this.armorBuyCopperNumericUpDown.TabIndex = 95;
            // 
            // armorBuySilverNumericUpDown
            // 
            this.armorBuySilverNumericUpDown.Location = new System.Drawing.Point(384, 147);
            this.armorBuySilverNumericUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.armorBuySilverNumericUpDown.Name = "armorBuySilverNumericUpDown";
            this.armorBuySilverNumericUpDown.Size = new System.Drawing.Size(45, 20);
            this.armorBuySilverNumericUpDown.TabIndex = 94;
            // 
            // armorSellCopperLabel
            // 
            this.armorSellCopperLabel.AutoSize = true;
            this.armorSellCopperLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorSellCopperLabel.Location = new System.Drawing.Point(571, 208);
            this.armorSellCopperLabel.Name = "armorSellCopperLabel";
            this.armorSellCopperLabel.Size = new System.Drawing.Size(57, 18);
            this.armorSellCopperLabel.TabIndex = 106;
            this.armorSellCopperLabel.Text = "Copper";
            // 
            // armorSellSilverLabel
            // 
            this.armorSellSilverLabel.AutoSize = true;
            this.armorSellSilverLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorSellSilverLabel.Location = new System.Drawing.Point(435, 208);
            this.armorSellSilverLabel.Name = "armorSellSilverLabel";
            this.armorSellSilverLabel.Size = new System.Drawing.Size(44, 18);
            this.armorSellSilverLabel.TabIndex = 105;
            this.armorSellSilverLabel.Text = "Silver";
            // 
            // armorSellGoldLabel
            // 
            this.armorSellGoldLabel.AutoSize = true;
            this.armorSellGoldLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorSellGoldLabel.Location = new System.Drawing.Point(312, 208);
            this.armorSellGoldLabel.Name = "armorSellGoldLabel";
            this.armorSellGoldLabel.Size = new System.Drawing.Size(40, 18);
            this.armorSellGoldLabel.TabIndex = 104;
            this.armorSellGoldLabel.Text = "Gold";
            // 
            // armorSellGoldTextBox
            // 
            this.armorSellGoldTextBox.Location = new System.Drawing.Point(255, 206);
            this.armorSellGoldTextBox.Name = "armorSellGoldTextBox";
            this.armorSellGoldTextBox.Size = new System.Drawing.Size(41, 20);
            this.armorSellGoldTextBox.TabIndex = 96;
            this.armorSellGoldTextBox.Text = "0";
            // 
            // armorBuyCopperLabel
            // 
            this.armorBuyCopperLabel.AutoSize = true;
            this.armorBuyCopperLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorBuyCopperLabel.Location = new System.Drawing.Point(571, 148);
            this.armorBuyCopperLabel.Name = "armorBuyCopperLabel";
            this.armorBuyCopperLabel.Size = new System.Drawing.Size(57, 18);
            this.armorBuyCopperLabel.TabIndex = 103;
            this.armorBuyCopperLabel.Text = "Copper";
            // 
            // armorBuySilverLabel
            // 
            this.armorBuySilverLabel.AutoSize = true;
            this.armorBuySilverLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorBuySilverLabel.Location = new System.Drawing.Point(435, 148);
            this.armorBuySilverLabel.Name = "armorBuySilverLabel";
            this.armorBuySilverLabel.Size = new System.Drawing.Size(44, 18);
            this.armorBuySilverLabel.TabIndex = 102;
            this.armorBuySilverLabel.Text = "Silver";
            // 
            // armorBuyGoldLabel
            // 
            this.armorBuyGoldLabel.AutoSize = true;
            this.armorBuyGoldLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorBuyGoldLabel.Location = new System.Drawing.Point(312, 148);
            this.armorBuyGoldLabel.Name = "armorBuyGoldLabel";
            this.armorBuyGoldLabel.Size = new System.Drawing.Size(40, 18);
            this.armorBuyGoldLabel.TabIndex = 101;
            this.armorBuyGoldLabel.Text = "Gold";
            // 
            // armorSellLabel
            // 
            this.armorSellLabel.AutoSize = true;
            this.armorSellLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorSellLabel.Location = new System.Drawing.Point(131, 208);
            this.armorSellLabel.Name = "armorSellLabel";
            this.armorSellLabel.Size = new System.Drawing.Size(70, 18);
            this.armorSellLabel.TabIndex = 100;
            this.armorSellLabel.Text = "Sell Price";
            // 
            // armorBuyGoldTextBox
            // 
            this.armorBuyGoldTextBox.Location = new System.Drawing.Point(255, 146);
            this.armorBuyGoldTextBox.Name = "armorBuyGoldTextBox";
            this.armorBuyGoldTextBox.Size = new System.Drawing.Size(41, 20);
            this.armorBuyGoldTextBox.TabIndex = 93;
            this.armorBuyGoldTextBox.Text = "0";
            // 
            // armorBuyPriceLabel
            // 
            this.armorBuyPriceLabel.AutoSize = true;
            this.armorBuyPriceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorBuyPriceLabel.Location = new System.Drawing.Point(131, 146);
            this.armorBuyPriceLabel.Name = "armorBuyPriceLabel";
            this.armorBuyPriceLabel.Size = new System.Drawing.Size(71, 18);
            this.armorBuyPriceLabel.TabIndex = 99;
            this.armorBuyPriceLabel.Text = "Buy Price";
            // 
            // armorFinishTabPage
            // 
            this.armorFinishTabPage.Controls.Add(this.armorSaveToSQLButton);
            this.armorFinishTabPage.Controls.Add(this.armorSaveToDBButton);
            this.armorFinishTabPage.Controls.Add(this.armorStartOverButton);
            this.armorFinishTabPage.Location = new System.Drawing.Point(4, 22);
            this.armorFinishTabPage.Name = "armorFinishTabPage";
            this.armorFinishTabPage.Size = new System.Drawing.Size(757, 380);
            this.armorFinishTabPage.TabIndex = 5;
            this.armorFinishTabPage.Text = "Finish";
            this.armorFinishTabPage.UseVisualStyleBackColor = true;
            // 
            // armorSaveToSQLButton
            // 
            this.armorSaveToSQLButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorSaveToSQLButton.Location = new System.Drawing.Point(281, 221);
            this.armorSaveToSQLButton.Name = "armorSaveToSQLButton";
            this.armorSaveToSQLButton.Size = new System.Drawing.Size(208, 74);
            this.armorSaveToSQLButton.TabIndex = 13;
            this.armorSaveToSQLButton.Text = "Save To SQL File";
            this.armorSaveToSQLButton.UseVisualStyleBackColor = true;
            this.armorSaveToSQLButton.Click += new System.EventHandler(this.armorSaveToSQLButton_Click);
            // 
            // armorSaveToDBButton
            // 
            this.armorSaveToDBButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorSaveToDBButton.Location = new System.Drawing.Point(453, 85);
            this.armorSaveToDBButton.Name = "armorSaveToDBButton";
            this.armorSaveToDBButton.Size = new System.Drawing.Size(208, 74);
            this.armorSaveToDBButton.TabIndex = 12;
            this.armorSaveToDBButton.Text = "Save To Database";
            this.armorSaveToDBButton.UseVisualStyleBackColor = true;
            this.armorSaveToDBButton.Click += new System.EventHandler(this.armorSaveToDBButton_Click);
            // 
            // armorStartOverButton
            // 
            this.armorStartOverButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.armorStartOverButton.Location = new System.Drawing.Point(95, 85);
            this.armorStartOverButton.Name = "armorStartOverButton";
            this.armorStartOverButton.Size = new System.Drawing.Size(208, 74);
            this.armorStartOverButton.TabIndex = 11;
            this.armorStartOverButton.Text = "Start Over";
            this.armorStartOverButton.UseVisualStyleBackColor = true;
            this.armorStartOverButton.Click += new System.EventHandler(this.armorStartOverButton_Click);
            // 
            // npcTabPage
            // 
            this.npcTabPage.Controls.Add(this.npcTabControl);
            this.npcTabPage.Location = new System.Drawing.Point(4, 22);
            this.npcTabPage.Name = "npcTabPage";
            this.npcTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.npcTabPage.Size = new System.Drawing.Size(760, 402);
            this.npcTabPage.TabIndex = 0;
            this.npcTabPage.Text = "NPC";
            this.npcTabPage.UseVisualStyleBackColor = true;
            // 
            // npcTabControl
            // 
            this.npcTabControl.Controls.Add(this.npcDetailsTabPage);
            this.npcTabControl.Controls.Add(this.npcBehaviorTabPage);
            this.npcTabControl.Controls.Add(this.npcStatsTabPage);
            this.npcTabControl.Controls.Add(this.npcResistsTabPage);
            this.npcTabControl.Controls.Add(this.npcOptionsTabPage);
            this.npcTabControl.Controls.Add(this.npcLootTabPage);
            this.npcTabControl.Controls.Add(this.npcFinishTabPage);
            this.npcTabControl.Location = new System.Drawing.Point(0, 0);
            this.npcTabControl.Name = "npcTabControl";
            this.npcTabControl.SelectedIndex = 0;
            this.npcTabControl.Size = new System.Drawing.Size(764, 406);
            this.npcTabControl.TabIndex = 0;
            // 
            // npcDetailsTabPage
            // 
            this.npcDetailsTabPage.Controls.Add(this.npcDetailsRequiredLabel);
            this.npcDetailsTabPage.Controls.Add(this.npcSearchDisplayIDs);
            this.npcDetailsTabPage.Controls.Add(this.npcBossLabel);
            this.npcDetailsTabPage.Controls.Add(this.groupBox1);
            this.npcDetailsTabPage.Controls.Add(this.npcTypeComboBox);
            this.npcDetailsTabPage.Controls.Add(this.npcTypeLabel);
            this.npcDetailsTabPage.Controls.Add(this.npcFactionComboBox);
            this.npcDetailsTabPage.Controls.Add(this.npcFactionLabel);
            this.npcDetailsTabPage.Controls.Add(this.npcEntryIDTextBox);
            this.npcDetailsTabPage.Controls.Add(this.npcEntryidLabel);
            this.npcDetailsTabPage.Controls.Add(this.npcDetailsNextButton);
            this.npcDetailsTabPage.Controls.Add(this.npcDisplayidTextBox);
            this.npcDetailsTabPage.Controls.Add(this.npcDisplayidLabel);
            this.npcDetailsTabPage.Controls.Add(this.npcRankComboBox);
            this.npcDetailsTabPage.Controls.Add(this.npcRankLabel);
            this.npcDetailsTabPage.Controls.Add(this.npcSubnameTextbox);
            this.npcDetailsTabPage.Controls.Add(this.npcSubnameLabel);
            this.npcDetailsTabPage.Controls.Add(this.npcNameTextBox);
            this.npcDetailsTabPage.Controls.Add(this.npcNameLabel);
            this.npcDetailsTabPage.Location = new System.Drawing.Point(4, 22);
            this.npcDetailsTabPage.Name = "npcDetailsTabPage";
            this.npcDetailsTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.npcDetailsTabPage.Size = new System.Drawing.Size(756, 380);
            this.npcDetailsTabPage.TabIndex = 0;
            this.npcDetailsTabPage.Text = "Details";
            this.npcDetailsTabPage.UseVisualStyleBackColor = true;
            // 
            // npcDetailsRequiredLabel
            // 
            this.npcDetailsRequiredLabel.AutoSize = true;
            this.npcDetailsRequiredLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcDetailsRequiredLabel.Location = new System.Drawing.Point(39, 343);
            this.npcDetailsRequiredLabel.Name = "npcDetailsRequiredLabel";
            this.npcDetailsRequiredLabel.Size = new System.Drawing.Size(90, 18);
            this.npcDetailsRequiredLabel.TabIndex = 33;
            this.npcDetailsRequiredLabel.Text = "* = Required";
            // 
            // npcSearchDisplayIDs
            // 
            this.npcSearchDisplayIDs.Location = new System.Drawing.Point(309, 342);
            this.npcSearchDisplayIDs.Name = "npcSearchDisplayIDs";
            this.npcSearchDisplayIDs.Size = new System.Drawing.Size(148, 23);
            this.npcSearchDisplayIDs.TabIndex = 10;
            this.npcSearchDisplayIDs.Text = "Search For Display IDs";
            this.npcSearchDisplayIDs.UseVisualStyleBackColor = true;
            this.npcSearchDisplayIDs.Click += new System.EventHandler(this.npcSearchDisplayIDs_Click);
            // 
            // npcBossLabel
            // 
            this.npcBossLabel.AutoSize = true;
            this.npcBossLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcBossLabel.Location = new System.Drawing.Point(460, 161);
            this.npcBossLabel.Name = "npcBossLabel";
            this.npcBossLabel.Size = new System.Drawing.Size(43, 18);
            this.npcBossLabel.TabIndex = 31;
            this.npcBossLabel.Text = "Boss";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.npcBossNoRadioButton);
            this.groupBox1.Controls.Add(this.npcBossYesRadioButton);
            this.groupBox1.Location = new System.Drawing.Point(509, 149);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(141, 40);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            // 
            // npcBossNoRadioButton
            // 
            this.npcBossNoRadioButton.AutoSize = true;
            this.npcBossNoRadioButton.Checked = true;
            this.npcBossNoRadioButton.Location = new System.Drawing.Point(85, 14);
            this.npcBossNoRadioButton.Name = "npcBossNoRadioButton";
            this.npcBossNoRadioButton.Size = new System.Drawing.Size(39, 17);
            this.npcBossNoRadioButton.TabIndex = 1;
            this.npcBossNoRadioButton.TabStop = true;
            this.npcBossNoRadioButton.Text = "No";
            this.npcBossNoRadioButton.UseVisualStyleBackColor = true;
            // 
            // npcBossYesRadioButton
            // 
            this.npcBossYesRadioButton.AutoSize = true;
            this.npcBossYesRadioButton.Location = new System.Drawing.Point(19, 14);
            this.npcBossYesRadioButton.Name = "npcBossYesRadioButton";
            this.npcBossYesRadioButton.Size = new System.Drawing.Size(43, 17);
            this.npcBossYesRadioButton.TabIndex = 0;
            this.npcBossYesRadioButton.Text = "Yes";
            this.npcBossYesRadioButton.UseVisualStyleBackColor = true;
            // 
            // npcTypeComboBox
            // 
            this.npcTypeComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.npcTypeComboBox.FormattingEnabled = true;
            this.npcTypeComboBox.Items.AddRange(new object[] {
            "None",
            "Beast",
            "Dragonkin",
            "Demon",
            "Elemental",
            "Giant",
            "Undead",
            "Humanoid",
            "Critter",
            "Mechanical",
            "Totem",
            "Gas Cloud",
            "Non-Combat Pet"});
            this.npcTypeComboBox.Location = new System.Drawing.Point(509, 101);
            this.npcTypeComboBox.Name = "npcTypeComboBox";
            this.npcTypeComboBox.Size = new System.Drawing.Size(128, 21);
            this.npcTypeComboBox.TabIndex = 7;
            // 
            // npcTypeLabel
            // 
            this.npcTypeLabel.AutoSize = true;
            this.npcTypeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcTypeLabel.Location = new System.Drawing.Point(463, 101);
            this.npcTypeLabel.Name = "npcTypeLabel";
            this.npcTypeLabel.Size = new System.Drawing.Size(40, 18);
            this.npcTypeLabel.TabIndex = 26;
            this.npcTypeLabel.Text = "Type";
            // 
            // npcFactionComboBox
            // 
            this.npcFactionComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.npcFactionComboBox.FormattingEnabled = true;
            this.npcFactionComboBox.Items.AddRange(new object[] {
            "Neutral",
            "Hostile",
            "Friendly"});
            this.npcFactionComboBox.Location = new System.Drawing.Point(509, 55);
            this.npcFactionComboBox.Name = "npcFactionComboBox";
            this.npcFactionComboBox.Size = new System.Drawing.Size(90, 21);
            this.npcFactionComboBox.TabIndex = 6;
            // 
            // npcFactionLabel
            // 
            this.npcFactionLabel.AutoSize = true;
            this.npcFactionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcFactionLabel.Location = new System.Drawing.Point(446, 54);
            this.npcFactionLabel.Name = "npcFactionLabel";
            this.npcFactionLabel.Size = new System.Drawing.Size(57, 18);
            this.npcFactionLabel.TabIndex = 24;
            this.npcFactionLabel.Text = "Faction";
            // 
            // npcEntryIDTextBox
            // 
            this.npcEntryIDTextBox.Location = new System.Drawing.Point(130, 250);
            this.npcEntryIDTextBox.Name = "npcEntryIDTextBox";
            this.npcEntryIDTextBox.Size = new System.Drawing.Size(90, 20);
            this.npcEntryIDTextBox.TabIndex = 5;
            // 
            // npcEntryidLabel
            // 
            this.npcEntryidLabel.AutoSize = true;
            this.npcEntryidLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcEntryidLabel.Location = new System.Drawing.Point(31, 252);
            this.npcEntryidLabel.Name = "npcEntryidLabel";
            this.npcEntryidLabel.Size = new System.Drawing.Size(74, 18);
            this.npcEntryidLabel.TabIndex = 19;
            this.npcEntryidLabel.Text = "* Entry ID:";
            // 
            // npcDetailsNextButton
            // 
            this.npcDetailsNextButton.Location = new System.Drawing.Point(647, 331);
            this.npcDetailsNextButton.Name = "npcDetailsNextButton";
            this.npcDetailsNextButton.Size = new System.Drawing.Size(101, 41);
            this.npcDetailsNextButton.TabIndex = 11;
            this.npcDetailsNextButton.Text = "Next";
            this.npcDetailsNextButton.UseVisualStyleBackColor = true;
            this.npcDetailsNextButton.Click += new System.EventHandler(this.npcDetailsNextButton_Click);
            // 
            // npcDisplayidTextBox
            // 
            this.npcDisplayidTextBox.Location = new System.Drawing.Point(130, 203);
            this.npcDisplayidTextBox.Name = "npcDisplayidTextBox";
            this.npcDisplayidTextBox.Size = new System.Drawing.Size(90, 20);
            this.npcDisplayidTextBox.TabIndex = 4;
            // 
            // npcDisplayidLabel
            // 
            this.npcDisplayidLabel.AutoSize = true;
            this.npcDisplayidLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcDisplayidLabel.Location = new System.Drawing.Point(17, 205);
            this.npcDisplayidLabel.Name = "npcDisplayidLabel";
            this.npcDisplayidLabel.Size = new System.Drawing.Size(88, 18);
            this.npcDisplayidLabel.TabIndex = 16;
            this.npcDisplayidLabel.Text = "* Display ID:";
            // 
            // npcRankComboBox
            // 
            this.npcRankComboBox.DisplayMember = "0";
            this.npcRankComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.npcRankComboBox.FormattingEnabled = true;
            this.npcRankComboBox.Items.AddRange(new object[] {
            "Normal",
            "Elite",
            "Rare Elite",
            "World Boss",
            "Rare"});
            this.npcRankComboBox.Location = new System.Drawing.Point(125, 158);
            this.npcRankComboBox.Name = "npcRankComboBox";
            this.npcRankComboBox.Size = new System.Drawing.Size(90, 21);
            this.npcRankComboBox.TabIndex = 3;
            // 
            // npcRankLabel
            // 
            this.npcRankLabel.AutoSize = true;
            this.npcRankLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcRankLabel.Location = new System.Drawing.Point(58, 161);
            this.npcRankLabel.Name = "npcRankLabel";
            this.npcRankLabel.Size = new System.Drawing.Size(47, 18);
            this.npcRankLabel.TabIndex = 14;
            this.npcRankLabel.Text = "Rank:";
            // 
            // npcSubnameTextbox
            // 
            this.npcSubnameTextbox.Location = new System.Drawing.Point(125, 113);
            this.npcSubnameTextbox.Name = "npcSubnameTextbox";
            this.npcSubnameTextbox.Size = new System.Drawing.Size(145, 20);
            this.npcSubnameTextbox.TabIndex = 2;
            // 
            // npcSubnameLabel
            // 
            this.npcSubnameLabel.AutoSize = true;
            this.npcSubnameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcSubnameLabel.Location = new System.Drawing.Point(35, 112);
            this.npcSubnameLabel.Name = "npcSubnameLabel";
            this.npcSubnameLabel.Size = new System.Drawing.Size(75, 18);
            this.npcSubnameLabel.TabIndex = 12;
            this.npcSubnameLabel.Text = "Subname:";
            // 
            // npcNameTextBox
            // 
            this.npcNameTextBox.Location = new System.Drawing.Point(125, 55);
            this.npcNameTextBox.Name = "npcNameTextBox";
            this.npcNameTextBox.Size = new System.Drawing.Size(145, 20);
            this.npcNameTextBox.TabIndex = 1;
            // 
            // npcNameLabel
            // 
            this.npcNameLabel.AutoSize = true;
            this.npcNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcNameLabel.Location = new System.Drawing.Point(43, 57);
            this.npcNameLabel.Name = "npcNameLabel";
            this.npcNameLabel.Size = new System.Drawing.Size(62, 18);
            this.npcNameLabel.TabIndex = 10;
            this.npcNameLabel.Text = "* Name:";
            // 
            // npcBehaviorTabPage
            // 
            this.npcBehaviorTabPage.Controls.Add(this.npcModelSizeNumericUpDown);
            this.npcBehaviorTabPage.Controls.Add(this.npcBehaviorNextButton);
            this.npcBehaviorTabPage.Controls.Add(this.npcModeLSizeLabel);
            this.npcBehaviorTabPage.Controls.Add(this.groupBox2);
            this.npcBehaviorTabPage.Location = new System.Drawing.Point(4, 22);
            this.npcBehaviorTabPage.Name = "npcBehaviorTabPage";
            this.npcBehaviorTabPage.Size = new System.Drawing.Size(756, 380);
            this.npcBehaviorTabPage.TabIndex = 1;
            this.npcBehaviorTabPage.Text = "Behavior";
            this.npcBehaviorTabPage.UseVisualStyleBackColor = true;
            // 
            // npcModelSizeNumericUpDown
            // 
            this.npcModelSizeNumericUpDown.DecimalPlaces = 2;
            this.npcModelSizeNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.npcModelSizeNumericUpDown.Location = new System.Drawing.Point(407, 105);
            this.npcModelSizeNumericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.npcModelSizeNumericUpDown.Name = "npcModelSizeNumericUpDown";
            this.npcModelSizeNumericUpDown.Size = new System.Drawing.Size(60, 20);
            this.npcModelSizeNumericUpDown.TabIndex = 20;
            this.npcModelSizeNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // npcBehaviorNextButton
            // 
            this.npcBehaviorNextButton.Location = new System.Drawing.Point(647, 331);
            this.npcBehaviorNextButton.Name = "npcBehaviorNextButton";
            this.npcBehaviorNextButton.Size = new System.Drawing.Size(101, 41);
            this.npcBehaviorNextButton.TabIndex = 19;
            this.npcBehaviorNextButton.Text = "Next";
            this.npcBehaviorNextButton.UseVisualStyleBackColor = true;
            this.npcBehaviorNextButton.Click += new System.EventHandler(this.npcBehaviorNextButton_Click);
            // 
            // npcModeLSizeLabel
            // 
            this.npcModeLSizeLabel.AutoSize = true;
            this.npcModeLSizeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcModeLSizeLabel.Location = new System.Drawing.Point(298, 105);
            this.npcModeLSizeLabel.Name = "npcModeLSizeLabel";
            this.npcModeLSizeLabel.Size = new System.Drawing.Size(82, 18);
            this.npcModeLSizeLabel.TabIndex = 11;
            this.npcModeLSizeLabel.Text = "Model Size";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.npcSecondsLabel);
            this.groupBox2.Controls.Add(this.npcHoursLabel);
            this.groupBox2.Controls.Add(this.npcMinutesLabel);
            this.groupBox2.Controls.Add(this.npcMinutesNumericUpDown);
            this.groupBox2.Controls.Add(this.npcSecondsNumericUpDown);
            this.groupBox2.Controls.Add(this.npcHoursTextBox);
            this.groupBox2.Location = new System.Drawing.Point(134, 180);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(501, 104);
            this.groupBox2.TabIndex = 33;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Respawn Timer";
            // 
            // npcSecondsLabel
            // 
            this.npcSecondsLabel.AutoSize = true;
            this.npcSecondsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcSecondsLabel.Location = new System.Drawing.Point(432, 44);
            this.npcSecondsLabel.Name = "npcSecondsLabel";
            this.npcSecondsLabel.Size = new System.Drawing.Size(67, 18);
            this.npcSecondsLabel.TabIndex = 32;
            this.npcSecondsLabel.Text = "Seconds";
            // 
            // npcHoursLabel
            // 
            this.npcHoursLabel.AutoSize = true;
            this.npcHoursLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcHoursLabel.Location = new System.Drawing.Point(91, 44);
            this.npcHoursLabel.Name = "npcHoursLabel";
            this.npcHoursLabel.Size = new System.Drawing.Size(49, 18);
            this.npcHoursLabel.TabIndex = 30;
            this.npcHoursLabel.Text = "Hours";
            // 
            // npcMinutesLabel
            // 
            this.npcMinutesLabel.AutoSize = true;
            this.npcMinutesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcMinutesLabel.Location = new System.Drawing.Point(263, 44);
            this.npcMinutesLabel.Name = "npcMinutesLabel";
            this.npcMinutesLabel.Size = new System.Drawing.Size(60, 18);
            this.npcMinutesLabel.TabIndex = 31;
            this.npcMinutesLabel.Text = "Minutes";
            // 
            // npcMinutesNumericUpDown
            // 
            this.npcMinutesNumericUpDown.Location = new System.Drawing.Point(189, 42);
            this.npcMinutesNumericUpDown.Name = "npcMinutesNumericUpDown";
            this.npcMinutesNumericUpDown.Size = new System.Drawing.Size(57, 20);
            this.npcMinutesNumericUpDown.TabIndex = 27;
            // 
            // npcSecondsNumericUpDown
            // 
            this.npcSecondsNumericUpDown.Location = new System.Drawing.Point(356, 42);
            this.npcSecondsNumericUpDown.Name = "npcSecondsNumericUpDown";
            this.npcSecondsNumericUpDown.Size = new System.Drawing.Size(57, 20);
            this.npcSecondsNumericUpDown.TabIndex = 28;
            // 
            // npcHoursTextBox
            // 
            this.npcHoursTextBox.Location = new System.Drawing.Point(28, 42);
            this.npcHoursTextBox.Name = "npcHoursTextBox";
            this.npcHoursTextBox.Size = new System.Drawing.Size(57, 20);
            this.npcHoursTextBox.TabIndex = 29;
            this.npcHoursTextBox.Text = "0";
            // 
            // npcStatsTabPage
            // 
            this.npcStatsTabPage.Controls.Add(this.npcStatsNextButton);
            this.npcStatsTabPage.Controls.Add(this.npcMaxDamageTextBox);
            this.npcStatsTabPage.Controls.Add(this.npcMaxDamageLabel);
            this.npcStatsTabPage.Controls.Add(this.npcMinDamageTextBox);
            this.npcStatsTabPage.Controls.Add(this.npcMinDamageLabel);
            this.npcStatsTabPage.Controls.Add(this.npcStatsGroupBox);
            this.npcStatsTabPage.Controls.Add(this.npcAttackStatsGroupBox);
            this.npcStatsTabPage.Location = new System.Drawing.Point(4, 22);
            this.npcStatsTabPage.Name = "npcStatsTabPage";
            this.npcStatsTabPage.Size = new System.Drawing.Size(756, 380);
            this.npcStatsTabPage.TabIndex = 2;
            this.npcStatsTabPage.Text = "Stats";
            this.npcStatsTabPage.UseVisualStyleBackColor = true;
            // 
            // npcStatsNextButton
            // 
            this.npcStatsNextButton.Location = new System.Drawing.Point(647, 331);
            this.npcStatsNextButton.Name = "npcStatsNextButton";
            this.npcStatsNextButton.Size = new System.Drawing.Size(101, 41);
            this.npcStatsNextButton.TabIndex = 30;
            this.npcStatsNextButton.Text = "Next";
            this.npcStatsNextButton.UseVisualStyleBackColor = true;
            this.npcStatsNextButton.Click += new System.EventHandler(this.npcStatsNextButton_Click);
            // 
            // npcMaxDamageTextBox
            // 
            this.npcMaxDamageTextBox.Location = new System.Drawing.Point(565, 111);
            this.npcMaxDamageTextBox.Name = "npcMaxDamageTextBox";
            this.npcMaxDamageTextBox.Size = new System.Drawing.Size(69, 20);
            this.npcMaxDamageTextBox.TabIndex = 27;
            this.npcMaxDamageTextBox.Text = "0";
            // 
            // npcMaxDamageLabel
            // 
            this.npcMaxDamageLabel.AutoSize = true;
            this.npcMaxDamageLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcMaxDamageLabel.Location = new System.Drawing.Point(440, 110);
            this.npcMaxDamageLabel.Name = "npcMaxDamageLabel";
            this.npcMaxDamageLabel.Size = new System.Drawing.Size(96, 18);
            this.npcMaxDamageLabel.TabIndex = 26;
            this.npcMaxDamageLabel.Text = "Max Damage";
            // 
            // npcMinDamageTextBox
            // 
            this.npcMinDamageTextBox.Location = new System.Drawing.Point(565, 59);
            this.npcMinDamageTextBox.Name = "npcMinDamageTextBox";
            this.npcMinDamageTextBox.Size = new System.Drawing.Size(69, 20);
            this.npcMinDamageTextBox.TabIndex = 25;
            this.npcMinDamageTextBox.Text = "0";
            // 
            // npcMinDamageLabel
            // 
            this.npcMinDamageLabel.AutoSize = true;
            this.npcMinDamageLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcMinDamageLabel.Location = new System.Drawing.Point(444, 58);
            this.npcMinDamageLabel.Name = "npcMinDamageLabel";
            this.npcMinDamageLabel.Size = new System.Drawing.Size(92, 18);
            this.npcMinDamageLabel.TabIndex = 24;
            this.npcMinDamageLabel.Text = "Min Damage";
            // 
            // npcStatsGroupBox
            // 
            this.npcStatsGroupBox.Controls.Add(this.npcArmorLabel);
            this.npcStatsGroupBox.Controls.Add(this.npcManaLabel);
            this.npcStatsGroupBox.Controls.Add(this.npcMinHealthLevel);
            this.npcStatsGroupBox.Controls.Add(this.npcMaxHealthLabel);
            this.npcStatsGroupBox.Controls.Add(this.npcMinLevelLabel);
            this.npcStatsGroupBox.Controls.Add(this.npcMaxLevelTextBox);
            this.npcStatsGroupBox.Controls.Add(this.npcMaxLevelLabel);
            this.npcStatsGroupBox.Controls.Add(this.npcMinLevelTextBox);
            this.npcStatsGroupBox.Controls.Add(this.npcArmorTextBox);
            this.npcStatsGroupBox.Controls.Add(this.npcMaxHealthTextBox);
            this.npcStatsGroupBox.Controls.Add(this.npcManaTextBox);
            this.npcStatsGroupBox.Controls.Add(this.npcMinHealthTextBox);
            this.npcStatsGroupBox.Location = new System.Drawing.Point(29, 27);
            this.npcStatsGroupBox.Name = "npcStatsGroupBox";
            this.npcStatsGroupBox.Size = new System.Drawing.Size(199, 306);
            this.npcStatsGroupBox.TabIndex = 31;
            this.npcStatsGroupBox.TabStop = false;
            this.npcStatsGroupBox.Text = "Stats";
            // 
            // npcArmorLabel
            // 
            this.npcArmorLabel.AutoSize = true;
            this.npcArmorLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcArmorLabel.Location = new System.Drawing.Point(41, 31);
            this.npcArmorLabel.Name = "npcArmorLabel";
            this.npcArmorLabel.Size = new System.Drawing.Size(49, 18);
            this.npcArmorLabel.TabIndex = 12;
            this.npcArmorLabel.Text = "Armor";
            // 
            // npcManaLabel
            // 
            this.npcManaLabel.AutoSize = true;
            this.npcManaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcManaLabel.Location = new System.Drawing.Point(45, 86);
            this.npcManaLabel.Name = "npcManaLabel";
            this.npcManaLabel.Size = new System.Drawing.Size(45, 18);
            this.npcManaLabel.TabIndex = 13;
            this.npcManaLabel.Text = "Mana";
            // 
            // npcMinHealthLevel
            // 
            this.npcMinHealthLevel.AutoSize = true;
            this.npcMinHealthLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcMinHealthLevel.Location = new System.Drawing.Point(12, 133);
            this.npcMinHealthLevel.Name = "npcMinHealthLevel";
            this.npcMinHealthLevel.Size = new System.Drawing.Size(78, 18);
            this.npcMinHealthLevel.TabIndex = 14;
            this.npcMinHealthLevel.Text = "Min Health";
            // 
            // npcMaxHealthLabel
            // 
            this.npcMaxHealthLabel.AutoSize = true;
            this.npcMaxHealthLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcMaxHealthLabel.Location = new System.Drawing.Point(8, 175);
            this.npcMaxHealthLabel.Name = "npcMaxHealthLabel";
            this.npcMaxHealthLabel.Size = new System.Drawing.Size(82, 18);
            this.npcMaxHealthLabel.TabIndex = 15;
            this.npcMaxHealthLabel.Text = "Max Health";
            // 
            // npcMinLevelLabel
            // 
            this.npcMinLevelLabel.AutoSize = true;
            this.npcMinLevelLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcMinLevelLabel.Location = new System.Drawing.Point(20, 216);
            this.npcMinLevelLabel.Name = "npcMinLevelLabel";
            this.npcMinLevelLabel.Size = new System.Drawing.Size(70, 18);
            this.npcMinLevelLabel.TabIndex = 16;
            this.npcMinLevelLabel.Text = "Min Level";
            // 
            // npcMaxLevelTextBox
            // 
            this.npcMaxLevelTextBox.Location = new System.Drawing.Point(107, 260);
            this.npcMaxLevelTextBox.Name = "npcMaxLevelTextBox";
            this.npcMaxLevelTextBox.Size = new System.Drawing.Size(69, 20);
            this.npcMaxLevelTextBox.TabIndex = 23;
            this.npcMaxLevelTextBox.Text = "1";
            // 
            // npcMaxLevelLabel
            // 
            this.npcMaxLevelLabel.AutoSize = true;
            this.npcMaxLevelLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcMaxLevelLabel.Location = new System.Drawing.Point(16, 259);
            this.npcMaxLevelLabel.Name = "npcMaxLevelLabel";
            this.npcMaxLevelLabel.Size = new System.Drawing.Size(74, 18);
            this.npcMaxLevelLabel.TabIndex = 17;
            this.npcMaxLevelLabel.Text = "Max Level";
            // 
            // npcMinLevelTextBox
            // 
            this.npcMinLevelTextBox.Location = new System.Drawing.Point(107, 217);
            this.npcMinLevelTextBox.Name = "npcMinLevelTextBox";
            this.npcMinLevelTextBox.Size = new System.Drawing.Size(69, 20);
            this.npcMinLevelTextBox.TabIndex = 22;
            this.npcMinLevelTextBox.Text = "1";
            // 
            // npcArmorTextBox
            // 
            this.npcArmorTextBox.Location = new System.Drawing.Point(107, 31);
            this.npcArmorTextBox.Name = "npcArmorTextBox";
            this.npcArmorTextBox.Size = new System.Drawing.Size(69, 20);
            this.npcArmorTextBox.TabIndex = 18;
            this.npcArmorTextBox.Text = "0";
            // 
            // npcMaxHealthTextBox
            // 
            this.npcMaxHealthTextBox.Location = new System.Drawing.Point(107, 176);
            this.npcMaxHealthTextBox.Name = "npcMaxHealthTextBox";
            this.npcMaxHealthTextBox.Size = new System.Drawing.Size(69, 20);
            this.npcMaxHealthTextBox.TabIndex = 21;
            this.npcMaxHealthTextBox.Text = "0";
            // 
            // npcManaTextBox
            // 
            this.npcManaTextBox.Location = new System.Drawing.Point(107, 84);
            this.npcManaTextBox.Name = "npcManaTextBox";
            this.npcManaTextBox.Size = new System.Drawing.Size(69, 20);
            this.npcManaTextBox.TabIndex = 19;
            this.npcManaTextBox.Text = "0";
            // 
            // npcMinHealthTextBox
            // 
            this.npcMinHealthTextBox.Location = new System.Drawing.Point(107, 134);
            this.npcMinHealthTextBox.Name = "npcMinHealthTextBox";
            this.npcMinHealthTextBox.Size = new System.Drawing.Size(69, 20);
            this.npcMinHealthTextBox.TabIndex = 20;
            this.npcMinHealthTextBox.Text = "0";
            // 
            // npcAttackStatsGroupBox
            // 
            this.npcAttackStatsGroupBox.Controls.Add(this.npcSpeedTextBox);
            this.npcAttackStatsGroupBox.Controls.Add(this.npcSpeedLabel);
            this.npcAttackStatsGroupBox.Location = new System.Drawing.Point(431, 27);
            this.npcAttackStatsGroupBox.Name = "npcAttackStatsGroupBox";
            this.npcAttackStatsGroupBox.Size = new System.Drawing.Size(238, 283);
            this.npcAttackStatsGroupBox.TabIndex = 32;
            this.npcAttackStatsGroupBox.TabStop = false;
            this.npcAttackStatsGroupBox.Text = "Attack Stats";
            // 
            // npcSpeedTextBox
            // 
            this.npcSpeedTextBox.Location = new System.Drawing.Point(134, 134);
            this.npcSpeedTextBox.Name = "npcSpeedTextBox";
            this.npcSpeedTextBox.Size = new System.Drawing.Size(69, 20);
            this.npcSpeedTextBox.TabIndex = 33;
            this.npcSpeedTextBox.Text = "0";
            // 
            // npcSpeedLabel
            // 
            this.npcSpeedLabel.AutoSize = true;
            this.npcSpeedLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcSpeedLabel.Location = new System.Drawing.Point(5, 136);
            this.npcSpeedLabel.Name = "npcSpeedLabel";
            this.npcSpeedLabel.Size = new System.Drawing.Size(100, 18);
            this.npcSpeedLabel.TabIndex = 28;
            this.npcSpeedLabel.Text = "Speed (in ms)";
            // 
            // npcResistsTabPage
            // 
            this.npcResistsTabPage.Controls.Add(this.npcResistsNextButton);
            this.npcResistsTabPage.Controls.Add(this.npcResistArcaneTextBox);
            this.npcResistsTabPage.Controls.Add(this.npcResistArcaneLabel);
            this.npcResistsTabPage.Controls.Add(this.npcResistFrostTextBox);
            this.npcResistsTabPage.Controls.Add(this.npcResistFrostLabel);
            this.npcResistsTabPage.Controls.Add(this.npcResistFireTextBox);
            this.npcResistsTabPage.Controls.Add(this.npcResistFireLabel);
            this.npcResistsTabPage.Controls.Add(this.npcResistShadowTextBox);
            this.npcResistsTabPage.Controls.Add(this.npcResistShadowLabel);
            this.npcResistsTabPage.Controls.Add(this.npcResistNatureTextBox);
            this.npcResistsTabPage.Controls.Add(this.npcResistNatureLabel);
            this.npcResistsTabPage.Controls.Add(this.npcResistHolyTextBox);
            this.npcResistsTabPage.Controls.Add(this.npcResistHolyLabel);
            this.npcResistsTabPage.Location = new System.Drawing.Point(4, 22);
            this.npcResistsTabPage.Name = "npcResistsTabPage";
            this.npcResistsTabPage.Size = new System.Drawing.Size(756, 380);
            this.npcResistsTabPage.TabIndex = 3;
            this.npcResistsTabPage.Text = "Resists";
            this.npcResistsTabPage.UseVisualStyleBackColor = true;
            // 
            // npcResistsNextButton
            // 
            this.npcResistsNextButton.Location = new System.Drawing.Point(647, 331);
            this.npcResistsNextButton.Name = "npcResistsNextButton";
            this.npcResistsNextButton.Size = new System.Drawing.Size(101, 41);
            this.npcResistsNextButton.TabIndex = 31;
            this.npcResistsNextButton.Text = "Next";
            this.npcResistsNextButton.UseVisualStyleBackColor = true;
            this.npcResistsNextButton.Click += new System.EventHandler(this.npcResistsNextButton_Click);
            // 
            // npcResistArcaneTextBox
            // 
            this.npcResistArcaneTextBox.Location = new System.Drawing.Point(513, 210);
            this.npcResistArcaneTextBox.Name = "npcResistArcaneTextBox";
            this.npcResistArcaneTextBox.Size = new System.Drawing.Size(64, 20);
            this.npcResistArcaneTextBox.TabIndex = 25;
            this.npcResistArcaneTextBox.Text = "0";
            // 
            // npcResistArcaneLabel
            // 
            this.npcResistArcaneLabel.AutoSize = true;
            this.npcResistArcaneLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcResistArcaneLabel.Location = new System.Drawing.Point(431, 212);
            this.npcResistArcaneLabel.Name = "npcResistArcaneLabel";
            this.npcResistArcaneLabel.Size = new System.Drawing.Size(54, 18);
            this.npcResistArcaneLabel.TabIndex = 24;
            this.npcResistArcaneLabel.Text = "Arcane";
            // 
            // npcResistFrostTextBox
            // 
            this.npcResistFrostTextBox.Location = new System.Drawing.Point(513, 166);
            this.npcResistFrostTextBox.Name = "npcResistFrostTextBox";
            this.npcResistFrostTextBox.Size = new System.Drawing.Size(64, 20);
            this.npcResistFrostTextBox.TabIndex = 23;
            this.npcResistFrostTextBox.Text = "0";
            // 
            // npcResistFrostLabel
            // 
            this.npcResistFrostLabel.AutoSize = true;
            this.npcResistFrostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcResistFrostLabel.Location = new System.Drawing.Point(442, 165);
            this.npcResistFrostLabel.Name = "npcResistFrostLabel";
            this.npcResistFrostLabel.Size = new System.Drawing.Size(43, 18);
            this.npcResistFrostLabel.TabIndex = 22;
            this.npcResistFrostLabel.Text = "Frost";
            // 
            // npcResistFireTextBox
            // 
            this.npcResistFireTextBox.Location = new System.Drawing.Point(513, 124);
            this.npcResistFireTextBox.Name = "npcResistFireTextBox";
            this.npcResistFireTextBox.Size = new System.Drawing.Size(64, 20);
            this.npcResistFireTextBox.TabIndex = 21;
            this.npcResistFireTextBox.Text = "0";
            // 
            // npcResistFireLabel
            // 
            this.npcResistFireLabel.AutoSize = true;
            this.npcResistFireLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcResistFireLabel.Location = new System.Drawing.Point(452, 123);
            this.npcResistFireLabel.Name = "npcResistFireLabel";
            this.npcResistFireLabel.Size = new System.Drawing.Size(33, 18);
            this.npcResistFireLabel.TabIndex = 20;
            this.npcResistFireLabel.Text = "Fire";
            // 
            // npcResistShadowTextBox
            // 
            this.npcResistShadowTextBox.Location = new System.Drawing.Point(252, 211);
            this.npcResistShadowTextBox.Name = "npcResistShadowTextBox";
            this.npcResistShadowTextBox.Size = new System.Drawing.Size(64, 20);
            this.npcResistShadowTextBox.TabIndex = 19;
            this.npcResistShadowTextBox.Text = "0";
            // 
            // npcResistShadowLabel
            // 
            this.npcResistShadowLabel.AutoSize = true;
            this.npcResistShadowLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcResistShadowLabel.Location = new System.Drawing.Point(162, 211);
            this.npcResistShadowLabel.Name = "npcResistShadowLabel";
            this.npcResistShadowLabel.Size = new System.Drawing.Size(62, 18);
            this.npcResistShadowLabel.TabIndex = 18;
            this.npcResistShadowLabel.Text = "Shadow";
            // 
            // npcResistNatureTextBox
            // 
            this.npcResistNatureTextBox.Location = new System.Drawing.Point(252, 168);
            this.npcResistNatureTextBox.Name = "npcResistNatureTextBox";
            this.npcResistNatureTextBox.Size = new System.Drawing.Size(64, 20);
            this.npcResistNatureTextBox.TabIndex = 17;
            this.npcResistNatureTextBox.Text = "0";
            // 
            // npcResistNatureLabel
            // 
            this.npcResistNatureLabel.AutoSize = true;
            this.npcResistNatureLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcResistNatureLabel.Location = new System.Drawing.Point(172, 167);
            this.npcResistNatureLabel.Name = "npcResistNatureLabel";
            this.npcResistNatureLabel.Size = new System.Drawing.Size(52, 18);
            this.npcResistNatureLabel.TabIndex = 16;
            this.npcResistNatureLabel.Text = "Nature";
            // 
            // npcResistHolyTextBox
            // 
            this.npcResistHolyTextBox.Location = new System.Drawing.Point(252, 123);
            this.npcResistHolyTextBox.Name = "npcResistHolyTextBox";
            this.npcResistHolyTextBox.Size = new System.Drawing.Size(64, 20);
            this.npcResistHolyTextBox.TabIndex = 15;
            this.npcResistHolyTextBox.Text = "0";
            // 
            // npcResistHolyLabel
            // 
            this.npcResistHolyLabel.AutoSize = true;
            this.npcResistHolyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcResistHolyLabel.Location = new System.Drawing.Point(186, 126);
            this.npcResistHolyLabel.Name = "npcResistHolyLabel";
            this.npcResistHolyLabel.Size = new System.Drawing.Size(38, 18);
            this.npcResistHolyLabel.TabIndex = 14;
            this.npcResistHolyLabel.Text = "Holy";
            // 
            // npcOptionsTabPage
            // 
            this.npcOptionsTabPage.Controls.Add(this.npcOptionsNextButton);
            this.npcOptionsTabPage.Controls.Add(this.npcGuildBankGroupBox);
            this.npcOptionsTabPage.Controls.Add(this.npcStableGroupBox);
            this.npcOptionsTabPage.Controls.Add(this.npcAuctioneerGroupBox);
            this.npcOptionsTabPage.Controls.Add(this.npcBankerGroupBox);
            this.npcOptionsTabPage.Controls.Add(this.npcInnkeeperGroupBox);
            this.npcOptionsTabPage.Controls.Add(this.npcArmorerGroupBox);
            this.npcOptionsTabPage.Controls.Add(this.npcVendorGroupBox);
            this.npcOptionsTabPage.Controls.Add(this.npcGossipGroupBox);
            this.npcOptionsTabPage.Location = new System.Drawing.Point(4, 22);
            this.npcOptionsTabPage.Name = "npcOptionsTabPage";
            this.npcOptionsTabPage.Size = new System.Drawing.Size(756, 380);
            this.npcOptionsTabPage.TabIndex = 4;
            this.npcOptionsTabPage.Text = "Options";
            this.npcOptionsTabPage.UseVisualStyleBackColor = true;
            // 
            // npcOptionsNextButton
            // 
            this.npcOptionsNextButton.Location = new System.Drawing.Point(647, 331);
            this.npcOptionsNextButton.Name = "npcOptionsNextButton";
            this.npcOptionsNextButton.Size = new System.Drawing.Size(101, 41);
            this.npcOptionsNextButton.TabIndex = 32;
            this.npcOptionsNextButton.Text = "Next";
            this.npcOptionsNextButton.UseVisualStyleBackColor = true;
            this.npcOptionsNextButton.Click += new System.EventHandler(this.npcOptionsNextButton_Click);
            // 
            // npcGuildBankGroupBox
            // 
            this.npcGuildBankGroupBox.Controls.Add(this.npcGuildBankNoRadioButton);
            this.npcGuildBankGroupBox.Controls.Add(this.npcGuildBankYesRadioButton);
            this.npcGuildBankGroupBox.Location = new System.Drawing.Point(384, 158);
            this.npcGuildBankGroupBox.Name = "npcGuildBankGroupBox";
            this.npcGuildBankGroupBox.Size = new System.Drawing.Size(177, 42);
            this.npcGuildBankGroupBox.TabIndex = 8;
            this.npcGuildBankGroupBox.TabStop = false;
            this.npcGuildBankGroupBox.Text = "Guild Bank";
            // 
            // npcGuildBankNoRadioButton
            // 
            this.npcGuildBankNoRadioButton.AutoSize = true;
            this.npcGuildBankNoRadioButton.Checked = true;
            this.npcGuildBankNoRadioButton.Location = new System.Drawing.Point(100, 17);
            this.npcGuildBankNoRadioButton.Name = "npcGuildBankNoRadioButton";
            this.npcGuildBankNoRadioButton.Size = new System.Drawing.Size(39, 17);
            this.npcGuildBankNoRadioButton.TabIndex = 1;
            this.npcGuildBankNoRadioButton.TabStop = true;
            this.npcGuildBankNoRadioButton.Text = "No";
            this.npcGuildBankNoRadioButton.UseVisualStyleBackColor = true;
            // 
            // npcGuildBankYesRadioButton
            // 
            this.npcGuildBankYesRadioButton.AutoSize = true;
            this.npcGuildBankYesRadioButton.Location = new System.Drawing.Point(20, 17);
            this.npcGuildBankYesRadioButton.Name = "npcGuildBankYesRadioButton";
            this.npcGuildBankYesRadioButton.Size = new System.Drawing.Size(43, 17);
            this.npcGuildBankYesRadioButton.TabIndex = 0;
            this.npcGuildBankYesRadioButton.Text = "Yes";
            this.npcGuildBankYesRadioButton.UseVisualStyleBackColor = true;
            // 
            // npcStableGroupBox
            // 
            this.npcStableGroupBox.Controls.Add(this.npcStableNoRadioButton);
            this.npcStableGroupBox.Controls.Add(this.npcStableYesRadioButton);
            this.npcStableGroupBox.Location = new System.Drawing.Point(384, 110);
            this.npcStableGroupBox.Name = "npcStableGroupBox";
            this.npcStableGroupBox.Size = new System.Drawing.Size(177, 42);
            this.npcStableGroupBox.TabIndex = 7;
            this.npcStableGroupBox.TabStop = false;
            this.npcStableGroupBox.Text = "Stable";
            // 
            // npcStableNoRadioButton
            // 
            this.npcStableNoRadioButton.AutoSize = true;
            this.npcStableNoRadioButton.Checked = true;
            this.npcStableNoRadioButton.Location = new System.Drawing.Point(100, 17);
            this.npcStableNoRadioButton.Name = "npcStableNoRadioButton";
            this.npcStableNoRadioButton.Size = new System.Drawing.Size(39, 17);
            this.npcStableNoRadioButton.TabIndex = 1;
            this.npcStableNoRadioButton.TabStop = true;
            this.npcStableNoRadioButton.Text = "No";
            this.npcStableNoRadioButton.UseVisualStyleBackColor = true;
            // 
            // npcStableYesRadioButton
            // 
            this.npcStableYesRadioButton.AutoSize = true;
            this.npcStableYesRadioButton.Location = new System.Drawing.Point(20, 17);
            this.npcStableYesRadioButton.Name = "npcStableYesRadioButton";
            this.npcStableYesRadioButton.Size = new System.Drawing.Size(43, 17);
            this.npcStableYesRadioButton.TabIndex = 0;
            this.npcStableYesRadioButton.Text = "Yes";
            this.npcStableYesRadioButton.UseVisualStyleBackColor = true;
            // 
            // npcAuctioneerGroupBox
            // 
            this.npcAuctioneerGroupBox.Controls.Add(this.npcAuctioneerNoRadioButton);
            this.npcAuctioneerGroupBox.Controls.Add(this.npcAuctioneerYesRadioButton);
            this.npcAuctioneerGroupBox.Location = new System.Drawing.Point(384, 62);
            this.npcAuctioneerGroupBox.Name = "npcAuctioneerGroupBox";
            this.npcAuctioneerGroupBox.Size = new System.Drawing.Size(177, 42);
            this.npcAuctioneerGroupBox.TabIndex = 6;
            this.npcAuctioneerGroupBox.TabStop = false;
            this.npcAuctioneerGroupBox.Text = "Auctioneer";
            // 
            // npcAuctioneerNoRadioButton
            // 
            this.npcAuctioneerNoRadioButton.AutoSize = true;
            this.npcAuctioneerNoRadioButton.Checked = true;
            this.npcAuctioneerNoRadioButton.Location = new System.Drawing.Point(100, 17);
            this.npcAuctioneerNoRadioButton.Name = "npcAuctioneerNoRadioButton";
            this.npcAuctioneerNoRadioButton.Size = new System.Drawing.Size(39, 17);
            this.npcAuctioneerNoRadioButton.TabIndex = 1;
            this.npcAuctioneerNoRadioButton.TabStop = true;
            this.npcAuctioneerNoRadioButton.Text = "No";
            this.npcAuctioneerNoRadioButton.UseVisualStyleBackColor = true;
            // 
            // npcAuctioneerYesRadioButton
            // 
            this.npcAuctioneerYesRadioButton.AutoSize = true;
            this.npcAuctioneerYesRadioButton.Location = new System.Drawing.Point(20, 17);
            this.npcAuctioneerYesRadioButton.Name = "npcAuctioneerYesRadioButton";
            this.npcAuctioneerYesRadioButton.Size = new System.Drawing.Size(43, 17);
            this.npcAuctioneerYesRadioButton.TabIndex = 0;
            this.npcAuctioneerYesRadioButton.Text = "Yes";
            this.npcAuctioneerYesRadioButton.UseVisualStyleBackColor = true;
            // 
            // npcBankerGroupBox
            // 
            this.npcBankerGroupBox.Controls.Add(this.npcBankerNoRadioButton);
            this.npcBankerGroupBox.Controls.Add(this.npcBankerYesRadioButton);
            this.npcBankerGroupBox.Location = new System.Drawing.Point(201, 254);
            this.npcBankerGroupBox.Name = "npcBankerGroupBox";
            this.npcBankerGroupBox.Size = new System.Drawing.Size(177, 42);
            this.npcBankerGroupBox.TabIndex = 5;
            this.npcBankerGroupBox.TabStop = false;
            this.npcBankerGroupBox.Text = "Banker";
            // 
            // npcBankerNoRadioButton
            // 
            this.npcBankerNoRadioButton.AutoSize = true;
            this.npcBankerNoRadioButton.Checked = true;
            this.npcBankerNoRadioButton.Location = new System.Drawing.Point(100, 17);
            this.npcBankerNoRadioButton.Name = "npcBankerNoRadioButton";
            this.npcBankerNoRadioButton.Size = new System.Drawing.Size(39, 17);
            this.npcBankerNoRadioButton.TabIndex = 1;
            this.npcBankerNoRadioButton.TabStop = true;
            this.npcBankerNoRadioButton.Text = "No";
            this.npcBankerNoRadioButton.UseVisualStyleBackColor = true;
            // 
            // npcBankerYesRadioButton
            // 
            this.npcBankerYesRadioButton.AutoSize = true;
            this.npcBankerYesRadioButton.Location = new System.Drawing.Point(20, 17);
            this.npcBankerYesRadioButton.Name = "npcBankerYesRadioButton";
            this.npcBankerYesRadioButton.Size = new System.Drawing.Size(43, 17);
            this.npcBankerYesRadioButton.TabIndex = 0;
            this.npcBankerYesRadioButton.Text = "Yes";
            this.npcBankerYesRadioButton.UseVisualStyleBackColor = true;
            // 
            // npcInnkeeperGroupBox
            // 
            this.npcInnkeeperGroupBox.Controls.Add(this.npcInnkeeperNoRadioButton);
            this.npcInnkeeperGroupBox.Controls.Add(this.npcInnkeeperYesRadioButton);
            this.npcInnkeeperGroupBox.Location = new System.Drawing.Point(201, 206);
            this.npcInnkeeperGroupBox.Name = "npcInnkeeperGroupBox";
            this.npcInnkeeperGroupBox.Size = new System.Drawing.Size(177, 42);
            this.npcInnkeeperGroupBox.TabIndex = 4;
            this.npcInnkeeperGroupBox.TabStop = false;
            this.npcInnkeeperGroupBox.Text = "Innkeeper";
            // 
            // npcInnkeeperNoRadioButton
            // 
            this.npcInnkeeperNoRadioButton.AutoSize = true;
            this.npcInnkeeperNoRadioButton.Checked = true;
            this.npcInnkeeperNoRadioButton.Location = new System.Drawing.Point(100, 17);
            this.npcInnkeeperNoRadioButton.Name = "npcInnkeeperNoRadioButton";
            this.npcInnkeeperNoRadioButton.Size = new System.Drawing.Size(39, 17);
            this.npcInnkeeperNoRadioButton.TabIndex = 1;
            this.npcInnkeeperNoRadioButton.TabStop = true;
            this.npcInnkeeperNoRadioButton.Text = "No";
            this.npcInnkeeperNoRadioButton.UseVisualStyleBackColor = true;
            // 
            // npcInnkeeperYesRadioButton
            // 
            this.npcInnkeeperYesRadioButton.AutoSize = true;
            this.npcInnkeeperYesRadioButton.Location = new System.Drawing.Point(20, 17);
            this.npcInnkeeperYesRadioButton.Name = "npcInnkeeperYesRadioButton";
            this.npcInnkeeperYesRadioButton.Size = new System.Drawing.Size(43, 17);
            this.npcInnkeeperYesRadioButton.TabIndex = 0;
            this.npcInnkeeperYesRadioButton.Text = "Yes";
            this.npcInnkeeperYesRadioButton.UseVisualStyleBackColor = true;
            // 
            // npcArmorerGroupBox
            // 
            this.npcArmorerGroupBox.Controls.Add(this.npcArmorerNoRadioButton);
            this.npcArmorerGroupBox.Controls.Add(this.npcArmorerYesRadioButton);
            this.npcArmorerGroupBox.Location = new System.Drawing.Point(201, 158);
            this.npcArmorerGroupBox.Name = "npcArmorerGroupBox";
            this.npcArmorerGroupBox.Size = new System.Drawing.Size(177, 42);
            this.npcArmorerGroupBox.TabIndex = 3;
            this.npcArmorerGroupBox.TabStop = false;
            this.npcArmorerGroupBox.Text = "Armorer";
            // 
            // npcArmorerNoRadioButton
            // 
            this.npcArmorerNoRadioButton.AutoSize = true;
            this.npcArmorerNoRadioButton.Checked = true;
            this.npcArmorerNoRadioButton.Location = new System.Drawing.Point(100, 17);
            this.npcArmorerNoRadioButton.Name = "npcArmorerNoRadioButton";
            this.npcArmorerNoRadioButton.Size = new System.Drawing.Size(39, 17);
            this.npcArmorerNoRadioButton.TabIndex = 1;
            this.npcArmorerNoRadioButton.TabStop = true;
            this.npcArmorerNoRadioButton.Text = "No";
            this.npcArmorerNoRadioButton.UseVisualStyleBackColor = true;
            // 
            // npcArmorerYesRadioButton
            // 
            this.npcArmorerYesRadioButton.AutoSize = true;
            this.npcArmorerYesRadioButton.Location = new System.Drawing.Point(20, 17);
            this.npcArmorerYesRadioButton.Name = "npcArmorerYesRadioButton";
            this.npcArmorerYesRadioButton.Size = new System.Drawing.Size(43, 17);
            this.npcArmorerYesRadioButton.TabIndex = 0;
            this.npcArmorerYesRadioButton.Text = "Yes";
            this.npcArmorerYesRadioButton.UseVisualStyleBackColor = true;
            // 
            // npcVendorGroupBox
            // 
            this.npcVendorGroupBox.Controls.Add(this.npcVendorNoRadioButton);
            this.npcVendorGroupBox.Controls.Add(this.npcVendorYesRadioButton);
            this.npcVendorGroupBox.Location = new System.Drawing.Point(201, 110);
            this.npcVendorGroupBox.Name = "npcVendorGroupBox";
            this.npcVendorGroupBox.Size = new System.Drawing.Size(177, 42);
            this.npcVendorGroupBox.TabIndex = 2;
            this.npcVendorGroupBox.TabStop = false;
            this.npcVendorGroupBox.Text = "Vendor";
            // 
            // npcVendorNoRadioButton
            // 
            this.npcVendorNoRadioButton.AutoSize = true;
            this.npcVendorNoRadioButton.Checked = true;
            this.npcVendorNoRadioButton.Location = new System.Drawing.Point(100, 17);
            this.npcVendorNoRadioButton.Name = "npcVendorNoRadioButton";
            this.npcVendorNoRadioButton.Size = new System.Drawing.Size(39, 17);
            this.npcVendorNoRadioButton.TabIndex = 1;
            this.npcVendorNoRadioButton.TabStop = true;
            this.npcVendorNoRadioButton.Text = "No";
            this.npcVendorNoRadioButton.UseVisualStyleBackColor = true;
            // 
            // npcVendorYesRadioButton
            // 
            this.npcVendorYesRadioButton.AutoSize = true;
            this.npcVendorYesRadioButton.Location = new System.Drawing.Point(20, 17);
            this.npcVendorYesRadioButton.Name = "npcVendorYesRadioButton";
            this.npcVendorYesRadioButton.Size = new System.Drawing.Size(43, 17);
            this.npcVendorYesRadioButton.TabIndex = 0;
            this.npcVendorYesRadioButton.Text = "Yes";
            this.npcVendorYesRadioButton.UseVisualStyleBackColor = true;
            // 
            // npcGossipGroupBox
            // 
            this.npcGossipGroupBox.Controls.Add(this.npcGossipNoRadioButton);
            this.npcGossipGroupBox.Controls.Add(this.npcGossipYesRadioButton);
            this.npcGossipGroupBox.Location = new System.Drawing.Point(201, 62);
            this.npcGossipGroupBox.Name = "npcGossipGroupBox";
            this.npcGossipGroupBox.Size = new System.Drawing.Size(177, 42);
            this.npcGossipGroupBox.TabIndex = 0;
            this.npcGossipGroupBox.TabStop = false;
            this.npcGossipGroupBox.Text = "Gossip";
            // 
            // npcGossipNoRadioButton
            // 
            this.npcGossipNoRadioButton.AutoSize = true;
            this.npcGossipNoRadioButton.Checked = true;
            this.npcGossipNoRadioButton.Location = new System.Drawing.Point(100, 17);
            this.npcGossipNoRadioButton.Name = "npcGossipNoRadioButton";
            this.npcGossipNoRadioButton.Size = new System.Drawing.Size(39, 17);
            this.npcGossipNoRadioButton.TabIndex = 1;
            this.npcGossipNoRadioButton.TabStop = true;
            this.npcGossipNoRadioButton.Text = "No";
            this.npcGossipNoRadioButton.UseVisualStyleBackColor = true;
            // 
            // npcGossipYesRadioButton
            // 
            this.npcGossipYesRadioButton.AutoSize = true;
            this.npcGossipYesRadioButton.Location = new System.Drawing.Point(20, 17);
            this.npcGossipYesRadioButton.Name = "npcGossipYesRadioButton";
            this.npcGossipYesRadioButton.Size = new System.Drawing.Size(43, 17);
            this.npcGossipYesRadioButton.TabIndex = 0;
            this.npcGossipYesRadioButton.Text = "Yes";
            this.npcGossipYesRadioButton.UseVisualStyleBackColor = true;
            // 
            // npcLootTabPage
            // 
            this.npcLootTabPage.Controls.Add(this.npcLootFinishButton);
            this.npcLootTabPage.Controls.Add(this.npcLootGroupBox);
            this.npcLootTabPage.Location = new System.Drawing.Point(4, 22);
            this.npcLootTabPage.Name = "npcLootTabPage";
            this.npcLootTabPage.Size = new System.Drawing.Size(756, 380);
            this.npcLootTabPage.TabIndex = 5;
            this.npcLootTabPage.Text = "Loot";
            this.npcLootTabPage.UseVisualStyleBackColor = true;
            // 
            // npcLootFinishButton
            // 
            this.npcLootFinishButton.Location = new System.Drawing.Point(647, 331);
            this.npcLootFinishButton.Name = "npcLootFinishButton";
            this.npcLootFinishButton.Size = new System.Drawing.Size(101, 41);
            this.npcLootFinishButton.TabIndex = 55;
            this.npcLootFinishButton.Text = "Finish";
            this.npcLootFinishButton.UseVisualStyleBackColor = true;
            this.npcLootFinishButton.Click += new System.EventHandler(this.npcLootFinishButton_Click);
            // 
            // npcLootGroupBox
            // 
            this.npcLootGroupBox.Controls.Add(this.npcLootGoldTextBox);
            this.npcLootGroupBox.Controls.Add(this.npcLootCopperNumericUpDown);
            this.npcLootGroupBox.Controls.Add(this.npcLootGoldLabel);
            this.npcLootGroupBox.Controls.Add(this.npcLootSilverNumericUpDown);
            this.npcLootGroupBox.Controls.Add(this.npcLootSilverLabel);
            this.npcLootGroupBox.Controls.Add(this.npcLootCopperLabel);
            this.npcLootGroupBox.Location = new System.Drawing.Point(169, 135);
            this.npcLootGroupBox.Name = "npcLootGroupBox";
            this.npcLootGroupBox.Size = new System.Drawing.Size(431, 98);
            this.npcLootGroupBox.TabIndex = 56;
            this.npcLootGroupBox.TabStop = false;
            this.npcLootGroupBox.Text = "Loot";
            // 
            // npcLootGoldTextBox
            // 
            this.npcLootGoldTextBox.Location = new System.Drawing.Point(35, 44);
            this.npcLootGoldTextBox.Name = "npcLootGoldTextBox";
            this.npcLootGoldTextBox.Size = new System.Drawing.Size(41, 20);
            this.npcLootGoldTextBox.TabIndex = 49;
            this.npcLootGoldTextBox.Text = "0";
            // 
            // npcLootCopperNumericUpDown
            // 
            this.npcLootCopperNumericUpDown.Location = new System.Drawing.Point(300, 44);
            this.npcLootCopperNumericUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.npcLootCopperNumericUpDown.Name = "npcLootCopperNumericUpDown";
            this.npcLootCopperNumericUpDown.Size = new System.Drawing.Size(45, 20);
            this.npcLootCopperNumericUpDown.TabIndex = 54;
            // 
            // npcLootGoldLabel
            // 
            this.npcLootGoldLabel.AutoSize = true;
            this.npcLootGoldLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcLootGoldLabel.Location = new System.Drawing.Point(92, 46);
            this.npcLootGoldLabel.Name = "npcLootGoldLabel";
            this.npcLootGoldLabel.Size = new System.Drawing.Size(40, 18);
            this.npcLootGoldLabel.TabIndex = 50;
            this.npcLootGoldLabel.Text = "Gold";
            // 
            // npcLootSilverNumericUpDown
            // 
            this.npcLootSilverNumericUpDown.Location = new System.Drawing.Point(164, 45);
            this.npcLootSilverNumericUpDown.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.npcLootSilverNumericUpDown.Name = "npcLootSilverNumericUpDown";
            this.npcLootSilverNumericUpDown.Size = new System.Drawing.Size(45, 20);
            this.npcLootSilverNumericUpDown.TabIndex = 53;
            // 
            // npcLootSilverLabel
            // 
            this.npcLootSilverLabel.AutoSize = true;
            this.npcLootSilverLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcLootSilverLabel.Location = new System.Drawing.Point(215, 46);
            this.npcLootSilverLabel.Name = "npcLootSilverLabel";
            this.npcLootSilverLabel.Size = new System.Drawing.Size(44, 18);
            this.npcLootSilverLabel.TabIndex = 51;
            this.npcLootSilverLabel.Text = "Silver";
            // 
            // npcLootCopperLabel
            // 
            this.npcLootCopperLabel.AutoSize = true;
            this.npcLootCopperLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcLootCopperLabel.Location = new System.Drawing.Point(351, 46);
            this.npcLootCopperLabel.Name = "npcLootCopperLabel";
            this.npcLootCopperLabel.Size = new System.Drawing.Size(57, 18);
            this.npcLootCopperLabel.TabIndex = 52;
            this.npcLootCopperLabel.Text = "Copper";
            // 
            // npcFinishTabPage
            // 
            this.npcFinishTabPage.Controls.Add(this.npcSaveToSQLFileButton);
            this.npcFinishTabPage.Controls.Add(this.npcSaveToDBButton);
            this.npcFinishTabPage.Controls.Add(this.npcStartOverButton);
            this.npcFinishTabPage.Location = new System.Drawing.Point(4, 22);
            this.npcFinishTabPage.Name = "npcFinishTabPage";
            this.npcFinishTabPage.Size = new System.Drawing.Size(756, 380);
            this.npcFinishTabPage.TabIndex = 6;
            this.npcFinishTabPage.Text = "Finish";
            this.npcFinishTabPage.UseVisualStyleBackColor = true;
            // 
            // npcSaveToSQLFileButton
            // 
            this.npcSaveToSQLFileButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcSaveToSQLFileButton.Location = new System.Drawing.Point(281, 221);
            this.npcSaveToSQLFileButton.Name = "npcSaveToSQLFileButton";
            this.npcSaveToSQLFileButton.Size = new System.Drawing.Size(208, 74);
            this.npcSaveToSQLFileButton.TabIndex = 7;
            this.npcSaveToSQLFileButton.Text = "Save To SQL File";
            this.npcSaveToSQLFileButton.UseVisualStyleBackColor = true;
            this.npcSaveToSQLFileButton.Click += new System.EventHandler(this.npcSaveToSQLFileButton_Click);
            // 
            // npcSaveToDBButton
            // 
            this.npcSaveToDBButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcSaveToDBButton.Location = new System.Drawing.Point(453, 85);
            this.npcSaveToDBButton.Name = "npcSaveToDBButton";
            this.npcSaveToDBButton.Size = new System.Drawing.Size(208, 74);
            this.npcSaveToDBButton.TabIndex = 6;
            this.npcSaveToDBButton.Text = "Save To Database";
            this.npcSaveToDBButton.UseVisualStyleBackColor = true;
            this.npcSaveToDBButton.Click += new System.EventHandler(this.npcSaveToDBButton_Click);
            // 
            // npcStartOverButton
            // 
            this.npcStartOverButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcStartOverButton.Location = new System.Drawing.Point(95, 85);
            this.npcStartOverButton.Name = "npcStartOverButton";
            this.npcStartOverButton.Size = new System.Drawing.Size(208, 74);
            this.npcStartOverButton.TabIndex = 5;
            this.npcStartOverButton.Text = "Start Over";
            this.npcStartOverButton.UseVisualStyleBackColor = true;
            this.npcStartOverButton.Click += new System.EventHandler(this.npcStartOverButton_Click);
            // 
            // vendorsTabPage
            // 
            this.vendorsTabPage.Controls.Add(this.vendorResetButton);
            this.vendorsTabPage.Controls.Add(this.searchVendorNPCEntryIDsButton);
            this.vendorsTabPage.Controls.Add(this.vendorRemoveRowButton);
            this.vendorsTabPage.Controls.Add(this.vendorGridView);
            this.vendorsTabPage.Controls.Add(this.vendorAmountNumericUpDown);
            this.vendorsTabPage.Controls.Add(this.label64);
            this.vendorsTabPage.Controls.Add(this.vendorAddButton);
            this.vendorsTabPage.Controls.Add(this.vendorSaveToSQLButton);
            this.vendorsTabPage.Controls.Add(this.vendorSaveToDBButton);
            this.vendorsTabPage.Controls.Add(this.vendorItemEntryIDTextBox);
            this.vendorsTabPage.Controls.Add(this.vendorItemEntryIDLabel);
            this.vendorsTabPage.Controls.Add(this.vendorEntryIDTextBox);
            this.vendorsTabPage.Controls.Add(this.vendorEntryIDLabel);
            this.vendorsTabPage.Location = new System.Drawing.Point(4, 22);
            this.vendorsTabPage.Name = "vendorsTabPage";
            this.vendorsTabPage.Size = new System.Drawing.Size(760, 402);
            this.vendorsTabPage.TabIndex = 3;
            this.vendorsTabPage.Text = "Vendors";
            this.vendorsTabPage.UseVisualStyleBackColor = true;
            // 
            // vendorResetButton
            // 
            this.vendorResetButton.Location = new System.Drawing.Point(435, 145);
            this.vendorResetButton.Name = "vendorResetButton";
            this.vendorResetButton.Size = new System.Drawing.Size(75, 23);
            this.vendorResetButton.TabIndex = 12;
            this.vendorResetButton.Text = "Reset";
            this.vendorResetButton.UseVisualStyleBackColor = true;
            this.vendorResetButton.Click += new System.EventHandler(this.vendorResetButton_Click);
            // 
            // searchVendorNPCEntryIDsButton
            // 
            this.searchVendorNPCEntryIDsButton.Location = new System.Drawing.Point(551, 21);
            this.searchVendorNPCEntryIDsButton.Name = "searchVendorNPCEntryIDsButton";
            this.searchVendorNPCEntryIDsButton.Size = new System.Drawing.Size(148, 23);
            this.searchVendorNPCEntryIDsButton.TabIndex = 11;
            this.searchVendorNPCEntryIDsButton.Text = "Search For NPC Entry IDs";
            this.searchVendorNPCEntryIDsButton.UseVisualStyleBackColor = true;
            this.searchVendorNPCEntryIDsButton.Click += new System.EventHandler(this.searchVendorNPCEntryIDsButton_Click);
            // 
            // vendorRemoveRowButton
            // 
            this.vendorRemoveRowButton.Location = new System.Drawing.Point(354, 145);
            this.vendorRemoveRowButton.Name = "vendorRemoveRowButton";
            this.vendorRemoveRowButton.Size = new System.Drawing.Size(75, 23);
            this.vendorRemoveRowButton.TabIndex = 5;
            this.vendorRemoveRowButton.Text = "Remove";
            this.vendorRemoveRowButton.UseVisualStyleBackColor = true;
            this.vendorRemoveRowButton.Click += new System.EventHandler(this.vendorRemoveRowButton_Click);
            // 
            // vendorGridView
            // 
            this.vendorGridView.AllowUserToAddRows = false;
            this.vendorGridView.AllowUserToDeleteRows = false;
            this.vendorGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.vendorGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.vendorGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.vendorGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.vendorEntryIDColumn,
            this.vendorItemEntryID,
            this.vendorItemAmount});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.vendorGridView.DefaultCellStyle = dataGridViewCellStyle2;
            this.vendorGridView.Location = new System.Drawing.Point(4, 183);
            this.vendorGridView.Name = "vendorGridView";
            this.vendorGridView.ReadOnly = true;
            this.vendorGridView.Size = new System.Drawing.Size(748, 160);
            this.vendorGridView.TabIndex = 8;
            // 
            // vendorEntryIDColumn
            // 
            this.vendorEntryIDColumn.HeaderText = "Vendor Entry ID";
            this.vendorEntryIDColumn.Name = "vendorEntryIDColumn";
            this.vendorEntryIDColumn.ReadOnly = true;
            // 
            // vendorItemEntryID
            // 
            this.vendorItemEntryID.HeaderText = "Item Entry ID";
            this.vendorItemEntryID.Name = "vendorItemEntryID";
            this.vendorItemEntryID.ReadOnly = true;
            // 
            // vendorItemAmount
            // 
            this.vendorItemAmount.HeaderText = "Item Amount";
            this.vendorItemAmount.Name = "vendorItemAmount";
            this.vendorItemAmount.ReadOnly = true;
            // 
            // vendorAmountNumericUpDown
            // 
            this.vendorAmountNumericUpDown.Location = new System.Drawing.Point(383, 103);
            this.vendorAmountNumericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.vendorAmountNumericUpDown.Name = "vendorAmountNumericUpDown";
            this.vendorAmountNumericUpDown.Size = new System.Drawing.Size(52, 20);
            this.vendorAmountNumericUpDown.TabIndex = 3;
            this.vendorAmountNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(303, 106);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(59, 18);
            this.label64.TabIndex = 8;
            this.label64.Text = "Amount";
            // 
            // vendorAddButton
            // 
            this.vendorAddButton.Location = new System.Drawing.Point(273, 145);
            this.vendorAddButton.Name = "vendorAddButton";
            this.vendorAddButton.Size = new System.Drawing.Size(75, 23);
            this.vendorAddButton.TabIndex = 4;
            this.vendorAddButton.Text = "Add";
            this.vendorAddButton.UseVisualStyleBackColor = true;
            this.vendorAddButton.Click += new System.EventHandler(this.vendorAddButton_Click);
            // 
            // vendorSaveToSQLButton
            // 
            this.vendorSaveToSQLButton.Location = new System.Drawing.Point(232, 349);
            this.vendorSaveToSQLButton.Name = "vendorSaveToSQLButton";
            this.vendorSaveToSQLButton.Size = new System.Drawing.Size(106, 45);
            this.vendorSaveToSQLButton.TabIndex = 7;
            this.vendorSaveToSQLButton.Text = "Save To SQL";
            this.vendorSaveToSQLButton.UseVisualStyleBackColor = true;
            this.vendorSaveToSQLButton.Click += new System.EventHandler(this.vendorSaveToSQLButton_Click);
            // 
            // vendorSaveToDBButton
            // 
            this.vendorSaveToDBButton.Location = new System.Drawing.Point(444, 349);
            this.vendorSaveToDBButton.Name = "vendorSaveToDBButton";
            this.vendorSaveToDBButton.Size = new System.Drawing.Size(106, 45);
            this.vendorSaveToDBButton.TabIndex = 6;
            this.vendorSaveToDBButton.Text = "Save To DB";
            this.vendorSaveToDBButton.UseVisualStyleBackColor = true;
            this.vendorSaveToDBButton.Click += new System.EventHandler(this.vendorSaveToDBButton_Click);
            // 
            // vendorItemEntryIDTextBox
            // 
            this.vendorItemEntryIDTextBox.Location = new System.Drawing.Point(383, 67);
            this.vendorItemEntryIDTextBox.Name = "vendorItemEntryIDTextBox";
            this.vendorItemEntryIDTextBox.Size = new System.Drawing.Size(76, 20);
            this.vendorItemEntryIDTextBox.TabIndex = 2;
            // 
            // vendorItemEntryIDLabel
            // 
            this.vendorItemEntryIDLabel.AutoSize = true;
            this.vendorItemEntryIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vendorItemEntryIDLabel.Location = new System.Drawing.Point(270, 66);
            this.vendorItemEntryIDLabel.Name = "vendorItemEntryIDLabel";
            this.vendorItemEntryIDLabel.Size = new System.Drawing.Size(92, 18);
            this.vendorItemEntryIDLabel.TabIndex = 2;
            this.vendorItemEntryIDLabel.Text = "Item Entry ID";
            // 
            // vendorEntryIDTextBox
            // 
            this.vendorEntryIDTextBox.Location = new System.Drawing.Point(383, 21);
            this.vendorEntryIDTextBox.Name = "vendorEntryIDTextBox";
            this.vendorEntryIDTextBox.Size = new System.Drawing.Size(76, 20);
            this.vendorEntryIDTextBox.TabIndex = 1;
            // 
            // vendorEntryIDLabel
            // 
            this.vendorEntryIDLabel.AutoSize = true;
            this.vendorEntryIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vendorEntryIDLabel.Location = new System.Drawing.Point(251, 20);
            this.vendorEntryIDLabel.Name = "vendorEntryIDLabel";
            this.vendorEntryIDLabel.Size = new System.Drawing.Size(111, 18);
            this.vendorEntryIDLabel.TabIndex = 0;
            this.vendorEntryIDLabel.Text = "Vendor Entry ID";
            // 
            // lootTabPage
            // 
            this.lootTabPage.Controls.Add(this.lootSearchItemButton);
            this.lootTabPage.Controls.Add(this.lootSearchNPCButton);
            this.lootTabPage.Controls.Add(this.lootMaxAmountNumericUpDown);
            this.lootTabPage.Controls.Add(this.label63);
            this.lootTabPage.Controls.Add(this.lootChancePercent);
            this.lootTabPage.Controls.Add(this.lootChanceTextBox);
            this.lootTabPage.Controls.Add(this.lootChanceLabel);
            this.lootTabPage.Controls.Add(this.lootRemoveButton);
            this.lootTabPage.Controls.Add(this.lootGridView);
            this.lootTabPage.Controls.Add(this.lootMinAmountNumericUpDown);
            this.lootTabPage.Controls.Add(this.lootMinAmountLabel);
            this.lootTabPage.Controls.Add(this.lootAddButton);
            this.lootTabPage.Controls.Add(this.lootSaveToSQLFileButton);
            this.lootTabPage.Controls.Add(this.lootSaveToDBButton);
            this.lootTabPage.Controls.Add(this.lootItemEntryIDTextBox);
            this.lootTabPage.Controls.Add(this.lootItemEntryIDLabel);
            this.lootTabPage.Controls.Add(this.lootNPCEntryIDTextBox);
            this.lootTabPage.Controls.Add(this.lootNpcEntryIDLabel);
            this.lootTabPage.Location = new System.Drawing.Point(4, 22);
            this.lootTabPage.Name = "lootTabPage";
            this.lootTabPage.Size = new System.Drawing.Size(760, 402);
            this.lootTabPage.TabIndex = 4;
            this.lootTabPage.Text = "Loot";
            this.lootTabPage.UseVisualStyleBackColor = true;
            // 
            // lootSearchItemButton
            // 
            this.lootSearchItemButton.Location = new System.Drawing.Point(604, 65);
            this.lootSearchItemButton.Name = "lootSearchItemButton";
            this.lootSearchItemButton.Size = new System.Drawing.Size(148, 23);
            this.lootSearchItemButton.TabIndex = 28;
            this.lootSearchItemButton.Text = "Search For Item Entry IDs";
            this.lootSearchItemButton.UseVisualStyleBackColor = true;
            this.lootSearchItemButton.Click += new System.EventHandler(this.lootSearchItemButton_Click);
            // 
            // lootSearchNPCButton
            // 
            this.lootSearchNPCButton.Location = new System.Drawing.Point(604, 22);
            this.lootSearchNPCButton.Name = "lootSearchNPCButton";
            this.lootSearchNPCButton.Size = new System.Drawing.Size(148, 23);
            this.lootSearchNPCButton.TabIndex = 27;
            this.lootSearchNPCButton.Text = "Search For NPC Entry IDs";
            this.lootSearchNPCButton.UseVisualStyleBackColor = true;
            this.lootSearchNPCButton.Click += new System.EventHandler(this.lootSearchNPCButton_Click);
            // 
            // lootMaxAmountNumericUpDown
            // 
            this.lootMaxAmountNumericUpDown.Location = new System.Drawing.Point(505, 91);
            this.lootMaxAmountNumericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.lootMaxAmountNumericUpDown.Name = "lootMaxAmountNumericUpDown";
            this.lootMaxAmountNumericUpDown.Size = new System.Drawing.Size(52, 20);
            this.lootMaxAmountNumericUpDown.TabIndex = 5;
            this.lootMaxAmountNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.Location = new System.Drawing.Point(394, 93);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(91, 18);
            this.label63.TabIndex = 26;
            this.label63.Text = "Max Amount";
            // 
            // lootChancePercent
            // 
            this.lootChancePercent.AutoSize = true;
            this.lootChancePercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lootChancePercent.Location = new System.Drawing.Point(556, 47);
            this.lootChancePercent.Name = "lootChancePercent";
            this.lootChancePercent.Size = new System.Drawing.Size(21, 18);
            this.lootChancePercent.TabIndex = 25;
            this.lootChancePercent.Text = "%";
            // 
            // lootChanceTextBox
            // 
            this.lootChanceTextBox.Location = new System.Drawing.Point(505, 45);
            this.lootChanceTextBox.Name = "lootChanceTextBox";
            this.lootChanceTextBox.Size = new System.Drawing.Size(45, 20);
            this.lootChanceTextBox.TabIndex = 4;
            // 
            // lootChanceLabel
            // 
            this.lootChanceLabel.AutoSize = true;
            this.lootChanceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lootChanceLabel.Location = new System.Drawing.Point(426, 44);
            this.lootChanceLabel.Name = "lootChanceLabel";
            this.lootChanceLabel.Size = new System.Drawing.Size(59, 18);
            this.lootChanceLabel.TabIndex = 23;
            this.lootChanceLabel.Text = "Chance";
            // 
            // lootRemoveButton
            // 
            this.lootRemoveButton.Location = new System.Drawing.Point(397, 146);
            this.lootRemoveButton.Name = "lootRemoveButton";
            this.lootRemoveButton.Size = new System.Drawing.Size(75, 23);
            this.lootRemoveButton.TabIndex = 7;
            this.lootRemoveButton.Text = "Remove";
            this.lootRemoveButton.UseVisualStyleBackColor = true;
            this.lootRemoveButton.Click += new System.EventHandler(this.lootRemoveButton_Click);
            // 
            // lootGridView
            // 
            this.lootGridView.AllowUserToAddRows = false;
            this.lootGridView.AllowUserToDeleteRows = false;
            this.lootGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.lootGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.lootGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lootGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.lootNPCEntryIDColumn,
            this.lootItemEntryIDColumn,
            this.lootChanceColumn,
            this.lootMinAmountColumn,
            this.lootMaxAmountColumn});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.lootGridView.DefaultCellStyle = dataGridViewCellStyle4;
            this.lootGridView.Location = new System.Drawing.Point(4, 183);
            this.lootGridView.Name = "lootGridView";
            this.lootGridView.ReadOnly = true;
            this.lootGridView.Size = new System.Drawing.Size(748, 160);
            this.lootGridView.TabIndex = 10;
            // 
            // lootNPCEntryIDColumn
            // 
            this.lootNPCEntryIDColumn.HeaderText = "NPC Entry ID";
            this.lootNPCEntryIDColumn.Name = "lootNPCEntryIDColumn";
            this.lootNPCEntryIDColumn.ReadOnly = true;
            // 
            // lootItemEntryIDColumn
            // 
            this.lootItemEntryIDColumn.HeaderText = "Item Entry ID";
            this.lootItemEntryIDColumn.Name = "lootItemEntryIDColumn";
            this.lootItemEntryIDColumn.ReadOnly = true;
            // 
            // lootChanceColumn
            // 
            this.lootChanceColumn.HeaderText = "Chance (%)";
            this.lootChanceColumn.Name = "lootChanceColumn";
            this.lootChanceColumn.ReadOnly = true;
            // 
            // lootMinAmountColumn
            // 
            this.lootMinAmountColumn.HeaderText = "Min";
            this.lootMinAmountColumn.Name = "lootMinAmountColumn";
            this.lootMinAmountColumn.ReadOnly = true;
            // 
            // lootMaxAmountColumn
            // 
            this.lootMaxAmountColumn.HeaderText = "Max";
            this.lootMaxAmountColumn.Name = "lootMaxAmountColumn";
            this.lootMaxAmountColumn.ReadOnly = true;
            // 
            // lootMinAmountNumericUpDown
            // 
            this.lootMinAmountNumericUpDown.Location = new System.Drawing.Point(290, 107);
            this.lootMinAmountNumericUpDown.Name = "lootMinAmountNumericUpDown";
            this.lootMinAmountNumericUpDown.Size = new System.Drawing.Size(52, 20);
            this.lootMinAmountNumericUpDown.TabIndex = 3;
            // 
            // lootMinAmountLabel
            // 
            this.lootMinAmountLabel.AutoSize = true;
            this.lootMinAmountLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lootMinAmountLabel.Location = new System.Drawing.Point(182, 109);
            this.lootMinAmountLabel.Name = "lootMinAmountLabel";
            this.lootMinAmountLabel.Size = new System.Drawing.Size(87, 18);
            this.lootMinAmountLabel.TabIndex = 19;
            this.lootMinAmountLabel.Text = "Min Amount";
            // 
            // lootAddButton
            // 
            this.lootAddButton.Location = new System.Drawing.Point(316, 146);
            this.lootAddButton.Name = "lootAddButton";
            this.lootAddButton.Size = new System.Drawing.Size(75, 23);
            this.lootAddButton.TabIndex = 6;
            this.lootAddButton.Text = "Add";
            this.lootAddButton.UseVisualStyleBackColor = true;
            this.lootAddButton.Click += new System.EventHandler(this.lootAddButton_Click);
            // 
            // lootSaveToSQLFileButton
            // 
            this.lootSaveToSQLFileButton.Location = new System.Drawing.Point(232, 349);
            this.lootSaveToSQLFileButton.Name = "lootSaveToSQLFileButton";
            this.lootSaveToSQLFileButton.Size = new System.Drawing.Size(106, 45);
            this.lootSaveToSQLFileButton.TabIndex = 9;
            this.lootSaveToSQLFileButton.Text = "Save To SQL";
            this.lootSaveToSQLFileButton.UseVisualStyleBackColor = true;
            this.lootSaveToSQLFileButton.Click += new System.EventHandler(this.lootSaveToSQLFileButton_Click);
            // 
            // lootSaveToDBButton
            // 
            this.lootSaveToDBButton.Location = new System.Drawing.Point(444, 349);
            this.lootSaveToDBButton.Name = "lootSaveToDBButton";
            this.lootSaveToDBButton.Size = new System.Drawing.Size(106, 45);
            this.lootSaveToDBButton.TabIndex = 8;
            this.lootSaveToDBButton.Text = "Save To DB";
            this.lootSaveToDBButton.UseVisualStyleBackColor = true;
            this.lootSaveToDBButton.Click += new System.EventHandler(this.lootSaveToDBButton_Click);
            // 
            // lootItemEntryIDTextBox
            // 
            this.lootItemEntryIDTextBox.Location = new System.Drawing.Point(290, 71);
            this.lootItemEntryIDTextBox.Name = "lootItemEntryIDTextBox";
            this.lootItemEntryIDTextBox.Size = new System.Drawing.Size(67, 20);
            this.lootItemEntryIDTextBox.TabIndex = 2;
            // 
            // lootItemEntryIDLabel
            // 
            this.lootItemEntryIDLabel.AutoSize = true;
            this.lootItemEntryIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lootItemEntryIDLabel.Location = new System.Drawing.Point(177, 70);
            this.lootItemEntryIDLabel.Name = "lootItemEntryIDLabel";
            this.lootItemEntryIDLabel.Size = new System.Drawing.Size(92, 18);
            this.lootItemEntryIDLabel.TabIndex = 14;
            this.lootItemEntryIDLabel.Text = "Item Entry ID";
            // 
            // lootNPCEntryIDTextBox
            // 
            this.lootNPCEntryIDTextBox.Location = new System.Drawing.Point(290, 25);
            this.lootNPCEntryIDTextBox.Name = "lootNPCEntryIDTextBox";
            this.lootNPCEntryIDTextBox.Size = new System.Drawing.Size(67, 20);
            this.lootNPCEntryIDTextBox.TabIndex = 1;
            // 
            // lootNpcEntryIDLabel
            // 
            this.lootNpcEntryIDLabel.AutoSize = true;
            this.lootNpcEntryIDLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lootNpcEntryIDLabel.Location = new System.Drawing.Point(173, 27);
            this.lootNpcEntryIDLabel.Name = "lootNpcEntryIDLabel";
            this.lootNpcEntryIDLabel.Size = new System.Drawing.Size(96, 18);
            this.lootNpcEntryIDLabel.TabIndex = 12;
            this.lootNpcEntryIDLabel.Text = "NPC Entry ID";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // SaveItemSQLFile
            // 
            this.SaveItemSQLFile.DefaultExt = "sql";
            this.SaveItemSQLFile.Filter = "SQL File|*.sql";
            // 
            // SaveNPCSQLFile
            // 
            this.SaveNPCSQLFile.Filter = "SQL File|*.sql";
            // 
            // VendorSaveSQLFile
            // 
            this.VendorSaveSQLFile.Filter = "SQL File|*.sql";
            // 
            // LootSaveSQLFile
            // 
            this.LootSaveSQLFile.Filter = "SQL File|*.sql";
            // 
            // WeaponSaveSQLFile
            // 
            this.WeaponSaveSQLFile.Filter = "SQL File|*.sql";
            // 
            // ArmorSaveSQLFile
            // 
            this.ArmorSaveSQLFile.Filter = "SQL File|*.sql";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(772, 474);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimumSize = new System.Drawing.Size(788, 512);
            this.Name = "Form1";
            this.Text = "ArcEmu Manager - Version 1.1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.charactersCopperNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.charactersSilverNumericUpDown)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage13.ResumeLayout(false);
            this.tabPage13.PerformLayout();
            this.tabPage17.ResumeLayout(false);
            this.tabPage17.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mailCopperNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mailSilverNumericUpDown)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage11.ResumeLayout(false);
            this.tabPage11.PerformLayout();
            this.tabPage12.ResumeLayout(false);
            this.tabPage12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.tabPage14.ResumeLayout(false);
            this.tabPage14.PerformLayout();
            this.tabPage16.ResumeLayout(false);
            this.tabPage16.PerformLayout();
            this.tabPage15.ResumeLayout(false);
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            this.tabPage10.ResumeLayout(false);
            this.tabPage10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).EndInit();
            this.tabPage18.ResumeLayout(false);
            this.tabPage18.PerformLayout();
            this.creatorTabPage.ResumeLayout(false);
            this.creatorTabControl.ResumeLayout(false);
            this.itemsTabPage.ResumeLayout(false);
            this.itemsTabControl.ResumeLayout(false);
            this.itemDetailsTabPage.ResumeLayout(false);
            this.itemDetailsTabPage.PerformLayout();
            this.itemRequirementsTabPage.ResumeLayout(false);
            this.itemRequirementsTabPage.PerformLayout();
            this.itemPriceTabPage.ResumeLayout(false);
            this.itemPriceTabPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.itemsSellCopperNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsSellSilverNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBuyCopperNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBuySilverNumericUpDown)).EndInit();
            this.itemFinishTabPage.ResumeLayout(false);
            this.weaponsTabPage.ResumeLayout(false);
            this.weaponsTabControl.ResumeLayout(false);
            this.weaponDetailsTabPage.ResumeLayout(false);
            this.weaponDetailsTabPage.PerformLayout();
            this.weaponStatsTabPage.ResumeLayout(false);
            this.weaponArmorStatsGroupBox.ResumeLayout(false);
            this.weaponArmorStatsGroupBox.PerformLayout();
            this.weaponStatsGroupBox.ResumeLayout(false);
            this.weaponStatsGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.weaponSpeedNumericUpDown)).EndInit();
            this.weaponRequirementsTabPage.ResumeLayout(false);
            this.weaponRequirementsTabPage.PerformLayout();
            this.weaponDamageTabPage.ResumeLayout(false);
            this.weaponDamageTabPage.PerformLayout();
            this.weaponResistsTabPage.ResumeLayout(false);
            this.weaponResistsTabPage.PerformLayout();
            this.weaponSocketsTabPage.ResumeLayout(false);
            this.weaponSocketsTabPage.PerformLayout();
            this.weaponPriceTabPage.ResumeLayout(false);
            this.weaponPriceTabPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.weaponSellCopperNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.weaponSellSilverNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.weaponBuyCopperNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.weaponBuySilverNumericUpDown)).EndInit();
            this.weaponFinishTabPage.ResumeLayout(false);
            this.armorTabPage.ResumeLayout(false);
            this.armorTabControl.ResumeLayout(false);
            this.armorDetailsTabPage.ResumeLayout(false);
            this.armorDetailsTabPage.PerformLayout();
            this.armorStatsTabPage.ResumeLayout(false);
            this.armorStatsGroupBox.ResumeLayout(false);
            this.armorStatsGroupBox.PerformLayout();
            this.armorRequirementsTabPage.ResumeLayout(false);
            this.armorRequirementsTabPage.PerformLayout();
            this.armorSocketsTabPage.ResumeLayout(false);
            this.armorSocketsTabPage.PerformLayout();
            this.armorPriceTabPage.ResumeLayout(false);
            this.armorPriceTabPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.armorSellCopperNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.armorSellSilverNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.armorBuyCopperNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.armorBuySilverNumericUpDown)).EndInit();
            this.armorFinishTabPage.ResumeLayout(false);
            this.npcTabPage.ResumeLayout(false);
            this.npcTabControl.ResumeLayout(false);
            this.npcDetailsTabPage.ResumeLayout(false);
            this.npcDetailsTabPage.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.npcBehaviorTabPage.ResumeLayout(false);
            this.npcBehaviorTabPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.npcModelSizeNumericUpDown)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.npcMinutesNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.npcSecondsNumericUpDown)).EndInit();
            this.npcStatsTabPage.ResumeLayout(false);
            this.npcStatsTabPage.PerformLayout();
            this.npcStatsGroupBox.ResumeLayout(false);
            this.npcStatsGroupBox.PerformLayout();
            this.npcAttackStatsGroupBox.ResumeLayout(false);
            this.npcAttackStatsGroupBox.PerformLayout();
            this.npcResistsTabPage.ResumeLayout(false);
            this.npcResistsTabPage.PerformLayout();
            this.npcOptionsTabPage.ResumeLayout(false);
            this.npcGuildBankGroupBox.ResumeLayout(false);
            this.npcGuildBankGroupBox.PerformLayout();
            this.npcStableGroupBox.ResumeLayout(false);
            this.npcStableGroupBox.PerformLayout();
            this.npcAuctioneerGroupBox.ResumeLayout(false);
            this.npcAuctioneerGroupBox.PerformLayout();
            this.npcBankerGroupBox.ResumeLayout(false);
            this.npcBankerGroupBox.PerformLayout();
            this.npcInnkeeperGroupBox.ResumeLayout(false);
            this.npcInnkeeperGroupBox.PerformLayout();
            this.npcArmorerGroupBox.ResumeLayout(false);
            this.npcArmorerGroupBox.PerformLayout();
            this.npcVendorGroupBox.ResumeLayout(false);
            this.npcVendorGroupBox.PerformLayout();
            this.npcGossipGroupBox.ResumeLayout(false);
            this.npcGossipGroupBox.PerformLayout();
            this.npcLootTabPage.ResumeLayout(false);
            this.npcLootGroupBox.ResumeLayout(false);
            this.npcLootGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.npcLootCopperNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.npcLootSilverNumericUpDown)).EndInit();
            this.npcFinishTabPage.ResumeLayout(false);
            this.vendorsTabPage.ResumeLayout(false);
            this.vendorsTabPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.vendorGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vendorAmountNumericUpDown)).EndInit();
            this.lootTabPage.ResumeLayout(false);
            this.lootTabPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lootMaxAmountNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lootGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lootMinAmountNumericUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mySQLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem creditsToolStripMenuItem;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox charactersGoldTextBox;
        private System.Windows.Forms.Label charactersMoneyLabel;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ToolStripMenuItem arcEmuLocationToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TabPage tabPage16;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.NumericUpDown numericUpDown9;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.NumericUpDown numericUpDown8;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.NumericUpDown numericUpDown7;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.NumericUpDown numericUpDown6;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.NumericUpDown numericUpDown5;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.NumericUpDown numericUpDown10;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.ComboBox comboBox11;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.ListBox listBox4;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.ListBox listBox5;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.ToolStripMenuItem otherToolStripMenuItem;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.TabPage tabPage17;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBox13;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.TabPage tabPage18;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TabPage creatorTabPage;
        private System.Windows.Forms.TabControl creatorTabControl;
        private System.Windows.Forms.TabPage npcTabPage;
        private System.Windows.Forms.TabPage itemsTabPage;
        private System.Windows.Forms.TabControl npcTabControl;
        private System.Windows.Forms.TabPage npcDetailsTabPage;
        private System.Windows.Forms.TextBox npcDisplayidTextBox;
        private System.Windows.Forms.Label npcDisplayidLabel;
        private System.Windows.Forms.ComboBox npcRankComboBox;
        private System.Windows.Forms.Label npcRankLabel;
        private System.Windows.Forms.TextBox npcSubnameTextbox;
        private System.Windows.Forms.Label npcSubnameLabel;
        private System.Windows.Forms.TextBox npcNameTextBox;
        private System.Windows.Forms.Label npcNameLabel;
        private System.Windows.Forms.TextBox npcEntryIDTextBox;
        private System.Windows.Forms.Label npcEntryidLabel;
        private System.Windows.Forms.Button npcDetailsNextButton;
        private System.Windows.Forms.TabControl itemsTabControl;
        private System.Windows.Forms.TabPage itemDetailsTabPage;
        private System.Windows.Forms.TabPage itemRequirementsTabPage;
        private System.Windows.Forms.TabPage itemPriceTabPage;
        private System.Windows.Forms.TabPage itemFinishTabPage;
        private System.Windows.Forms.TextBox itemQuoteTextBox;
        private System.Windows.Forms.Label itemQuoteLabel;
        private System.Windows.Forms.TextBox itemNameTextBox;
        private System.Windows.Forms.Label itemNameLabel;
        private System.Windows.Forms.TextBox itemDisplayidTextBox;
        private System.Windows.Forms.Label itemDisplayidLabel;
        private System.Windows.Forms.ComboBox itemQualityComboBox;
        private System.Windows.Forms.Label itemQualityLabel;
        private System.Windows.Forms.TextBox itemEntryTextBox;
        private System.Windows.Forms.Label itemEntryidLabel;
        private System.Windows.Forms.Button itemDetailsNextButton;
        private System.Windows.Forms.Button itemRequirementsNextButton;
        private System.Windows.Forms.Label itemTypeLabel;
        private System.Windows.Forms.ComboBox itemTypeComboBox;
        private System.Windows.Forms.ComboBox itemBindsComboBox;
        private System.Windows.Forms.Label itemBindsLabel;
        private System.Windows.Forms.TextBox itemLevelTextBox;
        private System.Windows.Forms.Label itemLevelLabel;
        private System.Windows.Forms.Label itemRequiredLevelLabel;
        private System.Windows.Forms.TextBox itemRequiredLevelTextBox;
        private System.Windows.Forms.Label itemskillProfressionLabel;
        private System.Windows.Forms.ComboBox itemSkillProfessionComboBox;
        private System.Windows.Forms.TextBox itemSkillLevelTextBox;
        private System.Windows.Forms.Label itemSkillLevelLabel;
        private System.Windows.Forms.CheckBox itemsAllClasses;
        private System.Windows.Forms.Label itemsAllowableClassesLabel;
        private System.Windows.Forms.TextBox itemsMaxTextBox;
        private System.Windows.Forms.Label itemsMaxLabel;
        private System.Windows.Forms.CheckBox itemsDeathKnightCheckBox;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.CheckBox itemsWarlockCheckBox;
        private System.Windows.Forms.CheckBox itemsMageCheckBox;
        private System.Windows.Forms.CheckBox itemsShamanCheckBox;
        private System.Windows.Forms.CheckBox itemsDruidCheckBox;
        private System.Windows.Forms.CheckBox itemsPriestCheckBox;
        private System.Windows.Forms.CheckBox itemsRogueCheckBox;
        private System.Windows.Forms.CheckBox itemsHunterCheckBox;
        private System.Windows.Forms.CheckBox itemsPaladinCheckBox;
        private System.Windows.Forms.CheckBox itemsWarriorCheckBox;
        private System.Windows.Forms.CheckBox itemsOrcCheckBox;
        private System.Windows.Forms.CheckBox itemsHumanCheckBox;
        private System.Windows.Forms.CheckBox itemsAllRaces;
        private System.Windows.Forms.CheckBox itemsUndeadCheckBox;
        private System.Windows.Forms.CheckBox itemsNightElfCheckBox;
        private System.Windows.Forms.CheckBox itemsDwarfCheckBox;
        private System.Windows.Forms.CheckBox itemsGnomeCheckBox;
        private System.Windows.Forms.CheckBox itemsDraeneiCheckBox;
        private System.Windows.Forms.CheckBox itemsBloodElfCheckBox;
        private System.Windows.Forms.CheckBox itemsTrollCheckBox;
        private System.Windows.Forms.CheckBox itemsTaurenCheckBox;
        private System.Windows.Forms.Label itemsSellPriceLabel;
        private System.Windows.Forms.TextBox itemsBuyGoldTextBox;
        private System.Windows.Forms.Label itemsBuyPriceLabel;
        private System.Windows.Forms.Label itemsBuyGoldLabel;
        private System.Windows.Forms.Label itemsBuyCopperLabel;
        private System.Windows.Forms.Label itemsBuySilverLabel;
        private System.Windows.Forms.Label itemsSellCopperLabel;
        private System.Windows.Forms.Label itemsSellSilverLabel;
        private System.Windows.Forms.Label itemsSellGoldLabel;
        private System.Windows.Forms.TextBox itemsSellGoldTextBox;
        private System.Windows.Forms.Button itemsPriceNextButton;
        private System.Windows.Forms.Button itemsSaveToDBButton;
        private System.Windows.Forms.Button itemsStartOverButton;
        private System.Windows.Forms.Button itemDisplayIDSearch;
        private System.Windows.Forms.Button itemsSaveToSQLButton;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.SaveFileDialog SaveItemSQLFile;
        private System.Windows.Forms.TabPage weaponsTabPage;
        private System.Windows.Forms.TabControl weaponsTabControl;
        private System.Windows.Forms.TabPage weaponDetailsTabPage;
        private System.Windows.Forms.TabPage weaponStatsTabPage;
        private System.Windows.Forms.TabPage weaponRequirementsTabPage;
        private System.Windows.Forms.TabPage weaponResistsTabPage;
        private System.Windows.Forms.TabPage weaponSocketsTabPage;
        private System.Windows.Forms.TabPage weaponPriceTabPage;
        private System.Windows.Forms.TabPage weaponFinishTabPage;
        private System.Windows.Forms.TabPage vendorsTabPage;
        private System.Windows.Forms.Label vendorEntryIDLabel;
        private System.Windows.Forms.TextBox vendorItemEntryIDTextBox;
        private System.Windows.Forms.Label vendorItemEntryIDLabel;
        private System.Windows.Forms.TextBox vendorEntryIDTextBox;
        private System.Windows.Forms.Button vendorSaveToSQLButton;
        private System.Windows.Forms.Button vendorSaveToDBButton;
        private System.Windows.Forms.Button vendorAddButton;
        private System.Windows.Forms.NumericUpDown vendorAmountNumericUpDown;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.DataGridView vendorGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn vendorEntryIDColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn vendorItemEntryID;
        private System.Windows.Forms.DataGridViewTextBoxColumn vendorItemAmount;
        private System.Windows.Forms.Button vendorRemoveRowButton;
        private System.Windows.Forms.ComboBox npcTypeComboBox;
        private System.Windows.Forms.Label npcTypeLabel;
        private System.Windows.Forms.ComboBox npcFactionComboBox;
        private System.Windows.Forms.Label npcFactionLabel;
        private System.Windows.Forms.Label npcBossLabel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton npcBossNoRadioButton;
        private System.Windows.Forms.RadioButton npcBossYesRadioButton;
        private System.Windows.Forms.NumericUpDown itemsSellCopperNumericUpDown;
        private System.Windows.Forms.NumericUpDown itemsSellSilverNumericUpDown;
        private System.Windows.Forms.NumericUpDown itemsBuyCopperNumericUpDown;
        private System.Windows.Forms.NumericUpDown itemsBuySilverNumericUpDown;
        private System.Windows.Forms.TabPage npcBehaviorTabPage;
        private System.Windows.Forms.NumericUpDown npcModelSizeNumericUpDown;
        private System.Windows.Forms.Button npcBehaviorNextButton;
        private System.Windows.Forms.Label npcModeLSizeLabel;
        private System.Windows.Forms.Button npcSearchDisplayIDs;
        private System.Windows.Forms.Label npcSecondsLabel;
        private System.Windows.Forms.Label npcMinutesLabel;
        private System.Windows.Forms.Label npcHoursLabel;
        private System.Windows.Forms.TextBox npcHoursTextBox;
        private System.Windows.Forms.NumericUpDown npcSecondsNumericUpDown;
        private System.Windows.Forms.NumericUpDown npcMinutesNumericUpDown;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TabPage npcStatsTabPage;
        private System.Windows.Forms.Label npcArmorLabel;
        private System.Windows.Forms.Label npcManaLabel;
        private System.Windows.Forms.Label npcMinHealthLevel;
        private System.Windows.Forms.Label npcMinDamageLabel;
        private System.Windows.Forms.TextBox npcMaxLevelTextBox;
        private System.Windows.Forms.TextBox npcMinLevelTextBox;
        private System.Windows.Forms.TextBox npcMaxHealthTextBox;
        private System.Windows.Forms.TextBox npcMinHealthTextBox;
        private System.Windows.Forms.TextBox npcManaTextBox;
        private System.Windows.Forms.TextBox npcArmorTextBox;
        private System.Windows.Forms.Label npcMaxLevelLabel;
        private System.Windows.Forms.Label npcMinLevelLabel;
        private System.Windows.Forms.Label npcMaxHealthLabel;
        private System.Windows.Forms.Label npcSpeedLabel;
        private System.Windows.Forms.TextBox npcMaxDamageTextBox;
        private System.Windows.Forms.Label npcMaxDamageLabel;
        private System.Windows.Forms.TextBox npcMinDamageTextBox;
        private System.Windows.Forms.TabPage npcResistsTabPage;
        private System.Windows.Forms.Button npcStatsNextButton;
        private System.Windows.Forms.GroupBox npcStatsGroupBox;
        private System.Windows.Forms.GroupBox npcAttackStatsGroupBox;
        private System.Windows.Forms.TextBox npcResistFrostTextBox;
        private System.Windows.Forms.Label npcResistFrostLabel;
        private System.Windows.Forms.TextBox npcResistFireTextBox;
        private System.Windows.Forms.Label npcResistFireLabel;
        private System.Windows.Forms.TextBox npcResistShadowTextBox;
        private System.Windows.Forms.Label npcResistShadowLabel;
        private System.Windows.Forms.TextBox npcResistNatureTextBox;
        private System.Windows.Forms.Label npcResistNatureLabel;
        private System.Windows.Forms.TextBox npcResistHolyTextBox;
        private System.Windows.Forms.Label npcResistHolyLabel;
        private System.Windows.Forms.Button npcResistsNextButton;
        private System.Windows.Forms.TextBox npcResistArcaneTextBox;
        private System.Windows.Forms.Label npcResistArcaneLabel;
        private System.Windows.Forms.TabPage npcOptionsTabPage;
        private System.Windows.Forms.GroupBox npcGossipGroupBox;
        private System.Windows.Forms.GroupBox npcGuildBankGroupBox;
        private System.Windows.Forms.RadioButton npcGuildBankNoRadioButton;
        private System.Windows.Forms.RadioButton npcGuildBankYesRadioButton;
        private System.Windows.Forms.GroupBox npcStableGroupBox;
        private System.Windows.Forms.RadioButton npcStableNoRadioButton;
        private System.Windows.Forms.RadioButton npcStableYesRadioButton;
        private System.Windows.Forms.GroupBox npcAuctioneerGroupBox;
        private System.Windows.Forms.RadioButton npcAuctioneerNoRadioButton;
        private System.Windows.Forms.RadioButton npcAuctioneerYesRadioButton;
        private System.Windows.Forms.GroupBox npcBankerGroupBox;
        private System.Windows.Forms.RadioButton npcBankerNoRadioButton;
        private System.Windows.Forms.RadioButton npcBankerYesRadioButton;
        private System.Windows.Forms.GroupBox npcInnkeeperGroupBox;
        private System.Windows.Forms.RadioButton npcInnkeeperNoRadioButton;
        private System.Windows.Forms.RadioButton npcInnkeeperYesRadioButton;
        private System.Windows.Forms.GroupBox npcArmorerGroupBox;
        private System.Windows.Forms.RadioButton npcArmorerNoRadioButton;
        private System.Windows.Forms.RadioButton npcArmorerYesRadioButton;
        private System.Windows.Forms.GroupBox npcVendorGroupBox;
        private System.Windows.Forms.RadioButton npcVendorNoRadioButton;
        private System.Windows.Forms.RadioButton npcVendorYesRadioButton;
        private System.Windows.Forms.RadioButton npcGossipNoRadioButton;
        private System.Windows.Forms.RadioButton npcGossipYesRadioButton;
        private System.Windows.Forms.Button npcOptionsNextButton;
        private System.Windows.Forms.TabPage npcLootTabPage;
        private System.Windows.Forms.NumericUpDown npcLootCopperNumericUpDown;
        private System.Windows.Forms.NumericUpDown npcLootSilverNumericUpDown;
        private System.Windows.Forms.Label npcLootCopperLabel;
        private System.Windows.Forms.Label npcLootSilverLabel;
        private System.Windows.Forms.Label npcLootGoldLabel;
        private System.Windows.Forms.TextBox npcLootGoldTextBox;
        private System.Windows.Forms.TabPage npcFinishTabPage;
        private System.Windows.Forms.Button npcLootFinishButton;
        private System.Windows.Forms.GroupBox npcLootGroupBox;
        private System.Windows.Forms.Button npcSaveToSQLFileButton;
        private System.Windows.Forms.Button npcSaveToDBButton;
        private System.Windows.Forms.Button npcStartOverButton;
        private System.Windows.Forms.Label npcDetailsRequiredLabel;
        private System.Windows.Forms.SaveFileDialog SaveNPCSQLFile;
        private System.Windows.Forms.TextBox npcSpeedTextBox;
        private System.Windows.Forms.SaveFileDialog VendorSaveSQLFile;
        private System.Windows.Forms.TabPage lootTabPage;
        private System.Windows.Forms.Label lootChancePercent;
        private System.Windows.Forms.TextBox lootChanceTextBox;
        private System.Windows.Forms.Label lootChanceLabel;
        private System.Windows.Forms.Button lootRemoveButton;
        private System.Windows.Forms.DataGridView lootGridView;
        private System.Windows.Forms.NumericUpDown lootMinAmountNumericUpDown;
        private System.Windows.Forms.Label lootMinAmountLabel;
        private System.Windows.Forms.Button lootAddButton;
        private System.Windows.Forms.Button lootSaveToSQLFileButton;
        private System.Windows.Forms.Button lootSaveToDBButton;
        private System.Windows.Forms.TextBox lootItemEntryIDTextBox;
        private System.Windows.Forms.Label lootItemEntryIDLabel;
        private System.Windows.Forms.TextBox lootNPCEntryIDTextBox;
        private System.Windows.Forms.Label lootNpcEntryIDLabel;
        private System.Windows.Forms.NumericUpDown lootMaxAmountNumericUpDown;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.DataGridViewTextBoxColumn lootNPCEntryIDColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lootItemEntryIDColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lootChanceColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lootMinAmountColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lootMaxAmountColumn;
        private System.Windows.Forms.SaveFileDialog LootSaveSQLFile;
        private System.Windows.Forms.TabPage armorTabPage;
        private System.Windows.Forms.Label charactersGoldLabel;
        private System.Windows.Forms.Label charactersCopperLabel;
        private System.Windows.Forms.Label charactersSilverLabel;
        private System.Windows.Forms.NumericUpDown charactersCopperNumericUpDown;
        private System.Windows.Forms.NumericUpDown charactersSilverNumericUpDown;
        private System.Windows.Forms.Label weaponDetailsRequiredLabel;
        private System.Windows.Forms.Button weaponSearchDisplayIDButton;
        private System.Windows.Forms.Button weaponDetailsNextButton;
        private System.Windows.Forms.TextBox weaponEntryIDTextBox;
        private System.Windows.Forms.Label weaponEntryIDLabel;
        private System.Windows.Forms.TextBox weaponDisplayIDTextBox;
        private System.Windows.Forms.Label weaponDisplayIDLabel;
        private System.Windows.Forms.ComboBox weaponQualityComboBox;
        private System.Windows.Forms.Label weaponQualityLabel;
        private System.Windows.Forms.TextBox weaponQuoteTextBox;
        private System.Windows.Forms.Label weaponQuoteLabel;
        private System.Windows.Forms.TextBox weaponNameTextBox;
        private System.Windows.Forms.Label weaponNameLabel;
        private System.Windows.Forms.ComboBox weaponEquipComboBox;
        private System.Windows.Forms.Label weaponEquipLabel;
        private System.Windows.Forms.ComboBox weaponTypeComboBox;
        private System.Windows.Forms.Label weaponTypeLabel;
        private System.Windows.Forms.ComboBox weaponBindComboBox;
        private System.Windows.Forms.Label weaponBindLabel;
        private System.Windows.Forms.TextBox weaponDurabilityTextBox;
        private System.Windows.Forms.Label weaponDurabilityLabel;
        private System.Windows.Forms.GroupBox weaponArmorStatsGroupBox;
        private System.Windows.Forms.Label weaponBlockLabel;
        private System.Windows.Forms.GroupBox weaponStatsGroupBox;
        private System.Windows.Forms.Label weaponSheathLabel;
        private System.Windows.Forms.Label weaponSpeedLabel;
        private System.Windows.Forms.ComboBox weaponSheathComboBox;
        private System.Windows.Forms.ComboBox weaponAmmoTypeComboBox;
        private System.Windows.Forms.Label weaponAmmoTypeLabel;
        private System.Windows.Forms.TextBox weaponBlockArmorTextBox;
        private System.Windows.Forms.Label weaponBlockArmorLabel;
        private System.Windows.Forms.TextBox weaponBlockTextBox;
        private System.Windows.Forms.Button weaponStatsNextButton;
        private System.Windows.Forms.Button weaponRequirementsNextButton;
        private System.Windows.Forms.CheckBox weaponDraeneiCheckBox;
        private System.Windows.Forms.CheckBox weaponBloodElfCheckBox;
        private System.Windows.Forms.CheckBox weaponTrollCheckBox;
        private System.Windows.Forms.CheckBox weaponTaurenCheckBox;
        private System.Windows.Forms.CheckBox weaponGnomeCheckBox;
        private System.Windows.Forms.CheckBox weaponUndeadCheckBox;
        private System.Windows.Forms.CheckBox weaponNightElfCheckBox;
        private System.Windows.Forms.CheckBox weaponDwarfCheckBox;
        private System.Windows.Forms.CheckBox weaponOrcCheckBox;
        private System.Windows.Forms.CheckBox weaponHumanCheckBox;
        private System.Windows.Forms.CheckBox weaponRaceAllCheckBox;
        private System.Windows.Forms.CheckBox weaponDeathKnightCheckBox;
        private System.Windows.Forms.Label weaponAllowableRaceLabel;
        private System.Windows.Forms.CheckBox weaponWarlockCheckBox;
        private System.Windows.Forms.CheckBox weaponMageCheckBox;
        private System.Windows.Forms.CheckBox weaponShamanCheckBox;
        private System.Windows.Forms.CheckBox weaponDruidCheckBox;
        private System.Windows.Forms.CheckBox weaponPriestCheckBox;
        private System.Windows.Forms.CheckBox weaponRogueCheckBox;
        private System.Windows.Forms.CheckBox weaponHunterCheckBox;
        private System.Windows.Forms.CheckBox weaponPaladinCheckBox;
        private System.Windows.Forms.CheckBox weaponWarriorCheckBox;
        private System.Windows.Forms.CheckBox weaponClassAllCheckBox;
        private System.Windows.Forms.Label weaponAllowableClassLabel;
        private System.Windows.Forms.TextBox weaponMaxTextBox;
        private System.Windows.Forms.Label weaponMaxLabel;
        private System.Windows.Forms.TextBox weaponItemLevelTextBox;
        private System.Windows.Forms.Label weaponItemLevelLabel;
        private System.Windows.Forms.TextBox weaponRequiredLevelTextBox;
        private System.Windows.Forms.Label weaponRequiredLevelLabel;
        private System.Windows.Forms.Label weaponStackableLabel;
        private System.Windows.Forms.TextBox weaponStackableTextBox;
        private System.Windows.Forms.TabPage weaponDamageTabPage;
        private System.Windows.Forms.TextBox weaponDamageMax1TextBox;
        private System.Windows.Forms.Label weaponDamageMax1Label;
        private System.Windows.Forms.TextBox weaponDamageMin1TextBox;
        private System.Windows.Forms.Label weaponDamageMin1Label;
        private System.Windows.Forms.Label weaponDamageType1Label;
        private System.Windows.Forms.ComboBox weaponDamageType1ComboBox;
        private System.Windows.Forms.ComboBox weaponDamageType2ComboBox;
        private System.Windows.Forms.Label weaponDamageType2Label;
        private System.Windows.Forms.TextBox weaponDamageMax2TextBox;
        private System.Windows.Forms.Label weaponDamageMax2Label;
        private System.Windows.Forms.TextBox weaponDamageMin2TextBox;
        private System.Windows.Forms.Label weaponDamageMin2Label;
        private System.Windows.Forms.Button weaponDamageNextButton;
        private System.Windows.Forms.TextBox weaponArcaneTextBox;
        private System.Windows.Forms.Label weaponArcaneLabel;
        private System.Windows.Forms.TextBox weaponFrostTextBox;
        private System.Windows.Forms.Label weaponFrostLabel;
        private System.Windows.Forms.TextBox weaponFireTextBox;
        private System.Windows.Forms.Label weaponFireLabel;
        private System.Windows.Forms.TextBox weaponShadowTextBox;
        private System.Windows.Forms.Label weaponShadowLabel;
        private System.Windows.Forms.TextBox weaponNatureTextBox;
        private System.Windows.Forms.Label weaponNatureLabel;
        private System.Windows.Forms.TextBox weaponHolyTextBox;
        private System.Windows.Forms.Label weaponHolyLabel;
        private System.Windows.Forms.Button weaponResistsNextButton;
        private System.Windows.Forms.Button weaponSocket2YellowButton;
        private System.Windows.Forms.Button weaponSocket2RedButton;
        private System.Windows.Forms.Button weaponSocket2BlueButton;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button weaponSocket1YellowButton;
        private System.Windows.Forms.Button weaponSocket1RedButton;
        private System.Windows.Forms.Button weaponSocket1BlueButton;
        private System.Windows.Forms.Label weaponSocket1Label;
        private System.Windows.Forms.Button weaponSocket3YellowButton;
        private System.Windows.Forms.Button weaponSocket3RedButton;
        private System.Windows.Forms.Button weaponSocket3BlueButton;
        private System.Windows.Forms.Label weaponSocket3Label;
        private System.Windows.Forms.Button weaponSocketsNextButton;
        private System.Windows.Forms.NumericUpDown weaponSellCopperNumericUpDown;
        private System.Windows.Forms.NumericUpDown weaponSellSilverNumericUpDown;
        private System.Windows.Forms.NumericUpDown weaponBuyCopperNumericUpDown;
        private System.Windows.Forms.NumericUpDown weaponBuySilverNumericUpDown;
        private System.Windows.Forms.Label weaponSellCopperLabel;
        private System.Windows.Forms.Label weaponSellSilverLabel;
        private System.Windows.Forms.Label weaponSellGoldLabel;
        private System.Windows.Forms.TextBox weaponSellGoldTextBox;
        private System.Windows.Forms.Label weaponBuyCopperLabel;
        private System.Windows.Forms.Label weaponBuySilverLabel;
        private System.Windows.Forms.Label weaponBuyGoldLabel;
        private System.Windows.Forms.Label weaponSellPriceLabel;
        private System.Windows.Forms.TextBox weaponBuyGoldTextBox;
        private System.Windows.Forms.Label weaponBuyPriceLabel;
        private System.Windows.Forms.Button weaponPriceNextButton;
        private System.Windows.Forms.Button weaponSaveToSQLFileButton;
        private System.Windows.Forms.Button weaponSaveToDBButton;
        private System.Windows.Forms.Button weaponStartOverButton;
        private System.Windows.Forms.Button weaponSocket3NoneButton;
        private System.Windows.Forms.Button weaponSocket2NoneButton;
        private System.Windows.Forms.Button weaponSocket1NoneButton;
        private System.Windows.Forms.Label weaponSocketBonusLabel;
        private System.Windows.Forms.ComboBox weaponSocketBonusComboBox;
        private System.Windows.Forms.NumericUpDown weaponSpeedNumericUpDown;
        private System.Windows.Forms.SaveFileDialog WeaponSaveSQLFile;
        private System.Windows.Forms.TabControl armorTabControl;
        private System.Windows.Forms.TabPage armorDetailsTabPage;
        private System.Windows.Forms.TabPage armorStatsTabPage;
        private System.Windows.Forms.Label armorRequiredLabel;
        private System.Windows.Forms.Button armorSearchDisplayIDs;
        private System.Windows.Forms.Button armorDetailsNextButton;
        private System.Windows.Forms.ComboBox armorBindsComboBox;
        private System.Windows.Forms.Label armorBindsLabel;
        private System.Windows.Forms.TextBox armorDurabilityTextBox;
        private System.Windows.Forms.Label armorDurabilityLabel;
        private System.Windows.Forms.ComboBox armorEquipComboBox;
        private System.Windows.Forms.Label armorEquipLabel;
        private System.Windows.Forms.TextBox armorEntryIDTextBox;
        private System.Windows.Forms.Label armorEntryIDLabel;
        private System.Windows.Forms.TextBox armorDisplayIDTextBox;
        private System.Windows.Forms.Label armorDisplayIDLabel;
        private System.Windows.Forms.ComboBox armorQualityComboBox;
        private System.Windows.Forms.Label armorQualityLabel;
        private System.Windows.Forms.TextBox armorQuoteTextBox;
        private System.Windows.Forms.Label armorQuoteLabel;
        private System.Windows.Forms.TextBox armorNameTextBox;
        private System.Windows.Forms.Label armorNameLabel;
        private System.Windows.Forms.TabPage armorRequirementsTabPage;
        private System.Windows.Forms.TabPage armorSocketsTabPage;
        private System.Windows.Forms.TabPage armorPriceTabPage;
        private System.Windows.Forms.Label armorMaterialLabel;
        private System.Windows.Forms.ComboBox armorMaterialComboBox;
        private System.Windows.Forms.GroupBox armorStatsGroupBox;
        private System.Windows.Forms.TextBox armorStatsArmorTextBox;
        private System.Windows.Forms.Label armorStatsArmorLabel;
        private System.Windows.Forms.TextBox armorStatsBlockTextBox;
        private System.Windows.Forms.Label armorStatsBlockLabel;
        private System.Windows.Forms.Button armorStatsNextButton;
        private System.Windows.Forms.Label armorStackableLabel;
        private System.Windows.Forms.TextBox armorStackableTextBox;
        private System.Windows.Forms.Button armorRequirementsNextButton;
        private System.Windows.Forms.CheckBox armorDraeneiCheckBox;
        private System.Windows.Forms.CheckBox armorBloodElfCheckBox;
        private System.Windows.Forms.CheckBox armorTrollCheckBox;
        private System.Windows.Forms.CheckBox armorTaurenCheckBox;
        private System.Windows.Forms.CheckBox armorGnomeCheckBox;
        private System.Windows.Forms.CheckBox armorUndeadCheckBox;
        private System.Windows.Forms.CheckBox armorNightElfCheckBox;
        private System.Windows.Forms.CheckBox armorDwarfCheckBox;
        private System.Windows.Forms.CheckBox armorOrcCheckBox;
        private System.Windows.Forms.CheckBox armorHumanCheckBox;
        private System.Windows.Forms.CheckBox armorRaceAllCheckBox;
        private System.Windows.Forms.CheckBox armorDeathKnightCheckBox;
        private System.Windows.Forms.Label armorAllowableRaceLabel;
        private System.Windows.Forms.CheckBox armorWarlockCheckBox;
        private System.Windows.Forms.CheckBox armorMageCheckBox;
        private System.Windows.Forms.CheckBox armorShamanCheckBox;
        private System.Windows.Forms.CheckBox armorDruidCheckBox;
        private System.Windows.Forms.CheckBox armorPriestCheckBox;
        private System.Windows.Forms.CheckBox armorRogueCheckBox;
        private System.Windows.Forms.CheckBox armorHunterCheckBox;
        private System.Windows.Forms.CheckBox armorPaladinCheckBox;
        private System.Windows.Forms.CheckBox armorWarriorCheckBox;
        private System.Windows.Forms.CheckBox armorClassAllCheckBox;
        private System.Windows.Forms.Label armorAllowableClassLabel;
        private System.Windows.Forms.TextBox armorMaxTextBox;
        private System.Windows.Forms.Label armorMaxLabel;
        private System.Windows.Forms.TextBox armorItemLevelTextBox;
        private System.Windows.Forms.Label armorItemLevelLabel;
        private System.Windows.Forms.TextBox armorRequiredLevelTextBox;
        private System.Windows.Forms.Label armorRequiredLevelLabel;
        private System.Windows.Forms.Label armorBonusLabel;
        private System.Windows.Forms.ComboBox armorBonusComboBox;
        private System.Windows.Forms.Button armorSocket3NoneButton;
        private System.Windows.Forms.Button armorSocket2NoneButton;
        private System.Windows.Forms.Button armorSocket1NoneButton;
        private System.Windows.Forms.Button armorSocketsNextButton;
        private System.Windows.Forms.Button armorSocket3YellowButton;
        private System.Windows.Forms.Button armorSocket3RedButtton;
        private System.Windows.Forms.Button armorSocket3BlueButton;
        private System.Windows.Forms.Label armorSocket3Label;
        private System.Windows.Forms.Button armorSocket2YellowButton;
        private System.Windows.Forms.Button armorSocket2RedButton;
        private System.Windows.Forms.Button armorSocket2BlueButton;
        private System.Windows.Forms.Label armorSocket2Label;
        private System.Windows.Forms.Button armorSocket1YellowButton;
        private System.Windows.Forms.Button armorSocket1RedButton;
        private System.Windows.Forms.Button armorSocket1BlueButton;
        private System.Windows.Forms.Label armorSocket1Label;
        private System.Windows.Forms.Button armorSellPriceNextButton;
        private System.Windows.Forms.NumericUpDown armorSellCopperNumericUpDown;
        private System.Windows.Forms.NumericUpDown armorSellSilverNumericUpDown;
        private System.Windows.Forms.NumericUpDown armorBuyCopperNumericUpDown;
        private System.Windows.Forms.NumericUpDown armorBuySilverNumericUpDown;
        private System.Windows.Forms.Label armorSellCopperLabel;
        private System.Windows.Forms.Label armorSellSilverLabel;
        private System.Windows.Forms.Label armorSellGoldLabel;
        private System.Windows.Forms.TextBox armorSellGoldTextBox;
        private System.Windows.Forms.Label armorBuyCopperLabel;
        private System.Windows.Forms.Label armorBuySilverLabel;
        private System.Windows.Forms.Label armorBuyGoldLabel;
        private System.Windows.Forms.Label armorSellLabel;
        private System.Windows.Forms.TextBox armorBuyGoldTextBox;
        private System.Windows.Forms.Label armorBuyPriceLabel;
        private System.Windows.Forms.TabPage armorFinishTabPage;
        private System.Windows.Forms.Button armorSaveToSQLButton;
        private System.Windows.Forms.Button armorSaveToDBButton;
        private System.Windows.Forms.Button armorStartOverButton;
        private System.Windows.Forms.SaveFileDialog ArmorSaveSQLFile;
        private System.Windows.Forms.Button lootSearchItemButton;
        private System.Windows.Forms.Button lootSearchNPCButton;
        private System.Windows.Forms.NumericUpDown mailCopperNumericUpDown;
        private System.Windows.Forms.NumericUpDown mailSilverNumericUpDown;
        private System.Windows.Forms.Label mailCopperLabel;
        private System.Windows.Forms.Label mailSilverLabel;
        private System.Windows.Forms.Label mailGoldLabel;
        private System.Windows.Forms.TextBox mailGoldTextBox;
        private System.Windows.Forms.Label mailMoneyLabel;
        private System.Windows.Forms.Button searchVendorNPCEntryIDsButton;
        private System.Windows.Forms.Button vendorResetButton;
    }
}

