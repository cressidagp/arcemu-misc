﻿/* ArcEmu Manager
 * 
 * Copyright (C) 2010 Mitchell Kutchuk (Mitch528)
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *  
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *  
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *  
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using ArcEmu_Manager.Properties;

namespace ArcEmu_Manager
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private bool itemexists = false;

        private void Form5_Load(object sender, EventArgs e)
        {
            textBox1.KeyPress += new KeyPressEventHandler(textBox1_KeyPress);
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) e.Handled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text != String.Empty)
                {
                    string connection = String.Format("Data Source={0};Database={1};User ID={2};Password={3};Port={4};", Settings.Default.host, Settings.Default.worlddb, Settings.Default.username, Settings.Default.password, Settings.Default.port);

                    MySqlConnection mConnection = new MySqlConnection(connection);

                    mConnection.Open();

                    string qry = String.Format("SELECT * FROM items WHERE entry='{0}'", textBox1.Text);

                    MySqlCommand cmd = new MySqlCommand(qry, mConnection);

                    MySqlDataReader Reader = cmd.ExecuteReader();

                    string item = String.Empty;

                    while (Reader.Read())
                    {
                        item = Reader.GetString("entry");
                    }

                    mConnection.Close();
                    mConnection.Dispose();

                    if (item != String.Empty)
                    {
                        itemexists = true;
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show(String.Format("Entry {0} does not exist!", textBox1.Text));
                    }
                }
                else
                {
                    MessageBox.Show("You must fill out all fields!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public string getTextBoxValue()
        {
            if (itemexists == true)
            {
                return textBox1.Text;
            }
            else
            {
                return null;
            }
        }
    }
}
