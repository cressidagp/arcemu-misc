﻿namespace ArcEmu_Manager
{
    partial class SearchNPCDisplayID
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchNPCDisplayID));
            this.Submit = new System.Windows.Forms.Button();
            this.searchButton = new System.Windows.Forms.Button();
            this.npcLabel = new System.Windows.Forms.Label();
            this.searchTextBox = new System.Windows.Forms.TextBox();
            this.searchListBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // Submit
            // 
            this.Submit.Location = new System.Drawing.Point(297, 323);
            this.Submit.Name = "Submit";
            this.Submit.Size = new System.Drawing.Size(103, 36);
            this.Submit.TabIndex = 14;
            this.Submit.Text = "Submit";
            this.Submit.UseVisualStyleBackColor = true;
            this.Submit.Click += new System.EventHandler(this.Submit_Click);
            // 
            // searchButton
            // 
            this.searchButton.Location = new System.Drawing.Point(455, 30);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(75, 23);
            this.searchButton.TabIndex = 13;
            this.searchButton.Text = "Search";
            this.searchButton.UseVisualStyleBackColor = true;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // npcLabel
            // 
            this.npcLabel.AutoSize = true;
            this.npcLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.npcLabel.Location = new System.Drawing.Point(186, 31);
            this.npcLabel.Name = "npcLabel";
            this.npcLabel.Size = new System.Drawing.Size(84, 18);
            this.npcLabel.TabIndex = 12;
            this.npcLabel.Text = "NPC Name";
            // 
            // searchTextBox
            // 
            this.searchTextBox.Location = new System.Drawing.Point(284, 31);
            this.searchTextBox.Name = "searchTextBox";
            this.searchTextBox.Size = new System.Drawing.Size(153, 20);
            this.searchTextBox.TabIndex = 10;
            // 
            // searchListBox
            // 
            this.searchListBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchListBox.FormattingEnabled = true;
            this.searchListBox.ItemHeight = 20;
            this.searchListBox.Location = new System.Drawing.Point(9, 71);
            this.searchListBox.Name = "searchListBox";
            this.searchListBox.Size = new System.Drawing.Size(690, 244);
            this.searchListBox.TabIndex = 11;
            // 
            // SearchNPCDisplayID
            // 
            this.AcceptButton = this.searchButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(708, 366);
            this.Controls.Add(this.Submit);
            this.Controls.Add(this.searchButton);
            this.Controls.Add(this.npcLabel);
            this.Controls.Add(this.searchTextBox);
            this.Controls.Add(this.searchListBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "SearchNPCDisplayID";
            this.Text = "Search For NPC Display IDs";
            this.Load += new System.EventHandler(this.SearchNPCDisplayID_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Submit;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.Label npcLabel;
        private System.Windows.Forms.TextBox searchTextBox;
        private System.Windows.Forms.ListBox searchListBox;
    }
}